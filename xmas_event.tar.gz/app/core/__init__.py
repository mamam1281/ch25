"""Core utilities and configuration."""
