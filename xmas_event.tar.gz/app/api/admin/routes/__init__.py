# /workspace/ch25/app/api/admin/routes/__init__.py
"""Admin route modules namespace."""
