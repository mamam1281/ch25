"""Application package initialization."""
