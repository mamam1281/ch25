-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: xmas_event
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` varchar(100) DEFAULT NULL,
  `before_json` json DEFAULT NULL,
  `after_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_admin_audit_log_id` (`id`),
  KEY `ix_admin_audit_log_admin_id` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','null','{\"value\": {\"body\": \"지금 씨씨를 이용하면 바로 이어서 플레이 가능합니다.\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}}}','2025-12-31 16:27:58'),(2,2,'UPDATE_UNLOCK_RULES','VaultProgram','NEW_MEMBER_VAULT','{\"unlock_rules_json\": {\"available_grace_hours\": 0}}','{\"unlock_rules_json\": {\"available_grace_hours\": 0, \"phase1_deposit_unlock\": {\"tiers\": [{\"unlock_amount\": 30000, \"min_deposit_delta\": 500000}], \"trigger\": \"EXTERNAL_RANKING_DEPOSIT_INCREASE\"}}}','2025-12-31 16:40:58'),(3,2,'UPDATE_CONFIG','VaultProgram','NEW_MEMBER_VAULT','{\"config_json\": {\"eligibility_mode\": \"all\", \"eligibility_allow\": [], \"eligibility_block\": [], \"charge_bonus_rules\": [], \"enable_game_earn_events\": true}}','{\"config_json\": {\"eligibility_mode\": \"all\", \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {}, \"enable_game_earn_events\": true}}','2025-12-31 18:32:48'),(4,2,'UPDATE_CONFIG','VaultProgram','NEW_MEMBER_VAULT','{\"config_json\": {\"eligibility_mode\": \"all\", \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {}, \"enable_game_earn_events\": true}}','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTe\": 100}, \"enable_game_earn_events\": true}}','2026-01-02 12:56:25'),(5,2,'UPDATE_CONFIG','VaultProgram','NEW_MEMBER_VAULT','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTe\": 100}, \"enable_game_earn_events\": true}}','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTE:1\": 100}, \"enable_game_earn_events\": true}}','2026-01-02 12:57:07'),(6,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": null}','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','2026-01-02 13:30:30'),(7,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"지금 씨씨를 이용하면 바로 이어서 플레이 가능합니다.\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}}}','{\"value\": {\"body\": \"지금 씨씨를 이용하면 바로 이어서 플레이 가능합니다.\\n🤩인기 패키지 추천\\n🎁스타터팩: 1만 - 첫충 - 주사위 2장\\n🎁베스트팩: 10만 (20XP) - 주사위 4장 \\n⭐프리미엄팩: 20 만 (45XP/5%) - 주사위 5장 / 복권 1장  \\n🔎VIP팩: 50만(120XP/20%) - 룰렛 5장 / 주사위 2장 / 복권 3장 \", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-02 13:30:30'),(8,2,'UPDATE_UI_CONFIG','AppUiConfig','shop_products','null','{\"value\": {\"products\": {\"PROD_GOLD_KEY_1\": {\"title\": \"골드키 교환권\", \"is_active\": true, \"cost_amount\": 30}, \"PROD_DIAMOND_KEY_1\": {\"title\": \"다이아키 교환권\", \"is_active\": true, \"cost_amount\": 100}}}}','2026-01-02 13:31:38'),(9,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','2026-01-02 13:34:00'),(10,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"지금 씨씨를 이용하면 바로 이어서 플레이 가능합니다.\\n🤩인기 패키지 추천\\n🎁스타터팩: 1만 - 첫충 - 주사위 2장\\n🎁베스트팩: 10만 (20XP) - 주사위 4장 \\n⭐프리미엄팩: 20 만 (45XP/5%) - 주사위 5장 / 복권 1장  \\n🔎VIP팩: 50만(120XP/20%) - 룰렛 5장 / 주사위 2장 / 복권 3장 \", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"지금 바로 씨씨 충전하구 티켓받자 \\n🎁스타터팩: 1만 - 첫충 - 주사위 2장\\n🎁베스트팩: 10만 (20XP) - 주사위 4장 / 룰렛 1장 \\n⭐프리미엄팩: 20 만 (45XP/5%) - 주사위 4장 / 룰렛2장 / 복권 2장  \\n🔎VIP팩: 50만(120XP/20%) - 룰렛 5장 / 주사위 2장 / 복권 5장 \", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-02 13:34:00'),(11,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','2026-01-02 13:38:11'),(12,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"지금 바로 씨씨 충전하구 티켓받자 \\n🎁스타터팩: 1만 - 첫충 - 주사위 2장\\n🎁베스트팩: 10만 (20XP) - 주사위 4장 / 룰렛 1장 \\n⭐프리미엄팩: 20 만 (45XP/5%) - 주사위 4장 / 룰렛2장 / 복권 2장  \\n🔎VIP팩: 50만(120XP/20%) - 룰렛 5장 / 주사위 2장 / 복권 5장 \", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"지금 바로 씨씨 충전하구 티켓받자 \\n🎁스타터팩: 1만 - 첫충 - 주사위 2장\\n🎁베스트팩: 10만 (20XP) - 주사위 4장 / 룰렛 1장 \\n⭐프리미엄팩: 20 만 (45XP/5%) - 주사위 4장 / 룰렛2장 / 복권 2장  \\n🔎VIP팩: 50만(120XP/20%) - 룰렛 5장 / 주사위 2장 / 복권 5장 \", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-02 13:38:11'),(13,2,'UPDATE_CONFIG','VaultProgram','NEW_MEMBER_VAULT','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTE:1\": 100}, \"enable_game_earn_events\": true}}','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_DICE:2\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTE:1\": 100}, \"enable_game_earn_events\": true}}','2026-01-02 14:08:55'),(14,2,'UPDATE_CONFIG','VaultProgram','NEW_MEMBER_VAULT','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_DICE:2\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTE:1\": 100}, \"enable_game_earn_events\": true}}','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_DICE:2\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTE:1\": 100, \"TICKET__ROULETTE:2\": 100}, \"enable_game_earn_events\": true}}','2026-01-02 14:09:07'),(15,2,'UPDATE_VAULT_BALANCE','VaultStatus','NEW_MEMBER_VAULT:20','{\"locked\": 27600, \"available\": 0}','{\"locked\": 30150, \"reason\": \"관리자 조정\", \"available\": 0}','2026-01-02 23:07:29'),(16,2,'UPDATE_VAULT_BALANCE','VaultStatus','NEW_MEMBER_VAULT:20','{\"locked\": 30150, \"available\": 0}','{\"locked\": 1600, \"reason\": \"관리자 조정\", \"available\": 0}','2026-01-02 23:07:44'),(17,2,'UPDATE_VAULT_BALANCE','VaultStatus','NEW_MEMBER_VAULT:20','{\"locked\": 1600, \"available\": 0}','{\"locked\": 2550, \"reason\": \"관리자 조정\", \"available\": 0}','2026-01-02 23:08:00'),(18,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"지금 바로 씨씨 충전하구 티켓받자 \\n🎁스타터팩: 1만 - 첫충 - 주사위 2장\\n🎁베스트팩: 10만 (20XP) - 주사위 4장 / 룰렛 1장 \\n⭐프리미엄팩: 20 만 (45XP/5%) - 주사위 4장 / 룰렛2장 / 복권 2장  \\n🔎VIP팩: 50만(120XP/20%) - 룰렛 5장 / 주사위 2장 / 복권 5장 \", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"지금 바로 씨씨 충전하구 티켓받자 ! \\n스타터 1만 (첫충=주사위2장 )\\n맛보기10만  (1렙+주사위4장)\\n베스트 20만 (2렙+주사위5장+복권1장)\\nVIP 50만 (3렙+ 티켓풀패키지)\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-02 23:58:46'),(19,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','2026-01-02 23:58:46'),(20,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','2026-01-02 23:58:56'),(21,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"지금 바로 씨씨 충전하구 티켓받자 ! \\n스타터 1만 (첫충=주사위2장 )\\n맛보기10만  (1렙+주사위4장)\\n베스트 20만 (2렙+주사위5장+복권1장)\\nVIP 50만 (3렙+ 티켓풀패키지)\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"티켓이 잠깐 부족해요\", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"스타터 1만 (첫충=주사위2장 )\\n맛보기10만  (1렙+주사위4장)\\n베스트 20만 (2렙+주사위5장+복권1장)\\nVIP 50만 (3렙+ 티켓풀패키지)\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-02 23:58:56'),(22,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','2026-01-03 00:00:25'),(23,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"스타터 1만 (첫충=주사위2장 )\\n맛보기10만  (1렙+주사위4장)\\n베스트 20만 (2렙+주사위5장+복권1장)\\nVIP 50만 (3렙+ 티켓풀패키지)\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"스타터🎶 1만 (첫충=주사위2장 )\\n👌맛보기10만  (1렙+주사위4장)\\n❤️베스트 20만 (2렙+주사위5장+복권1장)\\n❤️VIP 50만 (3렙+ 티켓풀패키지)🪄\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-03 00:00:25'),(24,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"🆕 웰컴 미션\\n- 접속하면 자동미션\\n- 4개 완료하면 보상지급\\n- 완료 전까지는 계속\\n\\n미션이 안 보이면 \\n닉네임 + 화면 스샷주세요\", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"title\": \"내 금고\"}}','2026-01-03 00:05:17'),(25,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"스타터🎶 1만 (첫충=주사위2장 )\\n👌맛보기10만  (1렙+주사위4장)\\n❤️베스트 20만 (2렙+주사위5장+복권1장)\\n❤️VIP 50만 (3렙+ 티켓풀패키지)🪄\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"스타터🎶 1만 (첫충=주사위2장 )\\n👌맛보기10만  (1렙+주사위4장)\\n❤️베스트 20만 (2렙+주사위5장+복권1장)\\n❤️VIP 50만 (3렙+ 티켓풀패키지)🪄\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-03 00:05:17'),(26,2,'UPDATE_CONFIG','VaultProgram','NEW_MEMBER_VAULT','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 100, \"TICKET_DICE:2\": 100, \"TICKET_LOTTERY:1\": 100, \"TICKET__ROULETTE:1\": 100, \"TICKET__ROULETTE:2\": 100}, \"enable_game_earn_events\": true}}','{\"config_json\": {\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 10, \"TICKET_DICE:2\": 10, \"TICKET_LOTTERY:1\": 10, \"TICKET__ROULETTE:1\": 10, \"TICKET__ROULETTE:2\": 10}, \"enable_game_earn_events\": true}}','2026-01-03 03:05:10'),(27,2,'UPDATE_VAULT_BALANCE','VaultStatus','NEW_MEMBER_VAULT:30','{\"locked\": 23200, \"available\": 0}','{\"locked\": 26300, \"reason\": \"관리자 조정 + 금고출금잔액\", \"available\": 0}','2026-01-03 08:05:17'),(28,2,'UPDATE_UI_COPY','VaultProgram','NEW_MEMBER_VAULT','{\"ui_copy_json\": {\"desc\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"title\": \"내 금고\"}}','{\"ui_copy_json\": {\"desc\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"title\": \"내 금고\"}}','2026-01-03 08:06:11'),(29,2,'UPDATE_UI_CONFIG','AppUiConfig','ticket_zero','{\"value\": {\"body\": \"스타터🎶 1만 (첫충=주사위2장 )\\n👌맛보기10만  (1렙+주사위4장)\\n❤️베스트 20만 (2렙+주사위5장+복권1장)\\n❤️VIP 50만 (3렙+ 티켓풀패키지)🪄\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','{\"value\": {\"body\": \"스타터🎶 1만 (주사위2장 )\\n👌맛보기10만  (주사위4장)\\n❤️베스트 20만 (주사위5장+복권1장)\\n❤️VIP 50만 (티켓풀10장)🪄\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}}','2026-01-03 08:06:11'),(30,2,'UPDATE_VAULT_BALANCE','VaultStatus','NEW_MEMBER_VAULT:30','{\"locked\": 26300, \"available\": 0}','{\"locked\": 29400, \"reason\": \"관리자 조정\", \"available\": 0}','2026-01-03 08:11:22'),(31,2,'UPDATE_VAULT_BALANCE','VaultStatus','NEW_MEMBER_VAULT:30','{\"locked\": 29400, \"available\": 0}','{\"locked\": 29400, \"reason\": \"관리자 조정\", \"available\": 0}','2026-01-03 08:12:00');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_message`
--

DROP TABLE IF EXISTS `admin_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_admin_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `target_type` varchar(50) NOT NULL,
  `target_value` varchar(255) DEFAULT NULL,
  `channels` json DEFAULT NULL,
  `recipient_count` int DEFAULT NULL,
  `read_count` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_admin_message_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_message`
--

LOCK TABLES `admin_message` WRITE;
/*!40000 ALTER TABLE `admin_message` DISABLE KEYS */;
INSERT INTO `admin_message` VALUES (1,2,'a','test','USER','tg_8216057989_7c310233','[\"INBOX\"]',0,0,'2025-12-31 18:33:26'),(2,2,'2026년 새해 복 많이 받으세요','2025년 고생 많으셨습니다\n행복한 2026년 되세요! ','ALL','','[\"INBOX\"]',4,2,'2025-12-31 18:57:21'),(3,2,'코드지갑 1/2(금) 밤 9시 정식런칭','새해 복 많이 받으세요🙂\n코드지갑 업그레이드로 \n안내가 늦었습니다. \n불편 드려 죄송합니다\n새해 복 많이 받으시고 한분한분 \n다 건강하시고 건승하시길 바랍니다\n\n✅코드지갑 찐찐찐찌막막 업글\n✅게임/티켓 현재 정상이용가능\n✅별도 로그인 없이 텔레그램 접속시 자동\n🤴웰컴미션 4종 \n🤴게임 +200 🆚 -50\n\n⚠️충전액 반영 안내\n\n충전액 반영은 외부 비공개 API로 \n운영자가 확인 후 처리합니다.\n\n⏳반영 시간 (매일)\n09~20시: 매시 정각\n20~24시: 4시간 단위\n00~09시: 중단(익일 9시 재개)','ALL','','[\"INBOX\"]',13,6,'2026-01-02 12:17:22'),(4,2,'웰컴 미션이란?','- 접속하면 자동으로 미션창 오픈\n- 4개 완료하면 자동 지급\n- 완료 전까지는 계속 진행 (1/31까지)\n\n미션이 안 보이면 닉네임+ 화면스샷 주세요!','ALL','','[\"INBOX\"]',15,5,'2026-01-02 13:31:05'),(5,2,'🤩 인기 패키지 추천','1만 첫충: 주사위2\n10만: 1렙+ 주사위4\n20만: 2렙+ 주사위5+복권1\n50만: 3렙+ 티켓풀10\n단일입금만 정산, \n이벤트는 하루 2회까지.','ALL','','[\"INBOX\"]',15,5,'2026-01-02 13:33:48'),(6,2,'🤩인기 패키지 적용관련','스타터 1만(첫충) 주사위2장\n맛보기 10만(1렙+) 주사위4장\n베스트 20만(2렙+) 주사위5장+복권1장\nVIP 50만(3렙+) 티켓풀 10장\n\n단일 입금 기준 정산. \n이벤트 1인 1일 2회 한정.','ALL','','[\"INBOX\"]',14,3,'2026-01-02 23:47:35');
/*!40000 ALTER TABLE `admin_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_message_inbox`
--

DROP TABLE IF EXISTS `admin_message_inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_message_inbox` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `message_id` int NOT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_admin_message_inbox_id` (`id`),
  KEY `ix_admin_message_inbox_message_id` (`message_id`),
  KEY `ix_admin_message_inbox_user_id` (`user_id`),
  CONSTRAINT `admin_message_inbox_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_message_inbox_ibfk_2` FOREIGN KEY (`message_id`) REFERENCES `admin_message` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_message_inbox`
--

LOCK TABLES `admin_message_inbox` WRITE;
/*!40000 ALTER TABLE `admin_message_inbox` DISABLE KEYS */;
INSERT INTO `admin_message_inbox` VALUES (1,2,2,0,NULL,'2025-12-31 18:57:21'),(5,2,3,0,NULL,'2026-01-02 12:17:22'),(9,7,3,1,'2026-01-02 13:51:57','2026-01-02 12:17:22'),(10,9,3,0,NULL,'2026-01-02 12:17:22'),(12,12,3,0,NULL,'2026-01-02 12:17:22'),(13,13,3,1,'2026-01-02 12:58:18','2026-01-02 12:17:22'),(14,14,3,1,'2026-01-02 13:22:50','2026-01-02 12:17:22'),(15,15,3,0,NULL,'2026-01-02 12:17:22'),(16,16,3,1,'2026-01-03 03:36:03','2026-01-02 12:17:22'),(17,17,3,0,NULL,'2026-01-02 12:17:22'),(18,2,4,0,NULL,'2026-01-02 13:31:05'),(22,7,4,1,'2026-01-02 13:51:34','2026-01-02 13:31:05'),(23,9,4,0,NULL,'2026-01-02 13:31:05'),(25,12,4,0,NULL,'2026-01-02 13:31:05'),(26,13,4,1,'2026-01-02 14:35:22','2026-01-02 13:31:05'),(27,14,4,0,NULL,'2026-01-02 13:31:05'),(28,15,4,0,NULL,'2026-01-02 13:31:05'),(29,16,4,1,'2026-01-03 03:36:03','2026-01-02 13:31:05'),(30,17,4,0,NULL,'2026-01-02 13:31:05'),(31,18,4,0,NULL,'2026-01-02 13:31:05'),(32,19,4,1,'2026-01-02 13:31:35','2026-01-02 13:31:05'),(33,2,5,0,NULL,'2026-01-02 13:33:48'),(37,7,5,1,'2026-01-02 13:51:19','2026-01-02 13:33:48'),(38,9,5,0,NULL,'2026-01-02 13:33:48'),(40,12,5,0,NULL,'2026-01-02 13:33:48'),(41,13,5,1,'2026-01-02 14:35:19','2026-01-02 13:33:48'),(42,14,5,0,NULL,'2026-01-02 13:33:48'),(43,15,5,0,NULL,'2026-01-02 13:33:48'),(44,16,5,1,'2026-01-03 03:36:03','2026-01-02 13:33:48'),(45,17,5,0,NULL,'2026-01-02 13:33:48'),(46,18,5,0,NULL,'2026-01-02 13:33:48'),(47,19,5,1,'2026-01-02 13:35:15','2026-01-02 13:33:48'),(48,2,6,0,NULL,'2026-01-02 23:47:35'),(49,7,6,1,'2026-01-03 01:43:04','2026-01-02 23:47:35'),(50,9,6,0,NULL,'2026-01-02 23:47:35'),(51,12,6,0,NULL,'2026-01-02 23:47:35'),(52,13,6,1,'2026-01-03 00:28:36','2026-01-02 23:47:35'),(53,14,6,0,NULL,'2026-01-02 23:47:35'),(54,15,6,0,NULL,'2026-01-02 23:47:35'),(55,16,6,1,'2026-01-03 03:36:09','2026-01-02 23:47:35'),(56,17,6,0,NULL,'2026-01-02 23:47:35'),(57,18,6,0,NULL,'2026-01-02 23:47:35'),(58,19,6,0,NULL,'2026-01-02 23:47:35'),(59,20,6,0,NULL,'2026-01-02 23:47:35'),(60,21,6,0,NULL,'2026-01-02 23:47:35'),(61,22,6,0,NULL,'2026-01-02 23:47:35');
/*!40000 ALTER TABLE `admin_message_inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_user_profile`
--

DROP TABLE IF EXISTS `admin_user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_user_profile` (
  `user_id` int NOT NULL,
  `external_id` varchar(100) DEFAULT NULL,
  `real_name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `telegram_id` varchar(100) DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `memo` text,
  `total_active_days` int DEFAULT NULL,
  `days_since_last_charge` int DEFAULT NULL,
  `last_active_date_str` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `ix_admin_user_profile_telegram_id` (`telegram_id`),
  KEY `ix_admin_user_profile_external_id` (`external_id`),
  CONSTRAINT `admin_user_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user_profile`
--

LOCK TABLES `admin_user_profile` WRITE;
/*!40000 ALTER TABLE `admin_user_profile` DISABLE KEYS */;
INSERT INTO `admin_user_profile` VALUES (2,'admin','Admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-31 16:10:42','2025-12-31 16:10:42'),(7,NULL,'최재훈/persipic','','6085974841','[]','',NULL,NULL,NULL,'2026-01-02 23:35:28','2026-01-02 23:35:28'),(12,NULL,'조규완/봄꽃잎','','1387125026','[]','',NULL,NULL,NULL,'2026-01-02 23:34:23','2026-01-02 23:34:23'),(13,NULL,'test/test','','7711588195','[]','',NULL,NULL,NULL,'2026-01-03 02:07:15','2026-01-03 02:07:15'),(14,NULL,'김기훈/초보베터','','8157048749','[]','',NULL,NULL,NULL,'2026-01-02 13:19:22','2026-01-02 13:19:22'),(15,NULL,'변대성/돈머니돈','','5240054244','[\"진상\"]','진상',NULL,NULL,NULL,'2026-01-02 13:18:59','2026-01-03 04:59:06'),(16,NULL,'김민석/일등당첨','','1249639412','[]','',NULL,NULL,NULL,'2026-01-02 13:17:47','2026-01-02 13:17:47'),(17,NULL,'현민수/민똘이','','7192872944','[]','',NULL,NULL,NULL,'2026-01-02 12:18:34','2026-01-02 12:18:34'),(18,NULL,'오동수/동추','','8338823321','[]','',NULL,NULL,NULL,'2026-01-02 12:41:25','2026-01-02 12:41:25'),(19,NULL,'이진숙/세상은참','','7764179799','[]','',NULL,NULL,NULL,'2026-01-02 13:23:19','2026-01-02 13:23:19'),(20,NULL,'남상헌/나이스비','','5787179040','[]','',NULL,NULL,NULL,'2026-01-02 23:19:19','2026-01-02 23:19:19'),(21,NULL,'','','5721857928','[]','',NULL,NULL,NULL,'2026-01-03 01:32:43','2026-01-03 01:32:43'),(22,NULL,'최락천/돈따묵쟈','','1981255322','[]','',NULL,NULL,NULL,'2026-01-02 23:40:50','2026-01-02 23:40:50'),(23,NULL,'이훈기/콩이랑','','7292051908','[]','',NULL,NULL,NULL,'2026-01-03 01:44:18','2026-01-03 01:44:18'),(24,NULL,'송윤서/아사카','','766455411','[]','',NULL,NULL,NULL,'2026-01-03 02:48:43','2026-01-03 02:48:43'),(25,NULL,'신평화/피슈웅','','8101149602','[]','',NULL,NULL,NULL,'2026-01-03 03:41:18','2026-01-03 03:41:26'),(26,NULL,'test/test','','40074587','[]','',NULL,NULL,NULL,'2026-01-03 04:45:23','2026-01-03 04:45:23'),(27,NULL,'유재경/라오스오','','7690760913','[]','',NULL,NULL,NULL,'2026-01-03 07:24:53','2026-01-03 07:24:53'),(29,NULL,'김현규/기프트','','7973906786','[]','',NULL,NULL,NULL,'2026-01-03 07:56:28','2026-01-03 07:56:28'),(30,NULL,'이용운/성민이','','8372420683','[]','',NULL,NULL,NULL,'2026-01-03 07:56:12','2026-01-03 07:56:12');
/*!40000 ALTER TABLE `admin_user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('20260102_0001');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_ui_config`
--

DROP TABLE IF EXISTS `app_ui_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_ui_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_ui_config_key` (`key`),
  KEY `ix_app_ui_config_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_ui_config`
--

LOCK TABLES `app_ui_config` WRITE;
/*!40000 ALTER TABLE `app_ui_config` DISABLE KEYS */;
INSERT INTO `app_ui_config` VALUES (1,'ticket_zero','{\"body\": \"스타터🎶 1만 (주사위2장 )\\n👌맛보기10만  (주사위4장)\\n❤️베스트 20만 (주사위5장+복권1장)\\n❤️VIP 50만 (티켓풀10장)🪄\\n단일입금 적용\\n1인 2회 혜택가능\", \"note\": \"문구는 매일 변경됩니다.\", \"title\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"primaryCta\": {\"url\": \"https://ccc-010.com\", \"label\": \"씨씨카지노 바로가기\"}, \"secondaryCta\": {\"url\": \"https://t.me/jm956\", \"label\": \"실장 텔레 문의\"}, \"primary_cta_url\": \"https://ccc-010.com\", \"primary_cta_label\": \"씨씨카지노 바로가기\", \"secondary_cta_url\": \"https://t.me/jm956\", \"secondary_cta_label\": \"실장 텔레 문의\"}','2025-12-31 16:27:58','2026-01-03 08:06:11'),(2,'shop_products','{\"products\": {\"PROD_GOLD_KEY_1\": {\"title\": \"골드키 교환권\", \"is_active\": true, \"cost_amount\": 30}, \"PROD_DIAMOND_KEY_1\": {\"title\": \"다이아키 교환권\", \"is_active\": true, \"cost_amount\": 100}}}','2026-01-02 13:31:38','2026-01-02 13:31:38');
/*!40000 ALTER TABLE `app_ui_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dice_config`
--

DROP TABLE IF EXISTS `dice_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dice_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `max_daily_plays` int NOT NULL,
  `win_reward_type` varchar(50) NOT NULL,
  `win_reward_amount` int NOT NULL,
  `draw_reward_type` varchar(50) NOT NULL,
  `draw_reward_amount` int NOT NULL,
  `lose_reward_type` varchar(50) NOT NULL,
  `lose_reward_amount` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_dice_config_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dice_config`
--

LOCK TABLES `dice_config` WRITE;
/*!40000 ALTER TABLE `dice_config` DISABLE KEYS */;
INSERT INTO `dice_config` VALUES (1,'2026001',1,0,'NONE',0,'TICKET_DICE',1,'NONE',0,'2025-12-31 16:57:17','2026-01-02 13:00:21');
/*!40000 ALTER TABLE `dice_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dice_log`
--

DROP TABLE IF EXISTS `dice_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dice_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `config_id` int NOT NULL,
  `user_dice_1` int NOT NULL,
  `user_dice_2` int NOT NULL,
  `user_sum` int NOT NULL,
  `dealer_dice_1` int NOT NULL,
  `dealer_dice_2` int NOT NULL,
  `dealer_sum` int NOT NULL,
  `result` varchar(10) NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `config_id` (`config_id`),
  KEY `ix_dice_log_id` (`id`),
  KEY `ix_dice_log_user_created_at` (`user_id`,`created_at`),
  CONSTRAINT `dice_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `dice_log_ibfk_2` FOREIGN KEY (`config_id`) REFERENCES `dice_config` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dice_log`
--

LOCK TABLES `dice_log` WRITE;
/*!40000 ALTER TABLE `dice_log` DISABLE KEYS */;
INSERT INTO `dice_log` VALUES (31,9,1,2,1,3,6,4,10,'LOSE','NONE',0,'2026-01-01 03:21:24'),(32,9,1,5,2,7,3,4,7,'DRAW','NONE',0,'2026-01-01 03:21:28'),(37,17,1,1,2,3,6,1,7,'LOSE','NONE',0,'2026-01-02 12:13:24'),(38,17,1,2,5,7,1,3,4,'WIN','TICKET_DICE',1,'2026-01-02 12:15:01'),(39,17,1,4,4,8,4,4,8,'DRAW','NONE',0,'2026-01-02 12:15:05'),(40,13,1,6,3,9,5,3,8,'WIN','TICKET_DICE',1,'2026-01-02 12:59:08'),(41,13,1,4,5,9,1,5,6,'WIN','TICKET_DICE',1,'2026-01-02 12:59:14'),(42,13,1,3,5,8,1,1,2,'WIN','TICKET_DICE',1,'2026-01-02 12:59:19'),(43,13,1,4,4,8,1,6,7,'WIN','TICKET_DICE',1,'2026-01-02 12:59:22'),(44,13,1,4,4,8,2,3,5,'WIN','TICKET_DICE',1,'2026-01-02 12:59:25'),(45,13,1,1,5,6,1,1,2,'WIN','TICKET_DICE',1,'2026-01-02 12:59:29'),(46,13,1,6,1,7,3,1,4,'WIN','TICKET_DICE',1,'2026-01-02 12:59:31'),(47,13,1,3,4,7,4,1,5,'WIN','TICKET_DICE',1,'2026-01-02 12:59:34'),(48,13,1,1,2,3,1,3,4,'LOSE','NONE',0,'2026-01-02 12:59:36'),(49,19,1,4,1,5,4,6,10,'LOSE','NONE',0,'2026-01-02 13:37:40'),(50,19,1,3,4,7,4,2,6,'WIN','NONE',0,'2026-01-02 13:37:59'),(51,7,1,2,1,3,6,3,9,'LOSE','NONE',0,'2026-01-02 13:52:44'),(52,20,1,1,1,2,1,2,3,'LOSE','NONE',0,'2026-01-02 16:45:21'),(53,20,1,5,2,7,3,4,7,'DRAW','TICKET_DICE',1,'2026-01-02 16:51:22'),(54,20,1,4,6,10,2,3,5,'WIN','NONE',0,'2026-01-02 16:51:27'),(55,20,1,6,3,9,1,5,6,'WIN','NONE',0,'2026-01-02 16:51:30'),(56,20,1,1,3,4,3,1,4,'DRAW','TICKET_DICE',1,'2026-01-02 16:51:37'),(57,20,1,1,1,2,4,3,7,'LOSE','NONE',0,'2026-01-02 16:51:39'),(58,7,1,6,5,11,1,4,5,'WIN','NONE',0,'2026-01-03 01:43:14'),(59,7,1,3,1,4,4,1,5,'LOSE','NONE',0,'2026-01-03 01:43:22'),(60,9,1,6,4,10,5,5,10,'DRAW','TICKET_DICE',1,'2026-01-03 02:16:32'),(61,13,1,6,2,8,6,6,12,'LOSE','NONE',0,'2026-01-03 03:03:41'),(62,16,1,1,4,5,4,6,10,'LOSE','NONE',0,'2026-01-03 03:36:58'),(63,16,1,6,3,9,5,3,8,'WIN','NONE',0,'2026-01-03 03:37:55'),(64,16,1,5,1,6,5,6,11,'LOSE','NONE',0,'2026-01-03 03:37:57'),(65,27,1,1,4,5,4,3,7,'LOSE','NONE',0,'2026-01-03 05:31:54'),(66,27,1,1,3,4,4,6,10,'LOSE','NONE',0,'2026-01-03 05:33:58'),(67,27,1,4,1,5,6,5,11,'LOSE','NONE',0,'2026-01-03 05:34:01'),(68,27,1,4,6,10,4,3,7,'WIN','NONE',0,'2026-01-03 05:34:04'),(69,29,1,4,2,6,2,4,6,'DRAW','TICKET_DICE',1,'2026-01-03 08:03:44'),(70,29,1,1,1,2,4,5,9,'LOSE','NONE',0,'2026-01-03 08:03:50'),(71,29,1,2,1,3,3,2,5,'LOSE','NONE',0,'2026-01-03 08:04:01'),(72,29,1,2,6,8,5,3,8,'DRAW','TICKET_DICE',1,'2026-01-03 08:06:34'),(73,29,1,3,2,5,6,2,8,'LOSE','NONE',0,'2026-01-03 08:06:38'),(74,29,1,4,5,9,5,4,9,'DRAW','TICKET_DICE',1,'2026-01-03 08:06:43'),(75,29,1,4,5,9,2,1,3,'WIN','NONE',0,'2026-01-03 08:06:46'),(76,29,1,4,2,6,2,6,8,'LOSE','NONE',0,'2026-01-03 08:06:50'),(77,29,1,2,1,3,1,3,4,'LOSE','NONE',0,'2026-01-03 08:06:53'),(78,29,1,4,4,8,1,5,6,'WIN','NONE',0,'2026-01-03 08:06:56'),(79,29,1,3,4,7,3,3,6,'WIN','NONE',0,'2026-01-03 08:08:42'),(80,29,1,2,5,7,4,3,7,'DRAW','TICKET_DICE',1,'2026-01-03 08:08:45'),(81,29,1,1,6,7,5,1,6,'WIN','NONE',0,'2026-01-03 08:08:49'),(82,29,1,6,1,7,1,2,3,'WIN','NONE',0,'2026-01-03 08:08:52'),(83,29,1,4,2,6,2,1,3,'WIN','NONE',0,'2026-01-03 08:08:55'),(84,29,1,4,2,6,3,4,7,'LOSE','NONE',0,'2026-01-03 08:08:58'),(85,29,1,2,6,8,1,5,6,'WIN','NONE',0,'2026-01-03 08:09:01'),(86,29,1,2,4,6,6,3,9,'LOSE','NONE',0,'2026-01-03 08:09:04');
/*!40000 ALTER TABLE `dice_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_ranking_data`
--

DROP TABLE IF EXISTS `external_ranking_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_ranking_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `deposit_amount` int NOT NULL,
  `play_count` int NOT NULL,
  `deposit_remainder` int NOT NULL,
  `daily_base_deposit` int NOT NULL,
  `daily_base_play` int NOT NULL,
  `last_daily_reset` date DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_external_ranking_user` (`user_id`),
  KEY `ix_external_ranking_data_id` (`id`),
  KEY `ix_external_ranking_data_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_ranking_data`
--

LOCK TABLES `external_ranking_data` WRITE;
/*!40000 ALTER TABLE `external_ranking_data` DISABLE KEYS */;
INSERT INTO `external_ranking_data` VALUES (1,3,100000,1,0,100000,1,'2026-01-03','','2025-12-31 17:03:26','2026-01-02 23:32:46'),(2,4,50000,1,50000,50000,1,'2026-01-03','','2025-12-31 18:36:31','2026-01-02 23:32:46'),(3,18,320000,2,0,320000,2,'2026-01-03','','2026-01-02 13:02:42','2026-01-02 23:32:46'),(4,17,350000,4,50000,0,0,'2026-01-03','','2026-01-02 23:32:46','2026-01-02 23:32:46'),(5,12,200000,1,0,0,0,'2026-01-03','','2026-01-02 23:34:44','2026-01-02 23:34:44'),(6,7,60000,3,20000,0,0,'2026-01-03','','2026-01-02 23:35:54','2026-01-03 01:58:01'),(7,24,300000,3,0,0,0,'2026-01-03','','2026-01-03 02:49:59','2026-01-03 04:57:36'),(8,22,30000,1,0,0,0,'2026-01-03','','2026-01-03 02:51:10','2026-01-03 02:51:10'),(9,27,150000,1,50000,0,0,'2026-01-03','','2026-01-03 07:25:59','2026-01-03 07:26:00'),(10,30,300000,1,0,0,0,'2026-01-03','','2026-01-03 07:57:00','2026-01-03 07:57:00'),(11,29,200000,1,0,0,0,'2026-01-03','','2026-01-03 07:57:13','2026-01-03 07:57:13');
/*!40000 ALTER TABLE `external_ranking_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_ranking_reward_log`
--

DROP TABLE IF EXISTS `external_ranking_reward_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_ranking_reward_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `reason` varchar(100) NOT NULL,
  `season_name` varchar(50) NOT NULL,
  `data_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `data_id` (`data_id`),
  KEY `ix_external_ranking_reward_log_id` (`id`),
  KEY `ix_external_ranking_reward_log_user_id` (`user_id`),
  CONSTRAINT `external_ranking_reward_log_ibfk_1` FOREIGN KEY (`data_id`) REFERENCES `external_ranking_data` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_ranking_reward_log`
--

LOCK TABLES `external_ranking_reward_log` WRITE;
/*!40000 ALTER TABLE `external_ranking_reward_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_ranking_reward_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feature_config`
--

DROP TABLE IF EXISTS `feature_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `feature_type` enum('ROULETTE','DICE','LOTTERY','RANKING','SEASON_PASS','NONE') NOT NULL,
  `title` varchar(100) NOT NULL,
  `page_path` varchar(100) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL,
  `config_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_feature_config_feature_type` (`feature_type`),
  KEY `ix_feature_config_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_config`
--

LOCK TABLES `feature_config` WRITE;
/*!40000 ALTER TABLE `feature_config` DISABLE KEYS */;
INSERT INTO `feature_config` VALUES (1,'ROULETTE','Christmas Roulette','/roulette',1,NULL,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(2,'SEASON_PASS','Season Pass','/season-pass',1,NULL,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(3,'DICE','Christmas Dice','/dice',1,NULL,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(4,'LOTTERY','Christmas Lottery','/lottery',1,NULL,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(5,'RANKING','Christmas Ranking','/ranking',1,NULL,'2026-01-01 01:00:58','2026-01-01 01:00:58');
/*!40000 ALTER TABLE `feature_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feature_schedule`
--

DROP TABLE IF EXISTS `feature_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `feature_type` enum('ROULETTE','DICE','LOTTERY','RANKING','SEASON_PASS','NONE') NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_feature_schedule_date` (`date`),
  KEY `ix_feature_schedule_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_schedule`
--

LOCK TABLES `feature_schedule` WRITE;
/*!40000 ALTER TABLE `feature_schedule` DISABLE KEYS */;
INSERT INTO `feature_schedule` VALUES (1,'2026-01-01','ROULETTE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(2,'2025-12-09','SEASON_PASS',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(3,'2025-12-10','ROULETTE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(4,'2025-12-11','DICE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(5,'2025-12-12','LOTTERY',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(6,'2025-12-13','RANKING',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(7,'2025-12-14','ROULETTE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(8,'2025-12-15','DICE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(9,'2025-12-16','LOTTERY',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(10,'2025-12-17','RANKING',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(11,'2025-12-18','ROULETTE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(12,'2025-12-19','DICE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(13,'2025-12-20','LOTTERY',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(14,'2025-12-21','RANKING',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(15,'2025-12-22','ROULETTE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(16,'2025-12-23','DICE',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(17,'2025-12-24','LOTTERY',1,'2026-01-01 01:00:58','2026-01-01 01:00:58'),(18,'2025-12-25','SEASON_PASS',1,'2026-01-01 01:00:58','2026-01-01 01:00:58');
/*!40000 ALTER TABLE `feature_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lottery_config`
--

DROP TABLE IF EXISTS `lottery_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `max_daily_tickets` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_lottery_config_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_config`
--

LOCK TABLES `lottery_config` WRITE;
/*!40000 ALTER TABLE `lottery_config` DISABLE KEYS */;
INSERT INTO `lottery_config` VALUES (1,'2026001',1,30,'2025-12-31 16:26:28','2026-01-01 08:23:17');
/*!40000 ALTER TABLE `lottery_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lottery_log`
--

DROP TABLE IF EXISTS `lottery_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `config_id` int NOT NULL,
  `prize_id` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `config_id` (`config_id`),
  KEY `prize_id` (`prize_id`),
  KEY `ix_lottery_log_id` (`id`),
  KEY `ix_lottery_log_user_created_at` (`user_id`,`created_at`),
  CONSTRAINT `lottery_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lottery_log_ibfk_2` FOREIGN KEY (`config_id`) REFERENCES `lottery_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lottery_log_ibfk_3` FOREIGN KEY (`prize_id`) REFERENCES `lottery_prize` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_log`
--

LOCK TABLES `lottery_log` WRITE;
/*!40000 ALTER TABLE `lottery_log` DISABLE KEYS */;
INSERT INTO `lottery_log` VALUES (22,13,1,108,'NONE',1,'2026-01-02 14:35:57'),(23,20,1,114,'NONE',1,'2026-01-02 16:53:03'),(24,7,1,112,'NONE',1,'2026-01-03 01:43:49'),(25,9,1,113,'TICKET_DICE',1,'2026-01-03 02:17:13'),(26,13,1,114,'NONE',1,'2026-01-03 03:03:53'),(27,16,1,107,'TICKET_ROULETTE',1,'2026-01-03 03:36:27'),(28,27,1,114,'NONE',1,'2026-01-03 05:35:17'),(29,29,1,112,'NONE',1,'2026-01-03 08:01:39'),(30,29,1,108,'NONE',1,'2026-01-03 08:02:30'),(31,29,1,107,'TICKET_ROULETTE',1,'2026-01-03 08:07:47'),(32,29,1,108,'NONE',1,'2026-01-03 08:07:53'),(33,29,1,113,'TICKET_DICE',1,'2026-01-03 08:07:58'),(34,29,1,107,'TICKET_ROULETTE',1,'2026-01-03 08:08:03'),(35,29,1,114,'NONE',1,'2026-01-03 08:09:47');
/*!40000 ALTER TABLE `lottery_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lottery_prize`
--

DROP TABLE IF EXISTS `lottery_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_prize` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_id` int NOT NULL,
  `label` varchar(100) NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `weight` int NOT NULL,
  `stock` int DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_lottery_prize_label` (`config_id`,`label`),
  KEY `ix_lottery_prize_id` (`id`),
  CONSTRAINT `lottery_prize_ibfk_1` FOREIGN KEY (`config_id`) REFERENCES `lottery_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_lottery_prize_stock_non_negative` CHECK (((`stock` is null) or (`stock` >= 0))),
  CONSTRAINT `ck_lottery_prize_weight_non_negative` CHECK ((`weight` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_prize`
--

LOCK TABLES `lottery_prize` WRITE;
/*!40000 ALTER TABLE `lottery_prize` DISABLE KEYS */;
INSERT INTO `lottery_prize` VALUES (107,1,'룰렛티켓','TICKET_ROULETTE',1,350,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(108,1,'배민5천원','NONE',1,180,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(109,1,'씨씨코인','NONE',1,100,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(110,1,'씨씨포인트1만원','NONE',1,3,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(111,1,'씨씨포인트2만원','NONE',1,1,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(112,1,'씨씨포인트2천원','NONE',1,400,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(113,1,'주사위티켓','TICKET_DICE',1,500,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(114,1,'컴포즈아아','NONE',1,500,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34'),(115,1,'골드키','GOLD_KEY',1,8,NULL,1,'2026-01-02 14:09:34','2026-01-02 14:09:34');
/*!40000 ALTER TABLE `lottery_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mission`
--

DROP TABLE IF EXISTS `mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `category` enum('DAILY','WEEKLY','SPECIAL','NEW_USER') NOT NULL,
  `logic_key` varchar(100) NOT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `target_value` int NOT NULL,
  `reward_type` enum('NONE','DIAMOND','GOLD_KEY','DIAMOND_KEY','CASH_UNLOCK','TICKET_BUNDLE','TICKET_ROULETTE','TICKET_LOTTERY','TICKET_DICE') NOT NULL,
  `reward_amount` int NOT NULL,
  `xp_reward` int NOT NULL,
  `requires_approval` tinyint(1) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_mission_logic_key` (`logic_key`),
  KEY `ix_mission_category` (`category`),
  KEY `ix_mission_id` (`id`),
  KEY `ix_mission_action_type` (`action_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mission`
--

LOCK TABLES `mission` WRITE;
/*!40000 ALTER TABLE `mission` DISABLE KEYS */;
INSERT INTO `mission` VALUES (1,'오픈기념 출석미션','오픈기념 일일 게임 1회 ','DAILY','','PLAY_GAME',1,'DIAMOND',1,0,0,NULL,NULL,1,'2025-12-31 16:18:04'),(2,'오픈기념 지민미션','지민코드지갑 자랑 공유하기','WEEKLY','week','SHARE_STORY',1,'DIAMOND',1,0,0,NULL,NULL,0,'2025-12-31 16:18:54'),(3,'오픈기념 게임미션','코드지갑 게임 26회 ','DAILY','daily','PLAY_GAME',26,'DIAMOND',6,0,0,NULL,NULL,1,'2025-12-31 16:20:11'),(4,'오픈기념 친구소개미션','오픈기념  코드지갑 공유하기','SPECIAL','special 2026 001','SHARE_WALLET',1,'DIAMOND',1,0,0,NULL,NULL,1,'2026-01-01 08:22:40'),(5,'첫 게임 플레이 ','아무 게임이나 1회 플레이\n다이아 1개  씨씨포인트 2500원','NEW_USER','NEW_USER_PLAY_1','PLAY_GAME',1,'CASH_UNLOCK',1,0,0,NULL,NULL,1,'2026-01-02 11:16:56'),(6,'게임 마스터 (3회)','게임을 3회 더 플레이해보세요.\n다이아 1개 씨씨포인트 2500원','NEW_USER','NEW_USER_PLAY_3','PLAY_GAME',3,'CASH_UNLOCK',1,0,0,NULL,NULL,1,'2026-01-02 11:16:56'),(7,'커뮤니티 함께하기','공식 채널에 입장하거나 스토리를 공유하세요.\n다이아 1개 씨씨포인트 2500원','NEW_USER','NEW_USER_VIRAL','JOIN_CHANNEL',1,'CASH_UNLOCK',1,0,0,NULL,NULL,1,'2026-01-02 11:16:56'),(8,'2일차 출석 체크','내일 다시 접속하여 출석체크를 완료하세요.\n다이아 1개 씨씨포인트 2500원','NEW_USER','NEW_USER_LOGIN_DAY2','daily_checkin',3,'CASH_UNLOCK',1,0,0,NULL,NULL,1,'2026-01-02 11:16:56');
/*!40000 ALTER TABLE `mission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_member_dice_eligibility`
--

DROP TABLE IF EXISTS `new_member_dice_eligibility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_member_dice_eligibility` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `is_eligible` tinyint(1) NOT NULL,
  `campaign_key` varchar(50) DEFAULT NULL,
  `granted_by` varchar(100) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_new_member_dice_eligibility_user_id` (`user_id`),
  KEY `ix_new_member_dice_eligibility_user_id` (`user_id`),
  KEY `ix_new_member_dice_eligibility_id` (`id`),
  CONSTRAINT `new_member_dice_eligibility_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_member_dice_eligibility`
--

LOCK TABLES `new_member_dice_eligibility` WRITE;
/*!40000 ALTER TABLE `new_member_dice_eligibility` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_member_dice_eligibility` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_member_dice_log`
--

DROP TABLE IF EXISTS `new_member_dice_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_member_dice_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `campaign_key` varchar(50) DEFAULT NULL,
  `outcome` varchar(10) NOT NULL,
  `user_dice` int NOT NULL,
  `dealer_dice` int NOT NULL,
  `win_link` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_new_member_dice_log_user_id` (`user_id`),
  KEY `ix_new_member_dice_log_user_created_at` (`user_id`,`created_at`),
  KEY `ix_new_member_dice_log_id` (`id`),
  CONSTRAINT `new_member_dice_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_member_dice_log`
--

LOCK TABLES `new_member_dice_log` WRITE;
/*!40000 ALTER TABLE `new_member_dice_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_member_dice_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ranking_daily`
--

DROP TABLE IF EXISTS `ranking_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ranking_daily` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `user_id` int DEFAULT NULL,
  `display_name` varchar(50) NOT NULL,
  `score` int NOT NULL,
  `rank` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ranking_daily_date_rank` (`date`,`rank`),
  KEY `user_id` (`user_id`),
  KEY `ix_ranking_daily_id` (`id`),
  CONSTRAINT `ranking_daily_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking_daily`
--

LOCK TABLES `ranking_daily` WRITE;
/*!40000 ALTER TABLE `ranking_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `ranking_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roulette_config`
--

DROP TABLE IF EXISTS `roulette_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roulette_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ticket_type` varchar(50) NOT NULL DEFAULT 'ROULETTE_COIN',
  `is_active` tinyint(1) NOT NULL,
  `max_daily_spins` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_roulette_config_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roulette_config`
--

LOCK TABLES `roulette_config` WRITE;
/*!40000 ALTER TABLE `roulette_config` DISABLE KEYS */;
INSERT INTO `roulette_config` VALUES (1,'2026001','ROULETTE_COIN',1,0,'2025-12-31 16:17:18','2025-12-31 16:17:18'),(2,'2026002','GOLD_KEY',1,0,'2025-12-31 18:21:51','2025-12-31 18:21:56'),(3,'2026003','DIAMOND_KEY',1,0,'2025-12-31 18:22:04','2025-12-31 18:22:07');
/*!40000 ALTER TABLE `roulette_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roulette_log`
--

DROP TABLE IF EXISTS `roulette_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roulette_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `config_id` int NOT NULL,
  `segment_id` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `config_id` (`config_id`),
  KEY `segment_id` (`segment_id`),
  KEY `ix_roulette_log_user_created_at` (`user_id`,`created_at`),
  KEY `ix_roulette_log_id` (`id`),
  CONSTRAINT `roulette_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `roulette_log_ibfk_2` FOREIGN KEY (`config_id`) REFERENCES `roulette_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `roulette_log_ibfk_3` FOREIGN KEY (`segment_id`) REFERENCES `roulette_segment` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roulette_log`
--

LOCK TABLES `roulette_log` WRITE;
/*!40000 ALTER TABLE `roulette_log` DISABLE KEYS */;
INSERT INTO `roulette_log` VALUES (48,17,1,170,'TICKET_DICE',1,'2026-01-02 12:14:12'),(49,17,1,173,'NONE',0,'2026-01-02 12:14:17'),(50,17,1,170,'TICKET_DICE',1,'2026-01-02 12:14:30'),(51,18,1,169,'TICKET_ROULETTE',1,'2026-01-02 12:42:03'),(52,18,1,170,'TICKET_DICE',1,'2026-01-02 12:42:09'),(53,18,1,170,'TICKET_DICE',1,'2026-01-02 12:42:17'),(54,18,1,170,'TICKET_DICE',1,'2026-01-02 12:42:25'),(55,18,1,170,'TICKET_DICE',1,'2026-01-02 12:42:34'),(56,18,1,169,'TICKET_ROULETTE',1,'2026-01-02 12:42:42'),(57,18,1,170,'TICKET_DICE',1,'2026-01-02 12:42:49'),(58,18,1,173,'NONE',0,'2026-01-02 12:43:03'),(59,13,1,170,'TICKET_DICE',1,'2026-01-02 12:58:32'),(60,13,1,170,'TICKET_DICE',1,'2026-01-02 12:58:42'),(61,19,1,172,'TICKET_ROULETTE',2,'2026-01-02 13:20:00'),(62,19,1,174,'NONE',1,'2026-01-02 13:20:11'),(63,19,1,171,'TICKET_LOTTERY',1,'2026-01-02 13:20:21'),(64,19,1,172,'TICKET_ROULETTE',2,'2026-01-02 13:20:26'),(65,19,1,172,'TICKET_ROULETTE',2,'2026-01-02 13:20:37'),(66,19,1,173,'NONE',0,'2026-01-02 13:20:51'),(67,19,1,170,'TICKET_DICE',1,'2026-01-02 13:21:01'),(68,19,1,173,'NONE',0,'2026-01-02 13:21:13'),(69,18,1,173,'NONE',0,'2026-01-02 13:26:22'),(70,18,1,171,'TICKET_LOTTERY',1,'2026-01-02 13:26:26'),(71,18,1,173,'NONE',0,'2026-01-02 13:26:32'),(72,18,1,173,'NONE',0,'2026-01-02 13:26:39'),(73,18,1,170,'TICKET_DICE',1,'2026-01-02 13:26:43'),(74,19,1,172,'TICKET_ROULETTE',2,'2026-01-02 13:36:22'),(75,7,1,169,'TICKET_ROULETTE',1,'2026-01-02 13:52:20'),(76,20,1,169,'TICKET_ROULETTE',1,'2026-01-02 16:45:56'),(77,20,1,170,'TICKET_DICE',1,'2026-01-02 16:46:00'),(78,20,1,172,'TICKET_ROULETTE',2,'2026-01-02 16:46:08'),(79,20,1,170,'TICKET_DICE',1,'2026-01-02 16:46:16'),(80,20,1,170,'TICKET_DICE',1,'2026-01-02 16:46:23'),(81,20,1,170,'TICKET_DICE',1,'2026-01-02 16:46:36'),(83,20,3,163,'POINT',20000,'2026-01-02 16:47:02'),(84,7,1,170,'TICKET_DICE',1,'2026-01-03 01:43:35'),(85,9,1,170,'TICKET_DICE',1,'2026-01-03 02:16:42'),(86,13,1,170,'TICKET_DICE',1,'2026-01-03 03:02:37'),(87,16,1,170,'TICKET_DICE',1,'2026-01-03 03:37:35'),(88,16,1,170,'TICKET_DICE',1,'2026-01-03 03:37:40'),(89,27,1,170,'TICKET_DICE',1,'2026-01-03 05:32:36'),(90,27,1,169,'TICKET_ROULETTE',1,'2026-01-03 05:32:45'),(91,27,1,172,'TICKET_ROULETTE',2,'2026-01-03 05:32:50'),(92,27,1,170,'TICKET_DICE',1,'2026-01-03 05:32:58'),(93,27,1,170,'TICKET_DICE',1,'2026-01-03 05:33:07'),(94,27,1,172,'TICKET_ROULETTE',2,'2026-01-03 05:35:44'),(95,26,1,169,'TICKET_ROULETTE',1,'2026-01-03 05:39:07'),(96,26,1,171,'TICKET_LOTTERY',1,'2026-01-03 05:39:20'),(97,30,1,172,'TICKET_ROULETTE',2,'2026-01-03 07:56:00'),(98,30,1,172,'TICKET_ROULETTE',2,'2026-01-03 07:56:15'),(99,30,1,170,'TICKET_DICE',1,'2026-01-03 07:56:23'),(100,30,1,170,'TICKET_DICE',1,'2026-01-03 07:56:36'),(101,30,1,172,'TICKET_ROULETTE',2,'2026-01-03 07:56:44'),(102,30,1,173,'NONE',0,'2026-01-03 07:56:55'),(103,30,1,169,'TICKET_ROULETTE',1,'2026-01-03 07:57:04'),(104,30,1,172,'TICKET_ROULETTE',2,'2026-01-03 07:57:13'),(105,30,1,171,'TICKET_LOTTERY',1,'2026-01-03 07:57:21'),(106,30,1,171,'TICKET_LOTTERY',1,'2026-01-03 07:57:32'),(107,30,1,170,'TICKET_DICE',1,'2026-01-03 07:57:41'),(108,30,1,170,'TICKET_DICE',1,'2026-01-03 07:57:53'),(109,30,1,170,'TICKET_DICE',1,'2026-01-03 07:57:59'),(110,30,1,169,'TICKET_ROULETTE',1,'2026-01-03 07:58:06'),(111,30,1,171,'TICKET_LOTTERY',1,'2026-01-03 07:58:14'),(112,30,1,171,'TICKET_LOTTERY',1,'2026-01-03 07:58:22'),(113,30,1,173,'NONE',0,'2026-01-03 07:58:30'),(115,29,1,169,'TICKET_ROULETTE',1,'2026-01-03 08:04:22'),(116,29,1,171,'TICKET_LOTTERY',1,'2026-01-03 08:04:28'),(117,29,1,170,'TICKET_DICE',1,'2026-01-03 08:04:36'),(118,29,1,172,'TICKET_ROULETTE',2,'2026-01-03 08:04:45'),(119,29,1,169,'TICKET_ROULETTE',1,'2026-01-03 08:04:53'),(120,29,1,169,'TICKET_ROULETTE',1,'2026-01-03 08:05:00'),(121,29,1,171,'TICKET_LOTTERY',1,'2026-01-03 08:05:07'),(122,29,1,172,'TICKET_ROULETTE',2,'2026-01-03 08:05:15'),(123,29,1,170,'TICKET_DICE',1,'2026-01-03 08:05:22'),(124,29,1,170,'TICKET_DICE',1,'2026-01-03 08:05:30'),(125,29,1,170,'TICKET_DICE',1,'2026-01-03 08:05:38'),(126,29,1,170,'TICKET_DICE',1,'2026-01-03 08:05:45'),(127,29,1,172,'TICKET_ROULETTE',2,'2026-01-03 08:05:52'),(128,29,1,171,'TICKET_LOTTERY',1,'2026-01-03 08:06:00'),(129,29,1,171,'TICKET_LOTTERY',1,'2026-01-03 08:06:08'),(130,29,1,173,'NONE',0,'2026-01-03 08:06:15'),(131,29,1,170,'TICKET_DICE',1,'2026-01-03 08:08:22'),(132,29,1,171,'TICKET_LOTTERY',1,'2026-01-03 08:08:27'),(133,29,1,170,'TICKET_DICE',1,'2026-01-03 08:09:20');
/*!40000 ALTER TABLE `roulette_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roulette_segment`
--

DROP TABLE IF EXISTS `roulette_segment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roulette_segment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_id` int NOT NULL,
  `slot_index` int NOT NULL,
  `label` varchar(50) NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `weight` int NOT NULL,
  `is_jackpot` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roulette_segment_slot` (`config_id`,`slot_index`),
  KEY `ix_roulette_segment_id` (`id`),
  CONSTRAINT `roulette_segment_ibfk_1` FOREIGN KEY (`config_id`) REFERENCES `roulette_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_roulette_segment_slot_range` CHECK (((`slot_index` >= 0) and (`slot_index` <= 5))),
  CONSTRAINT `ck_roulette_segment_weight_non_negative` CHECK ((`weight` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roulette_segment`
--

LOCK TABLES `roulette_segment` WRITE;
/*!40000 ALTER TABLE `roulette_segment` DISABLE KEYS */;
INSERT INTO `roulette_segment` VALUES (163,3,0,'20000원','POINT',20000,900,0,'2026-01-01 07:02:28','2026-01-01 07:02:28'),(164,3,1,'10000원','POINT',10000,1500,0,'2026-01-01 07:02:28','2026-01-01 07:02:28'),(165,3,2,'30000원','POINT',10000,400,0,'2026-01-01 07:02:28','2026-01-01 07:02:28'),(166,3,3,'50000원','POINT',50000,15,0,'2026-01-01 07:02:28','2026-01-01 07:02:28'),(167,3,4,'70000원','POINT',70000,1,0,'2026-01-01 07:02:28','2026-01-01 07:02:28'),(168,3,5,'10000원','POINT',10000,1200,0,'2026-01-01 07:02:28','2026-01-01 07:02:28'),(169,1,0,'룰렛티켓1장','TICKET_ROULETTE',1,300,0,'2026-01-01 08:22:59','2026-01-01 08:22:59'),(170,1,1,'주사위티켓1장','TICKET_DICE',1,500,0,'2026-01-01 08:22:59','2026-01-01 08:22:59'),(171,1,2,'복권티켓1장','TICKET_LOTTERY',1,150,0,'2026-01-01 08:22:59','2026-01-01 08:22:59'),(172,1,3,'룰렛티켓2장','TICKET_ROULETTE',2,200,0,'2026-01-01 08:22:59','2026-01-01 08:22:59'),(173,1,4,'꽝','NONE',0,250,0,'2026-01-01 08:22:59','2026-01-01 08:22:59'),(174,1,5,'씨씨코인','NONE',1,4,0,'2026-01-01 08:22:59','2026-01-01 08:22:59'),(175,2,0,'10000원','POINT',10000,250,0,'2026-01-03 08:04:37','2026-01-03 08:04:37'),(176,2,1,'5000원','POINT',5000,550,0,'2026-01-03 08:04:37','2026-01-03 08:04:37'),(177,2,2,'30000원','POINT',30000,60,0,'2026-01-03 08:04:37','2026-01-03 08:04:37'),(178,2,3,'20000원','POINT',20000,150,0,'2026-01-03 08:04:37','2026-01-03 08:04:37'),(179,2,4,'10000원','POINT',10000,440,0,'2026-01-03 08:04:37','2026-01-03 08:04:37'),(180,2,5,'50000원','POINT',50000,1,0,'2026-01-03 08:04:37','2026-01-03 08:04:37');
/*!40000 ALTER TABLE `roulette_segment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_pass_config`
--

DROP TABLE IF EXISTS `season_pass_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `season_pass_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `season_name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `max_level` int NOT NULL,
  `base_xp_per_stamp` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_season_name` (`season_name`),
  KEY `ix_season_pass_config_start_date` (`start_date`),
  KEY `ix_season_pass_config_end_date` (`end_date`),
  KEY `ix_season_pass_config_is_active` (`is_active`),
  KEY `ix_season_pass_config_id` (`id`),
  CONSTRAINT `ck_season_dates_order` CHECK ((`start_date` <= `end_date`))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `season_pass_config`
--

LOCK TABLES `season_pass_config` WRITE;
/*!40000 ALTER TABLE `season_pass_config` DISABLE KEYS */;
INSERT INTO `season_pass_config` VALUES (1,'2026001','2026-01-01','2026-01-31',20,20,1,'2026-01-01 01:00:58','2026-01-01 01:11:29');
/*!40000 ALTER TABLE `season_pass_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_pass_level`
--

DROP TABLE IF EXISTS `season_pass_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `season_pass_level` (
  `id` int NOT NULL AUTO_INCREMENT,
  `season_id` int NOT NULL,
  `level` int NOT NULL,
  `required_xp` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `auto_claim` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_season_level` (`season_id`,`level`),
  KEY `ix_season_pass_level_id` (`id`),
  CONSTRAINT `season_pass_level_ibfk_1` FOREIGN KEY (`season_id`) REFERENCES `season_pass_config` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `season_pass_level`
--

LOCK TABLES `season_pass_level` WRITE;
/*!40000 ALTER TABLE `season_pass_level` DISABLE KEYS */;
INSERT INTO `season_pass_level` VALUES (1,1,1,0,'TICKET_ROULETTE',1,1,'2026-01-01 01:00:58','2026-01-01 11:26:43'),(2,1,2,20,'TICKET_DICE',1,1,'2026-01-01 01:00:58','2026-01-02 22:11:06'),(3,1,3,50,'TICKET_ROULETTE',2,1,'2026-01-01 01:00:58','2026-01-02 22:11:06'),(4,1,4,60,'TICKET_LOTTERY',1,1,'2026-01-01 01:00:58','2026-01-02 22:11:34'),(5,1,5,80,'TICKET_LOTTERY',2,1,'2026-01-01 01:00:58','2026-01-03 17:09:48'),(6,1,6,100,'POINT',5000,0,'2026-01-01 11:26:43','2026-01-01 15:56:29'),(7,1,7,150,'TICKET_DICE',3,1,'2026-01-01 11:26:43','2026-01-01 15:58:11'),(8,1,8,200,'TICKET_ROULETTE',3,1,'2026-01-01 11:26:43','2026-01-01 15:54:29'),(9,1,9,300,'TICKET_LOTTERY',4,1,'2026-01-01 11:26:43','2026-01-03 17:10:21'),(10,1,10,400,'GOLD_KEY',1,1,'2026-01-01 11:26:43','2026-01-03 17:10:21'),(11,1,11,600,'POINT',10000,0,'2026-01-01 11:26:43','2026-01-01 15:56:29'),(12,1,12,800,'DIAMOND_KEY',1,1,'2026-01-01 11:26:43','2026-01-01 15:56:29'),(13,1,13,1100,'TICKET_DICE',5,1,'2026-01-01 11:26:43','2026-01-01 15:58:57'),(14,1,14,1400,'TICKET_BUNDLE',20000,0,'2026-01-01 11:26:43','2026-01-01 15:58:57'),(15,1,15,1800,'TICKET_ROULETTE',7,1,'2026-01-01 11:26:43','2026-01-01 15:58:57'),(16,1,16,2200,'TICKET_LOTTERY',10,1,'2026-01-01 11:26:43','2026-01-01 15:59:17'),(17,1,17,3000,'TICKET_BUNDLE',30000,0,'2026-01-01 11:26:43','2026-01-01 16:00:03'),(18,1,18,4000,'POINT',50000,0,'2026-01-01 11:26:43','2026-01-01 16:00:03'),(19,1,19,5000,'GOLD_KEY',3,1,'2026-01-01 11:26:43','2026-01-01 11:26:43'),(20,1,20,6000,'TICKET_BUNDLE',100000,0,'2026-01-01 11:26:43','2026-01-01 16:00:03');
/*!40000 ALTER TABLE `season_pass_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_pass_progress`
--

DROP TABLE IF EXISTS `season_pass_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `season_pass_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `season_id` int NOT NULL,
  `current_level` int NOT NULL,
  `current_xp` int NOT NULL,
  `total_stamps` int NOT NULL,
  `last_stamp_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_season_progress` (`user_id`,`season_id`),
  KEY `season_id` (`season_id`),
  KEY `ix_season_pass_progress_id` (`id`),
  CONSTRAINT `season_pass_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `season_pass_progress_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `season_pass_config` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `season_pass_progress`
--

LOCK TABLES `season_pass_progress` WRITE;
/*!40000 ALTER TABLE `season_pass_progress` DISABLE KEYS */;
INSERT INTO `season_pass_progress` VALUES (6,9,1,1,0,0,NULL,'2026-01-01 12:19:58','2026-01-01 12:19:58'),(7,7,1,2,20,1,'2026-01-03','2026-01-01 13:17:53','2026-01-03 08:35:54'),(10,12,1,4,60,1,'2026-01-03','2026-01-02 13:41:17','2026-01-03 08:34:44'),(11,13,1,1,0,0,NULL,'2026-01-02 16:50:50','2026-01-02 16:50:50'),(12,16,1,1,0,0,NULL,'2026-01-02 21:06:49','2026-01-02 21:06:49'),(13,17,1,5,80,1,'2026-01-03','2026-01-02 21:12:34','2026-01-03 08:32:46'),(14,18,1,4,60,1,'2026-01-02','2026-01-02 21:39:50','2026-01-02 22:45:26'),(15,15,1,1,0,0,NULL,'2026-01-02 22:18:58','2026-01-02 22:18:58'),(16,19,1,1,0,0,NULL,'2026-01-02 22:19:19','2026-01-02 22:19:19'),(17,14,1,1,0,0,NULL,'2026-01-02 22:19:21','2026-01-02 22:19:21'),(18,20,1,1,0,0,NULL,'2026-01-03 01:44:21','2026-01-03 01:44:21'),(19,21,1,1,0,0,NULL,'2026-01-03 08:04:04','2026-01-03 08:04:04'),(20,22,1,1,0,0,NULL,'2026-01-03 08:40:49','2026-01-03 08:40:49'),(23,23,1,1,0,0,NULL,'2026-01-03 10:44:17','2026-01-03 10:44:17'),(26,24,1,4,60,1,'2026-01-03','2026-01-03 11:42:55','2026-01-03 13:57:37'),(31,25,1,1,0,0,NULL,'2026-01-03 12:31:34','2026-01-03 12:31:34'),(32,26,1,1,0,0,NULL,'2026-01-03 12:54:56','2026-01-03 12:54:56'),(35,27,1,2,40,1,'2026-01-03','2026-01-03 14:30:31','2026-01-03 16:25:59'),(38,29,1,2,40,1,'2026-01-03','2026-01-03 16:55:09','2026-01-03 16:57:32'),(39,30,1,4,60,1,'2026-01-03','2026-01-03 16:55:16','2026-01-03 16:57:40');
/*!40000 ALTER TABLE `season_pass_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_pass_reward_log`
--

DROP TABLE IF EXISTS `season_pass_reward_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `season_pass_reward_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `season_id` int NOT NULL,
  `progress_id` int DEFAULT NULL,
  `level` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `claimed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reward_user_season_level` (`user_id`,`season_id`,`level`),
  KEY `season_id` (`season_id`),
  KEY `progress_id` (`progress_id`),
  KEY `ix_season_pass_reward_log_id` (`id`),
  CONSTRAINT `season_pass_reward_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `season_pass_reward_log_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `season_pass_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `season_pass_reward_log_ibfk_3` FOREIGN KEY (`progress_id`) REFERENCES `season_pass_progress` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `season_pass_reward_log`
--

LOCK TABLES `season_pass_reward_log` WRITE;
/*!40000 ALTER TABLE `season_pass_reward_log` DISABLE KEYS */;
INSERT INTO `season_pass_reward_log` VALUES (8,9,1,6,1,'TICKET_ROULETTE',1,'2026-01-01 03:19:58','2026-01-01 12:19:58'),(9,7,1,7,1,'TICKET_ROULETTE',1,'2026-01-01 04:17:54','2026-01-01 13:17:53'),(15,12,1,10,1,'TICKET_ROULETTE',1,'2026-01-02 04:41:17','2026-01-02 13:41:17'),(16,13,1,11,1,'TICKET_ROULETTE',1,'2026-01-02 07:50:51','2026-01-02 16:50:51'),(17,16,1,12,1,'TICKET_ROULETTE',1,'2026-01-02 12:06:50','2026-01-02 21:06:49'),(18,17,1,13,1,'TICKET_ROULETTE',1,'2026-01-02 12:12:34','2026-01-02 21:12:34'),(19,18,1,14,1,'TICKET_ROULETTE',1,'2026-01-02 12:39:51','2026-01-02 21:39:50'),(20,18,1,14,2,'TICKET_DICE',1,'2026-01-02 13:02:42','2026-01-02 22:02:41'),(21,18,1,14,3,'TICKET_ROULETTE',2,'2026-01-02 13:02:42','2026-01-02 22:02:41'),(22,18,1,14,4,'TICKET_LOTTERY',1,'2026-01-02 13:02:42','2026-01-02 22:02:41'),(23,19,1,16,1,'TICKET_ROULETTE',1,'2026-01-02 13:19:20','2026-01-02 22:19:19'),(24,14,1,17,1,'TICKET_ROULETTE',1,'2026-01-02 13:22:37','2026-01-02 22:22:37'),(25,20,1,18,1,'TICKET_ROULETTE',1,'2026-01-02 16:44:22','2026-01-03 01:44:21'),(26,21,1,19,1,'TICKET_ROULETTE',1,'2026-01-02 23:04:04','2026-01-03 08:04:04'),(27,17,1,13,2,'TICKET_DICE',1,'2026-01-02 23:32:46','2026-01-03 08:32:45'),(28,17,1,13,3,'TICKET_ROULETTE',2,'2026-01-02 23:32:46','2026-01-03 08:32:45'),(29,17,1,13,4,'TICKET_LOTTERY',1,'2026-01-02 23:32:46','2026-01-03 08:32:46'),(30,17,1,13,5,'GOLD_KEY',1,'2026-01-02 23:32:46','2026-01-03 08:32:46'),(31,12,1,10,2,'TICKET_DICE',1,'2026-01-02 23:34:44','2026-01-03 08:34:43'),(32,12,1,10,3,'TICKET_ROULETTE',2,'2026-01-02 23:34:44','2026-01-03 08:34:44'),(33,12,1,10,4,'TICKET_LOTTERY',1,'2026-01-02 23:34:44','2026-01-03 08:34:44'),(34,7,1,7,2,'TICKET_DICE',1,'2026-01-02 23:35:54','2026-01-03 08:35:54'),(35,24,1,26,1,'TICKET_ROULETTE',1,'2026-01-03 02:42:56','2026-01-03 11:42:55'),(36,24,1,26,2,'TICKET_DICE',1,'2026-01-03 02:49:59','2026-01-03 11:49:59'),(37,24,1,26,3,'TICKET_ROULETTE',2,'2026-01-03 02:50:00','2026-01-03 11:50:00'),(38,24,1,26,4,'TICKET_LOTTERY',1,'2026-01-03 02:50:00','2026-01-03 11:50:00'),(39,25,1,31,1,'TICKET_ROULETTE',1,'2026-01-03 03:31:34','2026-01-03 12:31:34'),(40,26,1,32,1,'TICKET_ROULETTE',1,'2026-01-03 03:54:57','2026-01-03 12:54:57'),(41,27,1,35,1,'TICKET_ROULETTE',1,'2026-01-03 05:30:32','2026-01-03 14:30:31'),(42,27,1,35,2,'TICKET_DICE',1,'2026-01-03 07:25:59','2026-01-03 16:25:59'),(43,29,1,38,1,'TICKET_ROULETTE',1,'2026-01-03 07:55:10','2026-01-03 16:55:10'),(44,30,1,39,1,'TICKET_ROULETTE',1,'2026-01-03 07:55:17','2026-01-03 16:55:16'),(45,30,1,39,2,'TICKET_DICE',1,'2026-01-03 07:57:00','2026-01-03 16:56:59'),(46,30,1,39,3,'TICKET_ROULETTE',2,'2026-01-03 07:57:00','2026-01-03 16:56:59'),(47,30,1,39,4,'TICKET_LOTTERY',1,'2026-01-03 07:57:00','2026-01-03 16:56:59'),(48,30,1,39,5,'GOLD_KEY',1,'2026-01-03 07:57:00','2026-01-03 16:57:00'),(49,29,1,38,2,'TICKET_DICE',1,'2026-01-03 07:57:13','2026-01-03 16:57:13'),(50,29,1,38,3,'TICKET_ROULETTE',2,'2026-01-03 07:57:14','2026-01-03 16:57:13'),(51,29,1,38,4,'TICKET_LOTTERY',1,'2026-01-03 07:57:14','2026-01-03 16:57:13');
/*!40000 ALTER TABLE `season_pass_reward_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `season_pass_stamp_log`
--

DROP TABLE IF EXISTS `season_pass_stamp_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `season_pass_stamp_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `season_id` int NOT NULL,
  `progress_id` int DEFAULT NULL,
  `date` date NOT NULL,
  `period_key` varchar(32) NOT NULL,
  `stamp_count` int NOT NULL,
  `source_feature_type` varchar(30) NOT NULL,
  `xp_earned` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_amount` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stamp_user_season_period` (`user_id`,`season_id`,`source_feature_type`,`period_key`),
  KEY `season_id` (`season_id`),
  KEY `progress_id` (`progress_id`),
  KEY `ix_season_pass_stamp_log_id` (`id`),
  CONSTRAINT `season_pass_stamp_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `season_pass_stamp_log_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `season_pass_config` (`id`) ON DELETE CASCADE,
  CONSTRAINT `season_pass_stamp_log_ibfk_3` FOREIGN KEY (`progress_id`) REFERENCES `season_pass_progress` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `season_pass_stamp_log`
--

LOCK TABLES `season_pass_stamp_log` WRITE;
/*!40000 ALTER TABLE `season_pass_stamp_log` DISABLE KEYS */;
INSERT INTO `season_pass_stamp_log` VALUES (3,18,1,14,'2026-01-02','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-02 22:02:42'),(4,17,1,13,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 08:32:46'),(5,12,1,10,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 08:34:44'),(6,7,1,7,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 08:35:54'),(7,24,1,26,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 11:50:00'),(8,27,1,35,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 16:25:59'),(9,30,1,39,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 16:57:00'),(10,29,1,38,'2026-01-03','TOP10_W2026-01',1,'EXTERNAL_RANKING_TOP10',20,'XP',20,'2026-01-03 16:57:13');
/*!40000 ALTER TABLE `season_pass_stamp_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `segment_rule`
--

DROP TABLE IF EXISTS `segment_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `segment_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `segment` varchar(50) NOT NULL,
  `priority` int NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `condition_json` json NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_segment_rule_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `segment_rule`
--

LOCK TABLES `segment_rule` WRITE;
/*!40000 ALTER TABLE `segment_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `segment_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `description` text,
  `status` enum('DRAFT','ACTIVE','PAUSED','ARCHIVED') NOT NULL,
  `channel` enum('GLOBAL','SEASON_PASS','ROULETTE','DICE','LOTTERY','TEAM_BATTLE') NOT NULL,
  `target_segment_json` json DEFAULT NULL,
  `reward_json` json DEFAULT NULL,
  `auto_launch` tinyint(1) NOT NULL,
  `start_at` datetime DEFAULT NULL,
  `end_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `survey_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_option`
--

DROP TABLE IF EXISTS `survey_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_option` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `value` varchar(100) NOT NULL,
  `label` varchar(150) NOT NULL,
  `order_index` int NOT NULL,
  `weight` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `survey_option_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `survey_question` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_option`
--

LOCK TABLES `survey_option` WRITE;
/*!40000 ALTER TABLE `survey_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_question`
--

DROP TABLE IF EXISTS `survey_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_question` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `order_index` int NOT NULL,
  `randomize_group` varchar(50) DEFAULT NULL,
  `question_type` enum('SINGLE_CHOICE','MULTI_CHOICE','LIKERT','TEXT','NUMBER') NOT NULL,
  `title` varchar(255) NOT NULL,
  `helper_text` varchar(255) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL,
  `config_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_survey_question_order` (`survey_id`,`order_index`),
  CONSTRAINT `survey_question_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_question`
--

LOCK TABLES `survey_question` WRITE;
/*!40000 ALTER TABLE `survey_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_response`
--

DROP TABLE IF EXISTS `survey_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_response` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `user_id` int NOT NULL,
  `trigger_rule_id` int DEFAULT NULL,
  `status` enum('PENDING','IN_PROGRESS','COMPLETED','DROPPED','EXPIRED') NOT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `dropped_at` datetime DEFAULT NULL,
  `reward_status` enum('NONE','SCHEDULED','GRANTED','FAILED') NOT NULL,
  `reward_payload` json DEFAULT NULL,
  `last_question_id` int DEFAULT NULL,
  `last_activity_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_id` (`survey_id`),
  KEY `user_id` (`user_id`),
  KEY `trigger_rule_id` (`trigger_rule_id`),
  KEY `last_question_id` (`last_question_id`),
  CONSTRAINT `survey_response_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_response_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_response_ibfk_3` FOREIGN KEY (`trigger_rule_id`) REFERENCES `survey_trigger_rule` (`id`) ON DELETE SET NULL,
  CONSTRAINT `survey_response_ibfk_4` FOREIGN KEY (`last_question_id`) REFERENCES `survey_question` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ck_survey_reward_status` CHECK ((`reward_status` in (_utf8mb4'NONE',_utf8mb4'SCHEDULED',_utf8mb4'GRANTED',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_response`
--

LOCK TABLES `survey_response` WRITE;
/*!40000 ALTER TABLE `survey_response` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_response_answer`
--

DROP TABLE IF EXISTS `survey_response_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_response_answer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `response_id` int NOT NULL,
  `question_id` int NOT NULL,
  `option_id` int DEFAULT NULL,
  `answer_text` text,
  `answer_number` int DEFAULT NULL,
  `meta_json` json DEFAULT NULL,
  `answered_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_response_question` (`response_id`,`question_id`),
  KEY `question_id` (`question_id`),
  KEY `option_id` (`option_id`),
  CONSTRAINT `survey_response_answer_ibfk_1` FOREIGN KEY (`response_id`) REFERENCES `survey_response` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_response_answer_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `survey_question` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_response_answer_ibfk_3` FOREIGN KEY (`option_id`) REFERENCES `survey_option` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_response_answer`
--

LOCK TABLES `survey_response_answer` WRITE;
/*!40000 ALTER TABLE `survey_response_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_response_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_trigger_rule`
--

DROP TABLE IF EXISTS `survey_trigger_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_trigger_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `trigger_type` enum('LEVEL_UP','INACTIVE_DAYS','GAME_RESULT','MANUAL_PUSH') NOT NULL,
  `trigger_config_json` json DEFAULT NULL,
  `priority` int NOT NULL,
  `cooldown_hours` int NOT NULL,
  `max_per_user` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_id` (`survey_id`),
  CONSTRAINT `survey_trigger_rule_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `survey` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_trigger_rule`
--

LOCK TABLES `survey_trigger_rule` WRITE;
/*!40000 ALTER TABLE `survey_trigger_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_trigger_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_name` (`name`),
  KEY `ix_team_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_event_log`
--

DROP TABLE IF EXISTS `team_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_event_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `season_id` int NOT NULL,
  `action` varchar(50) NOT NULL,
  `delta` int NOT NULL,
  `meta` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `team_id` (`team_id`),
  KEY `idx_tel_season_team` (`season_id`,`team_id`,`created_at`),
  KEY `idx_tel_user` (`user_id`),
  CONSTRAINT `team_event_log_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`) ON DELETE CASCADE,
  CONSTRAINT `team_event_log_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `team_event_log_ibfk_3` FOREIGN KEY (`season_id`) REFERENCES `team_season` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_event_log`
--

LOCK TABLES `team_event_log` WRITE;
/*!40000 ALTER TABLE `team_event_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_member`
--

DROP TABLE IF EXISTS `team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_member` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `team_id` int NOT NULL,
  `role` varchar(10) NOT NULL,
  `joined_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `idx_team_member_team` (`team_id`),
  CONSTRAINT `team_member_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_member`
--

LOCK TABLES `team_member` WRITE;
/*!40000 ALTER TABLE `team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_score`
--

DROP TABLE IF EXISTS `team_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_score` (
  `team_id` int NOT NULL,
  `season_id` int NOT NULL,
  `points` bigint NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`team_id`,`season_id`),
  UNIQUE KEY `uq_team_score` (`team_id`,`season_id`),
  KEY `idx_team_score_points` (`season_id`,`points`),
  CONSTRAINT `team_score_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`) ON DELETE CASCADE,
  CONSTRAINT `team_score_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `team_season` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_score`
--

LOCK TABLES `team_score` WRITE;
/*!40000 ALTER TABLE `team_score` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_season`
--

DROP TABLE IF EXISTS `team_season`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_season` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `rewards_schema` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_season_name` (`name`),
  KEY `ix_team_season_id` (`id`),
  KEY `idx_team_season_time` (`starts_at`,`ends_at`),
  KEY `idx_team_season_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_season`
--

LOCK TABLES `team_season` WRITE;
/*!40000 ALTER TABLE `team_season` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_season` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_link_code`
--

DROP TABLE IF EXISTS `telegram_link_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telegram_link_code` (
  `code` varchar(16) NOT NULL,
  `user_id` int NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `client_ip` varchar(50) DEFAULT NULL,
  `user_agent` text,
  PRIMARY KEY (`code`),
  KEY `ix_telegram_link_code_code` (`code`),
  KEY `ix_telegram_link_code_user_id` (`user_id`),
  CONSTRAINT `telegram_link_code_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_link_code`
--

LOCK TABLES `telegram_link_code` WRITE;
/*!40000 ALTER TABLE `telegram_link_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_link_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trial_token_bucket`
--

DROP TABLE IF EXISTS `trial_token_bucket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trial_token_bucket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_type` enum('ROULETTE_COIN','DICE_TOKEN','LOTTERY_TICKET','CC_COIN','GOLD_KEY','DIAMOND_KEY','DIAMOND') NOT NULL,
  `balance` int NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_trial_token_bucket_user_token` (`user_id`,`token_type`),
  KEY `ix_trial_token_bucket_user_id` (`user_id`),
  KEY `ix_trial_token_bucket_id` (`id`),
  CONSTRAINT `trial_token_bucket_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trial_token_bucket`
--

LOCK TABLES `trial_token_bucket` WRITE;
/*!40000 ALTER TABLE `trial_token_bucket` DISABLE KEYS */;
INSERT INTO `trial_token_bucket` VALUES (11,9,'ROULETTE_COIN',0,'2026-01-03 02:16:42'),(12,9,'DICE_TOKEN',0,'2026-01-03 02:16:31'),(13,7,'ROULETTE_COIN',0,'2026-01-03 01:43:35'),(14,7,'LOTTERY_TICKET',0,'2026-01-03 01:43:49'),(15,17,'DICE_TOKEN',0,'2026-01-02 12:13:24'),(16,17,'ROULETTE_COIN',0,'2026-01-02 12:14:30'),(17,17,'LOTTERY_TICKET',0,'2026-01-02 12:15:29'),(18,18,'ROULETTE_COIN',0,'2026-01-02 12:43:03'),(19,13,'ROULETTE_COIN',0,'2026-01-03 03:02:37'),(20,13,'DICE_TOKEN',0,'2026-01-03 03:03:41'),(21,19,'ROULETTE_COIN',0,'2026-01-02 13:36:22'),(22,19,'LOTTERY_TICKET',0,'2026-01-02 13:27:06'),(23,19,'DICE_TOKEN',0,'2026-01-02 13:37:59'),(24,7,'DICE_TOKEN',0,'2026-01-03 01:43:22'),(25,13,'LOTTERY_TICKET',0,'2026-01-03 03:03:53'),(26,20,'DICE_TOKEN',0,'2026-01-02 16:45:21'),(27,20,'ROULETTE_COIN',0,'2026-01-02 16:46:36'),(28,20,'GOLD_KEY',0,'2026-01-02 16:46:45'),(29,20,'DIAMOND_KEY',0,'2026-01-02 16:47:02'),(30,20,'LOTTERY_TICKET',0,'2026-01-02 16:53:03'),(31,9,'LOTTERY_TICKET',0,'2026-01-03 02:17:13'),(32,16,'LOTTERY_TICKET',0,'2026-01-03 03:36:27'),(33,16,'DICE_TOKEN',0,'2026-01-03 03:36:58'),(34,16,'ROULETTE_COIN',0,'2026-01-03 03:37:35'),(35,27,'DICE_TOKEN',0,'2026-01-03 05:31:54'),(36,27,'ROULETTE_COIN',0,'2026-01-03 05:35:44'),(37,27,'LOTTERY_TICKET',0,'2026-01-03 05:35:16'),(38,26,'LOTTERY_TICKET',1,'2026-01-03 05:35:13'),(39,26,'ROULETTE_COIN',0,'2026-01-03 05:39:07'),(40,30,'ROULETTE_COIN',0,'2026-01-03 07:56:00'),(41,30,'GOLD_KEY',0,'2026-01-03 07:59:29'),(42,29,'LOTTERY_TICKET',0,'2026-01-03 08:02:30'),(43,29,'DICE_TOKEN',0,'2026-01-03 08:04:01'),(44,29,'ROULETTE_COIN',0,'2026-01-03 08:09:19');
/*!40000 ALTER TABLE `trial_token_bucket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `external_id` varchar(100) NOT NULL,
  `nickname` varchar(100) DEFAULT NULL,
  `password_hash` varchar(128) DEFAULT NULL,
  `level` int NOT NULL DEFAULT '1',
  `xp` int NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `vault_balance` int NOT NULL DEFAULT '0',
  `vault_locked_balance` int NOT NULL DEFAULT '0',
  `vault_available_balance` int NOT NULL DEFAULT '0',
  `vault_locked_expires_at` datetime DEFAULT NULL,
  `cash_balance` int NOT NULL DEFAULT '0',
  `vault_fill_used_at` datetime DEFAULT NULL,
  `next_season_seed` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `diamond_key_count` int NOT NULL DEFAULT '0',
  `last_free_ticket_claimed_at` datetime DEFAULT NULL,
  `has_completed_onboarding` tinyint(1) DEFAULT NULL,
  `telegram_id` bigint DEFAULT NULL,
  `telegram_username` varchar(100) DEFAULT NULL,
  `telegram_is_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `telegram_join_count` int NOT NULL DEFAULT '0',
  `first_login_at` datetime DEFAULT NULL,
  `telegram_link_nonce` varchar(64) DEFAULT NULL,
  `telegram_link_nonce_expires_at` datetime DEFAULT NULL,
  `total_charge_amount` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `external_id` (`external_id`),
  UNIQUE KEY `ix_user_telegram_id` (`telegram_id`),
  KEY `ix_user_nickname` (`nickname`),
  KEY `ix_user_id` (`id`),
  KEY `ix_user_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'admin','Admin','03e59d56734f443d81e9f244ef89dbc1e3f9a6951c96733be15d2a144f04d5d2',1,0,'ACTIVE','2026-01-03 07:28:38','172.18.0.8',0,0,0,NULL,0,NULL,0,'2025-12-31 16:10:41','2026-01-03 07:28:38',0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0),(7,'tg_6085974841_9660ff34','percipic',NULL,2,20,'ACTIVE','2026-01-02 13:49:39',NULL,1500,1500,0,NULL,0,NULL,0,'2026-01-01 01:58:24','2026-01-03 01:43:49',0,NULL,0,6085974841,'percipic',0,2,'2026-01-01 01:58:24',NULL,NULL,0),(9,'tg_2049846755_d36896d2','tg_user_2049846755',NULL,1,0,'ACTIVE','2026-01-02 05:00:04',NULL,1450,1450,0,NULL,0,NULL,0,'2026-01-01 03:19:33','2026-01-03 02:17:13',0,NULL,0,2049846755,NULL,0,2,'2026-01-01 03:19:33',NULL,NULL,0),(12,'tg_1387125026_681b52c2','봄꽃잎',NULL,4,60,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-02 04:38:51','2026-01-02 23:37:04',0,NULL,0,1387125026,'봄꽃잎',0,1,'2026-01-02 04:38:51',NULL,NULL,0),(13,'tg_7711588195_c2428a27','mumuing',NULL,1,0,'ACTIVE','2026-01-03 04:51:21',NULL,2700,2700,0,NULL,0,NULL,0,'2026-01-02 07:50:48','2026-01-03 04:51:21',0,NULL,0,7711588195,'mumuing',0,4,'2026-01-02 07:50:48',NULL,NULL,0),(14,'tg_8157048749_2c8ec2e5','초보베터',NULL,1,0,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-02 11:58:28','2026-01-02 23:39:27',0,NULL,0,8157048749,'kkh9281',0,1,'2026-01-02 11:58:28',NULL,NULL,0),(15,'tg_5240054244_70bbbc00','돈머니돈',NULL,1,0,'ACTIVE','2026-01-02 11:58:50',NULL,0,0,0,NULL,0,NULL,0,'2026-01-02 11:58:28','2026-01-02 23:38:53',0,NULL,0,5240054244,'Skxnww',0,2,'2026-01-02 11:58:28',NULL,NULL,0),(16,'tg_1249639412_381ce4ec','일등당첨',NULL,1,0,'ACTIVE',NULL,NULL,700,700,0,NULL,0,NULL,0,'2026-01-02 12:06:45','2026-01-03 03:37:57',0,NULL,0,1249639412,'kmins22',0,1,'2026-01-02 12:06:45',NULL,NULL,0),(17,'tg_7192872944_7a9397a0','민똘이',NULL,5,80,'ACTIVE',NULL,NULL,1050,1050,0,NULL,0,NULL,0,'2026-01-02 12:12:28','2026-01-02 23:38:02',0,NULL,0,7192872944,'민똘이',0,1,'2026-01-02 12:12:28',NULL,NULL,0),(18,'tg_8338823321_d9695d15','동추',NULL,4,60,'ACTIVE',NULL,NULL,1600,1600,0,NULL,0,NULL,0,'2026-01-02 12:39:45','2026-01-02 13:45:26',0,NULL,0,8338823321,'동추',0,1,'2026-01-02 12:39:45',NULL,NULL,0),(19,'tg_7764179799_bcbff0e3','세상은참',NULL,1,0,'ACTIVE',NULL,NULL,1950,1950,0,NULL,0,NULL,0,'2026-01-02 13:19:19','2026-01-02 23:39:01',0,NULL,0,7764179799,'',0,1,'2026-01-02 13:19:19',NULL,NULL,0),(20,'tg_5787179040_d48286fc','나이스비',NULL,1,0,'ACTIVE','2026-01-02 16:44:20',NULL,2550,2550,0,'2026-01-03 16:45:21',0,NULL,0,'2026-01-02 16:41:48','2026-01-02 23:39:09',0,NULL,0,5787179040,'Zzzzzpty',0,2,'2026-01-02 16:41:48',NULL,NULL,0),(21,'tg_5721857928_a216cbc4','tg_user_5721857928',NULL,1,0,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-02 23:04:03','2026-01-03 01:32:43',0,NULL,0,5721857928,'',0,1,'2026-01-02 23:04:03',NULL,NULL,0),(22,'tg_1981255322_c86689ff','돈따묵쟈',NULL,1,0,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-02 23:13:27','2026-01-03 02:51:10',0,NULL,0,1981255322,'돈따묵쟈',0,1,'2026-01-02 23:13:27',NULL,NULL,0),(23,'tg_7292051908_c61e9929','콩이랑',NULL,1,0,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-03 01:40:47','2026-01-03 01:44:18',0,NULL,0,7292051908,'hklee93',0,1,'2026-01-03 01:40:47',NULL,NULL,0),(24,'tg_766455411_17661174','아사카',NULL,4,60,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-03 02:42:54','2026-01-03 04:57:38',0,NULL,0,766455411,'아사카',0,1,'2026-01-03 02:42:54',NULL,NULL,0),(25,'tg_8101149602_1b6f13d1','peace30922L',NULL,1,0,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-03 03:23:05','2026-01-03 03:23:05',0,NULL,0,8101149602,'peace30922L',0,1,'2026-01-03 03:23:05',NULL,NULL,0),(26,'tg_40074587_ad5fc2ac','jm956',NULL,1,0,'ACTIVE',NULL,NULL,400,400,0,NULL,0,NULL,0,'2026-01-03 03:54:56','2026-01-03 05:39:20',0,NULL,0,40074587,'jm956',0,1,'2026-01-03 03:54:56',NULL,NULL,0),(27,'tg_7690760913_660aae01','라오스오',NULL,2,40,'ACTIVE',NULL,NULL,1800,1800,0,NULL,0,NULL,0,'2026-01-03 05:30:30','2026-01-03 07:56:42',0,NULL,0,7690760913,'ppalqo',0,1,'2026-01-03 05:30:30',NULL,NULL,0),(29,'tg_7973906786_1f2eed9c','기프트',NULL,2,40,'ACTIVE',NULL,NULL,6010,6010,0,NULL,0,NULL,0,'2026-01-03 07:55:06','2026-01-03 08:09:47',0,NULL,0,7973906786,NULL,0,1,'2026-01-03 07:55:06',NULL,NULL,0),(30,'tg_8372420683_ccc1be57','성민이',NULL,4,60,'ACTIVE',NULL,NULL,0,0,0,NULL,0,NULL,0,'2026-01-03 07:55:15','2026-01-03 08:12:04',0,NULL,0,8372420683,'dyddns2211',0,1,'2026-01-03 07:55:15',NULL,NULL,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity`
--

DROP TABLE IF EXISTS `user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_charge_at` datetime DEFAULT NULL,
  `last_play_at` datetime DEFAULT NULL,
  `roulette_plays` int NOT NULL DEFAULT '0',
  `dice_plays` int NOT NULL DEFAULT '0',
  `lottery_plays` int NOT NULL DEFAULT '0',
  `total_play_duration` int NOT NULL DEFAULT '0',
  `last_bonus_used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_activity_user` (`user_id`),
  KEY `ix_user_activity_id` (`id`),
  KEY `ix_user_activity_user_updated_at` (`user_id`,`updated_at`),
  KEY `ix_user_activity_user_id` (`user_id`),
  CONSTRAINT `user_activity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity`
--

LOCK TABLES `user_activity` WRITE;
/*!40000 ALTER TABLE `user_activity` DISABLE KEYS */;
INSERT INTO `user_activity` VALUES (3,9,NULL,NULL,'2026-01-03 02:17:14',5,3,1,0,NULL,'2026-01-01 03:20:25','2026-01-03 02:17:14'),(4,7,NULL,'2026-01-03 01:58:01','2026-01-03 01:43:50',3,3,3,0,NULL,'2026-01-01 04:19:08','2026-01-03 01:58:01'),(5,17,NULL,'2026-01-02 23:32:46','2026-01-02 12:15:30',3,3,1,0,NULL,'2026-01-02 12:13:25','2026-01-02 23:32:46'),(6,18,NULL,'2026-01-02 13:45:26','2026-01-02 13:26:44',13,0,0,0,NULL,'2026-01-02 12:42:04','2026-01-02 13:45:26'),(7,13,NULL,NULL,'2026-01-03 03:03:54',3,10,2,0,NULL,'2026-01-02 12:58:32','2026-01-03 03:03:54'),(8,19,NULL,NULL,'2026-01-02 13:38:00',9,2,2,0,NULL,'2026-01-02 13:20:01','2026-01-02 13:38:00'),(9,20,NULL,NULL,'2026-01-02 16:53:03',8,6,1,0,NULL,'2026-01-02 16:45:27','2026-01-02 16:53:03'),(10,12,NULL,'2026-01-02 23:34:44',NULL,0,0,0,0,NULL,'2026-01-02 23:34:44','2026-01-02 23:34:44'),(11,24,NULL,'2026-01-03 04:57:36',NULL,0,0,0,0,NULL,'2026-01-03 02:49:59','2026-01-03 04:57:37'),(12,22,NULL,'2026-01-03 02:51:10',NULL,0,0,0,0,NULL,'2026-01-03 02:51:10','2026-01-03 02:51:10'),(13,16,NULL,NULL,'2026-01-03 03:37:58',2,3,1,0,NULL,'2026-01-03 03:36:28','2026-01-03 03:37:58'),(14,27,NULL,'2026-01-03 07:25:59','2026-01-03 05:35:44',6,4,1,0,NULL,'2026-01-03 05:32:00','2026-01-03 07:25:59'),(15,26,NULL,NULL,'2026-01-03 05:39:21',2,0,0,0,NULL,'2026-01-03 05:39:07','2026-01-03 05:39:21'),(16,30,NULL,'2026-01-03 07:57:00','2026-01-03 07:59:30',18,0,0,0,NULL,'2026-01-03 07:56:01','2026-01-03 07:59:30'),(17,29,NULL,'2026-01-03 07:57:13','2026-01-03 08:09:47',19,18,7,0,NULL,'2026-01-03 07:57:13','2026-01-03 08:09:47');
/*!40000 ALTER TABLE `user_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_event`
--

DROP TABLE IF EXISTS `user_activity_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activity_event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `event_id` varchar(36) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `duration_seconds` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_activity_event_event_id` (`event_id`),
  KEY `ix_user_activity_event_id` (`id`),
  KEY `ix_user_activity_event_user_id` (`user_id`),
  KEY `ix_user_activity_event_user_created` (`user_id`,`created_at`),
  CONSTRAINT `user_activity_event_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_event`
--

LOCK TABLES `user_activity_event` WRITE;
/*!40000 ALTER TABLE `user_activity_event` DISABLE KEYS */;
INSERT INTO `user_activity_event` VALUES (58,9,'8250a2f1-5566-43db-b251-e0f6069dc9cf','ROULETTE_PLAY',NULL,'2026-01-01 03:20:25'),(59,9,'f81bc268-5053-41fe-9aef-5b4531b5fb2e','ROULETTE_PLAY',NULL,'2026-01-01 03:20:27'),(60,9,'c95498ba-0950-4981-b28a-cdc0a72c3d79','ROULETTE_PLAY',NULL,'2026-01-01 03:20:43'),(61,9,'770601ba-c928-4144-8f6d-0246882bf045','ROULETTE_PLAY',NULL,'2026-01-01 03:20:53'),(62,9,'c81bc9a8-9ea4-44fb-8e94-773c23e2f2cc','DICE_PLAY',NULL,'2026-01-01 03:21:26'),(63,9,'71bdfa9e-4890-4d7b-99cf-c4076d9a071f','DICE_PLAY',NULL,'2026-01-01 03:21:29'),(64,7,'0d5c507f-1329-4805-971e-3c95a91d55a6','ROULETTE_PLAY',NULL,'2026-01-01 04:19:08'),(65,7,'c951ed30-9537-47c0-bf2f-c0c468aeed22','LOTTERY_PLAY',NULL,'2026-01-01 04:19:15'),(73,17,'c8dc8ee2-d6d1-477a-8159-6306430b8743','DICE_PLAY',NULL,'2026-01-02 12:13:25'),(74,17,'0b8f91c0-8ca2-41e2-82dd-fa1ea9c27193','ROULETTE_PLAY',NULL,'2026-01-02 12:14:12'),(75,17,'a994f72b-d448-405e-9f22-cc7a51281650','ROULETTE_PLAY',NULL,'2026-01-02 12:14:18'),(76,17,'e78533c2-c2cd-417f-a796-25aaa81f3747','ROULETTE_PLAY',NULL,'2026-01-02 12:14:31'),(77,17,'16cb88d4-33ce-4b79-9893-75434021d659','DICE_PLAY',NULL,'2026-01-02 12:15:02'),(78,17,'2007dadf-7b63-4bed-888c-700c5285c387','DICE_PLAY',NULL,'2026-01-02 12:15:07'),(79,17,'69e07798-8c5d-498d-b486-f308712bad1a','LOTTERY_PLAY',NULL,'2026-01-02 12:15:30'),(80,18,'f9dffbf7-c9d3-42b4-91f0-dfe6463104e6','ROULETTE_PLAY',NULL,'2026-01-02 12:42:04'),(81,18,'f5ea0101-ed8e-4b0d-bcae-f1228263572e','ROULETTE_PLAY',NULL,'2026-01-02 12:42:09'),(82,18,'ce17d280-28fc-47c8-bb82-7ea2eb7e19e7','ROULETTE_PLAY',NULL,'2026-01-02 12:42:18'),(83,18,'2f842086-cc97-4cce-bca3-f45cf440355f','ROULETTE_PLAY',NULL,'2026-01-02 12:42:25'),(84,18,'5e667518-9747-4e16-bbb7-878c898b7374','ROULETTE_PLAY',NULL,'2026-01-02 12:42:34'),(85,18,'555e46ed-7229-4892-b40c-ec07271e94b6','ROULETTE_PLAY',NULL,'2026-01-02 12:42:42'),(86,18,'43ee8b22-2de5-4667-858e-ad0d1fb3d7ce','ROULETTE_PLAY',NULL,'2026-01-02 12:42:50'),(87,18,'0e7b50ae-e2d3-4d7e-a173-c938f22217b5','ROULETTE_PLAY',NULL,'2026-01-02 12:43:04'),(88,13,'c34e9a75-39ac-4047-8709-1435108c2c37','ROULETTE_PLAY',NULL,'2026-01-02 12:58:32'),(89,13,'f25f9855-7a87-4c2c-8ba7-968646be3879','ROULETTE_PLAY',NULL,'2026-01-02 12:58:42'),(90,13,'97fba294-d029-49d8-a69d-8e0f507f69f1','DICE_PLAY',NULL,'2026-01-02 12:59:09'),(91,13,'a0b148e7-387a-49ed-a4a0-293820ac2057','DICE_PLAY',NULL,'2026-01-02 12:59:15'),(92,13,'d996fa01-24ea-43de-a03a-3bd88a860092','DICE_PLAY',NULL,'2026-01-02 12:59:19'),(93,13,'aaa1ec16-7616-4217-962a-d0ecea7e30b4','DICE_PLAY',NULL,'2026-01-02 12:59:23'),(94,13,'96c798cc-beea-4add-b73f-220c8cb81ea2','DICE_PLAY',NULL,'2026-01-02 12:59:26'),(95,13,'85edd64f-c821-44dc-bae8-0e8e113ef17e','DICE_PLAY',NULL,'2026-01-02 12:59:29'),(96,13,'1ccbf6aa-7b5f-4823-b253-d491519d0550','DICE_PLAY',NULL,'2026-01-02 12:59:32'),(97,13,'9a0b505d-0b44-4e43-bd37-a168aeb4c2cd','DICE_PLAY',NULL,'2026-01-02 12:59:34'),(98,13,'76a30c22-67e6-4ac7-aed4-e9a0a891c4db','DICE_PLAY',NULL,'2026-01-02 12:59:37'),(99,19,'33521f8a-fa3f-4b52-845a-7a042b52fbbf','ROULETTE_PLAY',NULL,'2026-01-02 13:20:01'),(100,19,'b973457e-75c6-4b38-815c-0f1cc413e429','ROULETTE_PLAY',NULL,'2026-01-02 13:20:12'),(101,19,'98532e2a-f30c-4f44-83de-a16c4226c734','ROULETTE_PLAY',NULL,'2026-01-02 13:20:21'),(102,19,'0f3d916a-d62e-405a-be7a-b7d8e89f59cc','ROULETTE_PLAY',NULL,'2026-01-02 13:20:26'),(103,19,'e7f0d767-d841-4c44-bd6a-4fd362bd8916','ROULETTE_PLAY',NULL,'2026-01-02 13:20:37'),(104,19,'731c69e5-d97a-46af-bd4c-43224e64c095','ROULETTE_PLAY',NULL,'2026-01-02 13:20:51'),(105,19,'f4e2064b-aea2-46ba-8e53-cab61449655a','ROULETTE_PLAY',NULL,'2026-01-02 13:21:01'),(106,19,'022dd0f2-37a8-4966-a91e-914bebbc20ce','ROULETTE_PLAY',NULL,'2026-01-02 13:21:14'),(107,18,'1ba21785-bc8a-439e-bd9a-fcedd387bd12','ROULETTE_PLAY',NULL,'2026-01-02 13:26:22'),(108,18,'f5e8b33c-f6a1-45f9-92b8-30a11060044a','ROULETTE_PLAY',NULL,'2026-01-02 13:26:27'),(109,18,'c4c7c86d-2157-433b-bd44-6fd3b3cecafe','ROULETTE_PLAY',NULL,'2026-01-02 13:26:33'),(110,18,'f080c1cd-8b76-4a7a-98d0-37166ee2cfb6','ROULETTE_PLAY',NULL,'2026-01-02 13:26:39'),(111,18,'521943f4-ea5d-48f5-aa86-f120171b8a36','ROULETTE_PLAY',NULL,'2026-01-02 13:26:44'),(112,19,'42604625-49ac-496e-afba-67cf3b9a4e4d','LOTTERY_PLAY',NULL,'2026-01-02 13:26:55'),(113,19,'19f3a7f7-550a-41b8-aeb8-3ffc96cde3d8','LOTTERY_PLAY',NULL,'2026-01-02 13:27:07'),(114,19,'093f7f95-5976-4bd4-843a-2a7c9a0dd365','ROULETTE_PLAY',NULL,'2026-01-02 13:36:22'),(115,19,'d98ddbf4-cc19-4d24-a012-6088492b4bac','DICE_PLAY',NULL,'2026-01-02 13:37:40'),(116,19,'1c0f8d63-4ec6-4dea-9172-adc3e5637a2a','DICE_PLAY',NULL,'2026-01-02 13:38:00'),(117,7,'6ab519c8-a2ac-4b73-9d2d-232d4ff6e99a','ROULETTE_PLAY',NULL,'2026-01-02 13:52:20'),(118,7,'33aa705b-d632-42ba-86c1-3e75d5a3f0d6','DICE_PLAY',NULL,'2026-01-02 13:52:45'),(119,7,'460c09b1-d5c1-48e1-a29e-a413a671a998','LOTTERY_PLAY',NULL,'2026-01-02 13:53:23'),(120,13,'9f61388a-fe77-40ae-9ff4-2b9c0a984245','LOTTERY_PLAY',NULL,'2026-01-02 14:35:58'),(121,20,'ca3ef07e-2be2-4c84-b394-d472572fc7a7','DICE_PLAY',NULL,'2026-01-02 16:45:27'),(122,20,'05af8a69-c9fe-4990-9044-b51a849ed0e9','ROULETTE_PLAY',NULL,'2026-01-02 16:45:57'),(123,20,'75f11ff6-d0ff-4cf3-949b-44664aeb4201','ROULETTE_PLAY',NULL,'2026-01-02 16:46:01'),(124,20,'0a4dff28-0bb1-4e7a-abcd-858548e2938e','ROULETTE_PLAY',NULL,'2026-01-02 16:46:09'),(125,20,'ebc3d4cf-651c-44f2-9c35-3f69e53d259f','ROULETTE_PLAY',NULL,'2026-01-02 16:46:16'),(126,20,'c841accd-ef63-455a-a233-be74d325bcc3','ROULETTE_PLAY',NULL,'2026-01-02 16:46:24'),(127,20,'ed0df95d-f424-4343-85e5-d215bd03680f','ROULETTE_PLAY',NULL,'2026-01-02 16:46:38'),(128,20,'e3d66f4b-b5ab-4790-8f47-5dc511e9a32d','ROULETTE_PLAY',NULL,'2026-01-02 16:46:47'),(129,20,'966fb6cc-6e08-4180-b27a-ebfb341267e1','ROULETTE_PLAY',NULL,'2026-01-02 16:47:03'),(130,20,'c470ea7d-1f62-4183-9e15-03baa09fa081','DICE_PLAY',NULL,'2026-01-02 16:51:23'),(131,20,'60fc1239-328b-4363-a0a2-e4cc55616ebc','DICE_PLAY',NULL,'2026-01-02 16:51:28'),(132,20,'6385027d-6a4a-430a-8074-b3f8f6c3fc31','DICE_PLAY',NULL,'2026-01-02 16:51:31'),(133,20,'229e3a42-88bc-4543-a03c-61ec8af92d45','DICE_PLAY',NULL,'2026-01-02 16:51:38'),(134,20,'cb74fe52-1a10-4288-9e1e-860d2220f59b','DICE_PLAY',NULL,'2026-01-02 16:51:40'),(135,20,'6d42ee66-f8bf-4e53-838f-84a5b0a696b7','LOTTERY_PLAY',NULL,'2026-01-02 16:53:03'),(136,7,'0536603c-5fe7-431a-b56e-49d240176d21','DICE_PLAY',NULL,'2026-01-03 01:43:15'),(137,7,'742af4c1-4932-437a-a8b0-a6a61624ea00','DICE_PLAY',NULL,'2026-01-03 01:43:22'),(138,7,'ac3fc392-2751-40c9-a420-885cf04093f1','ROULETTE_PLAY',NULL,'2026-01-03 01:43:36'),(139,7,'4c0930dc-1480-4e0b-9362-6744f9402cce','LOTTERY_PLAY',NULL,'2026-01-03 01:43:50'),(140,9,'4ba9f1e7-dc87-4bb6-b6b6-ffce01bd77ef','DICE_PLAY',NULL,'2026-01-03 02:16:32'),(141,9,'b246c798-c00c-46e3-9cc2-92f3ca43d663','ROULETTE_PLAY',NULL,'2026-01-03 02:16:43'),(142,9,'5b5f9fce-e5b3-463d-a3b2-7d3c5c55b4a2','LOTTERY_PLAY',NULL,'2026-01-03 02:17:14'),(143,13,'4c8ec196-2a2d-4e5c-bba1-720a7de2247a','ROULETTE_PLAY',NULL,'2026-01-03 03:02:38'),(144,13,'e1ff3ff7-2466-4e3d-a24d-87f7a7f81a3e','DICE_PLAY',NULL,'2026-01-03 03:03:42'),(145,13,'e81e8e66-994a-463c-9249-98e1560ab30b','LOTTERY_PLAY',NULL,'2026-01-03 03:03:54'),(146,16,'e23e09f8-1808-4ec4-8de0-4cee3db29f9c','LOTTERY_PLAY',NULL,'2026-01-03 03:36:28'),(147,16,'41416e1b-2ddf-4bc8-9967-c560ddb43642','DICE_PLAY',NULL,'2026-01-03 03:36:59'),(148,16,'bb50d430-f668-44f0-adf5-66a692a9cf90','ROULETTE_PLAY',NULL,'2026-01-03 03:37:35'),(149,16,'99522368-6689-409a-9e67-f975f5f2ec72','ROULETTE_PLAY',NULL,'2026-01-03 03:37:40'),(150,16,'dedc98ea-513b-4dab-839d-ef7f050b5988','DICE_PLAY',NULL,'2026-01-03 03:37:55'),(151,16,'71351c9b-c518-4f73-9a4a-94a08c071529','DICE_PLAY',NULL,'2026-01-03 03:37:58'),(152,27,'29c9f428-4594-44d0-8c89-4a9c8c55634b','DICE_PLAY',NULL,'2026-01-03 05:32:00'),(153,27,'5bd7e54a-32ac-438f-b7a4-49e527c24127','ROULETTE_PLAY',NULL,'2026-01-03 05:32:42'),(154,27,'52611f50-6cea-4c71-a1c6-d75cb2fa6114','ROULETTE_PLAY',NULL,'2026-01-03 05:32:46'),(155,27,'c63a1307-4440-4c2a-af0f-535a045d4781','ROULETTE_PLAY',NULL,'2026-01-03 05:32:51'),(156,27,'779488e9-61e4-4260-9b30-3b2a60663cd2','ROULETTE_PLAY',NULL,'2026-01-03 05:32:59'),(157,27,'58191d8c-d621-414e-9059-6c2d884dee7d','ROULETTE_PLAY',NULL,'2026-01-03 05:33:07'),(158,27,'b6491ab9-2c3f-4b48-9338-d25eaa20b24a','DICE_PLAY',NULL,'2026-01-03 05:33:58'),(159,27,'cf7c9da4-96fe-4ebe-8af0-77d872b67ae0','DICE_PLAY',NULL,'2026-01-03 05:34:02'),(160,27,'39cab0c6-b848-4fac-94fa-73e9e4d258bb','DICE_PLAY',NULL,'2026-01-03 05:34:05'),(161,27,'b0649689-74a4-41a7-aa61-a6ada0fe2fcd','LOTTERY_PLAY',NULL,'2026-01-03 05:35:17'),(162,27,'3e86f450-d4dd-4a93-bdd7-eda3f03f2618','ROULETTE_PLAY',NULL,'2026-01-03 05:35:44'),(163,26,'3b1e6cc1-4461-4db0-af7a-a48c06d5f53d','ROULETTE_PLAY',NULL,'2026-01-03 05:39:07'),(164,26,'949ae7e5-abbe-47a3-a7fb-98dda20a3764','ROULETTE_PLAY',NULL,'2026-01-03 05:39:21'),(165,30,'043e4a26-755e-4ce2-b954-4f3f8756facd','ROULETTE_PLAY',NULL,'2026-01-03 07:56:01'),(166,30,'ed85e36a-dbe9-4a5f-8a40-9c832472be25','ROULETTE_PLAY',NULL,'2026-01-03 07:56:16'),(167,30,'d07f9915-b76b-422d-8d82-889fedb866de','ROULETTE_PLAY',NULL,'2026-01-03 07:56:24'),(168,30,'f71f1973-a269-48f6-a746-c200efab26a9','ROULETTE_PLAY',NULL,'2026-01-03 07:56:36'),(169,30,'667672dd-535c-453f-92af-ae51993c8a7e','ROULETTE_PLAY',NULL,'2026-01-03 07:56:45'),(170,30,'3fc6f4ad-a1be-43be-93be-c86221d331ee','ROULETTE_PLAY',NULL,'2026-01-03 07:56:55'),(171,30,'28f845fd-3646-409c-be94-25d55f2aafc2','ROULETTE_PLAY',NULL,'2026-01-03 07:57:05'),(172,30,'1f6725d4-64a5-4950-9de4-16a71fc49148','ROULETTE_PLAY',NULL,'2026-01-03 07:57:14'),(173,30,'10c7208d-acff-49ae-bd5a-90e4a2be1e9e','ROULETTE_PLAY',NULL,'2026-01-03 07:57:22'),(174,30,'cd28ebd5-e733-4de1-ad68-ecb7aa3c8d37','ROULETTE_PLAY',NULL,'2026-01-03 07:57:32'),(175,30,'b4e76d2b-929e-4c98-bcbe-139435f7579e','ROULETTE_PLAY',NULL,'2026-01-03 07:57:42'),(176,30,'29169b85-fa4a-446c-bfc7-4773678936de','ROULETTE_PLAY',NULL,'2026-01-03 07:57:54'),(177,30,'aedaaf03-7c7e-465b-b985-0a0976859ed8','ROULETTE_PLAY',NULL,'2026-01-03 07:57:59'),(178,30,'82955468-433c-4a11-a4de-63a6807767f2','ROULETTE_PLAY',NULL,'2026-01-03 07:58:07'),(179,30,'0f844deb-c2cb-4c78-b0d7-e25feff3a235','ROULETTE_PLAY',NULL,'2026-01-03 07:58:15'),(180,30,'6347d395-5c3e-4b15-a6ef-66f5f9b4f1df','ROULETTE_PLAY',NULL,'2026-01-03 07:58:22'),(181,30,'d5f37b2b-a70f-4cb5-99fe-c8df2c319759','ROULETTE_PLAY',NULL,'2026-01-03 07:58:30'),(182,30,'aa9dcc9d-3002-4497-8166-75c2e4da3871','ROULETTE_PLAY',NULL,'2026-01-03 07:59:30'),(183,29,'a3e4fc6f-51df-4ecd-9af8-2a8aa7f26817','LOTTERY_PLAY',NULL,'2026-01-03 08:01:39'),(184,29,'3b403bce-14c1-4729-87b8-fdea82ea4b75','LOTTERY_PLAY',NULL,'2026-01-03 08:02:30'),(185,29,'3f74ac32-f19a-4aaf-8766-e2f0eb40dc2d','DICE_PLAY',NULL,'2026-01-03 08:03:44'),(186,29,'808e479a-38f6-4928-a59a-27e3361145f9','DICE_PLAY',NULL,'2026-01-03 08:03:51'),(187,29,'6c1fdefa-11b5-4840-878a-5e343e8c1881','DICE_PLAY',NULL,'2026-01-03 08:04:02'),(188,29,'b8644cb3-6803-461e-a4a0-f46559de4f82','ROULETTE_PLAY',NULL,'2026-01-03 08:04:23'),(189,29,'9ce5c99e-293c-4137-85d8-a02873c8ad7b','ROULETTE_PLAY',NULL,'2026-01-03 08:04:29'),(190,29,'59e7ddba-af68-40b5-aa38-092f3aaf1292','ROULETTE_PLAY',NULL,'2026-01-03 08:04:37'),(191,29,'8866faba-c8c3-4d15-94b1-3b71ff2533e2','ROULETTE_PLAY',NULL,'2026-01-03 08:04:45'),(192,29,'394d5c47-372e-4a06-9029-aa232c607b71','ROULETTE_PLAY',NULL,'2026-01-03 08:04:53'),(193,29,'03af906a-295e-441e-91eb-781ecb546111','ROULETTE_PLAY',NULL,'2026-01-03 08:05:00'),(194,29,'1094cc72-6dc7-4f83-8f86-3c177ff1f716','ROULETTE_PLAY',NULL,'2026-01-03 08:05:08'),(195,29,'8a819a2c-74d1-49db-9768-77a0d076c765','ROULETTE_PLAY',NULL,'2026-01-03 08:05:15'),(196,29,'9f081b54-8714-40f4-a54d-fed466ede9c0','ROULETTE_PLAY',NULL,'2026-01-03 08:05:23'),(197,29,'00193ce4-3ca4-499e-b74f-72464efc3d9a','ROULETTE_PLAY',NULL,'2026-01-03 08:05:30'),(198,29,'a31eb65a-e159-4206-be73-db9446972885','ROULETTE_PLAY',NULL,'2026-01-03 08:05:38'),(199,29,'879b0cc7-5461-44d7-a02d-0db4679f290e','ROULETTE_PLAY',NULL,'2026-01-03 08:05:45'),(200,29,'96d511d3-4f75-4642-8474-a17fe22151b4','ROULETTE_PLAY',NULL,'2026-01-03 08:05:53'),(201,29,'08666573-1ebf-4c95-a659-f2e079677a37','ROULETTE_PLAY',NULL,'2026-01-03 08:06:01'),(202,29,'f1c5e645-de78-467a-8ed8-fac917903abc','ROULETTE_PLAY',NULL,'2026-01-03 08:06:08'),(203,29,'82f73966-455a-4b43-854a-c1ff03ed2d30','ROULETTE_PLAY',NULL,'2026-01-03 08:06:15'),(204,29,'1dd92356-3f51-4aa7-a913-db040fc4fcf8','DICE_PLAY',NULL,'2026-01-03 08:06:35'),(205,29,'2de4a873-772c-48b3-be5a-8283d0daf147','DICE_PLAY',NULL,'2026-01-03 08:06:39'),(206,29,'599c6f4b-fe31-4b25-b796-369a1242a3bf','DICE_PLAY',NULL,'2026-01-03 08:06:43'),(207,29,'58c58d20-350b-4fc7-95b4-4e8bf95d3d4d','DICE_PLAY',NULL,'2026-01-03 08:06:46'),(208,29,'83af2dba-32d9-4114-8f72-49481450b832','DICE_PLAY',NULL,'2026-01-03 08:06:50'),(209,29,'3feb35b3-70b7-491e-b237-4b05c1c38129','DICE_PLAY',NULL,'2026-01-03 08:06:53'),(210,29,'5066d87f-a2d7-4e3e-8ae0-affb7b590908','DICE_PLAY',NULL,'2026-01-03 08:06:56'),(211,29,'ea69d6a0-9924-469e-bfb7-8e3ab14c331c','LOTTERY_PLAY',NULL,'2026-01-03 08:07:48'),(212,29,'d450080f-3bad-4993-bf2f-417479cda2ae','LOTTERY_PLAY',NULL,'2026-01-03 08:07:54'),(213,29,'cd262881-f7c3-4f4e-b238-cb18e2c30b8a','LOTTERY_PLAY',NULL,'2026-01-03 08:07:58'),(214,29,'1ea19d26-b974-4ada-8b68-a74dc47948c0','LOTTERY_PLAY',NULL,'2026-01-03 08:08:03'),(215,29,'e4db0636-1168-4c89-90f8-26ac23c67b8d','ROULETTE_PLAY',NULL,'2026-01-03 08:08:22'),(216,29,'e06d0d52-d584-4ad5-bd49-900ba9a87275','ROULETTE_PLAY',NULL,'2026-01-03 08:08:27'),(217,29,'ce4d44f2-cd46-4b25-840d-992557cf7f99','DICE_PLAY',NULL,'2026-01-03 08:08:43'),(218,29,'e40addd5-3f20-48bc-9ea4-02576af51aa9','DICE_PLAY',NULL,'2026-01-03 08:08:46'),(219,29,'570cdba1-fe64-4eda-98cc-4297f0d6930b','DICE_PLAY',NULL,'2026-01-03 08:08:49'),(220,29,'ad38e9a7-2717-4fa7-a58d-9f378b1b1855','DICE_PLAY',NULL,'2026-01-03 08:08:53'),(221,29,'9a7b8c7f-52c4-4ec7-938b-32dc71cabac1','DICE_PLAY',NULL,'2026-01-03 08:08:56'),(222,29,'778c575d-8ef5-4424-8d90-3bc26d8f9746','DICE_PLAY',NULL,'2026-01-03 08:08:59'),(223,29,'d9b26c0b-7197-43d1-a0a5-d557ae0f7f88','DICE_PLAY',NULL,'2026-01-03 08:09:02'),(224,29,'dfef4b8c-41e1-4edb-8b84-3f55ab2dc669','DICE_PLAY',NULL,'2026-01-03 08:09:04'),(225,29,'c7c89735-a2db-4a15-87f4-f787c7b94b8d','ROULETTE_PLAY',NULL,'2026-01-03 08:09:20'),(226,29,'bba52cae-d32f-40f1-bebf-c6a3131dae67','LOTTERY_PLAY',NULL,'2026-01-03 08:09:47');
/*!40000 ALTER TABLE `user_activity_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_cash_ledger`
--

DROP TABLE IF EXISTS `user_cash_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_cash_ledger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `delta` int NOT NULL,
  `balance_after` int NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `meta_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_user_cash_ledger_user_id` (`user_id`),
  KEY `ix_user_cash_ledger_id` (`id`),
  CONSTRAINT `user_cash_ledger_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_cash_ledger`
--

LOCK TABLES `user_cash_ledger` WRITE;
/*!40000 ALTER TABLE `user_cash_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_cash_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_event_log`
--

DROP TABLE IF EXISTS `user_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_event_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `feature_type` varchar(30) NOT NULL,
  `event_name` varchar(50) NOT NULL,
  `meta_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_user_event_log_id` (`id`),
  KEY `ix_user_event_log_user_created_at` (`user_id`,`created_at`),
  KEY `ix_user_event_log_event_name` (`event_name`),
  CONSTRAINT `user_event_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_event_log`
--

LOCK TABLES `user_event_log` WRITE;
/*!40000 ALTER TABLE `user_event_log` DISABLE KEYS */;
INSERT INTO `user_event_log` VALUES (1,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2025-12-31 16:11:00'),(2,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2025-12-31 18:15:43'),(61,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2025-12-31 19:27:21'),(76,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2025-12-31 20:13:26'),(90,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-01 02:37:00'),(91,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-01 02:46:17'),(92,9,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 136, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-01 03:20:16'),(93,9,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 134, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-01 03:20:26'),(94,9,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 133, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-01 03:20:38'),(95,9,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 134, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-01 03:20:50'),(96,9,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-01 03:21:24'),(97,9,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-01 03:21:28'),(98,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-01 03:28:02'),(99,7,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 135, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-01 04:19:07'),(100,7,'LOTTERY','PLAY','{\"label\": \"씨씨포인트2천원\", \"prize_id\": 58, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-01 04:19:15'),(103,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-01 05:08:23'),(104,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-01 06:12:23'),(105,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-01 09:15:40'),(109,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-02 11:34:50'),(112,17,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 12:13:24'),(113,17,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:14:12'),(114,17,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 12:14:17'),(115,17,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:14:30'),(116,17,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:15:01'),(117,17,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 12:15:06'),(118,17,'LOTTERY','PLAY','{\"label\": \"씨씨코인\", \"prize_id\": 100, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:15:29'),(119,18,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:03'),(120,18,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:09'),(121,18,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:17'),(122,18,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:25'),(123,18,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:34'),(124,18,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:42'),(125,18,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:42:49'),(126,18,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 12:43:03'),(127,13,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:58:32'),(128,13,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 12:58:42'),(129,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:09'),(130,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:14'),(131,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:19'),(132,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:22'),(133,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:25'),(134,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:29'),(135,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:31'),(136,13,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 1, \"xp_from_reward\": 5}','2026-01-02 12:59:34'),(137,13,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 12:59:36'),(138,19,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-02 13:20:00'),(139,19,'ROULETTE','PLAY','{\"label\": \"씨씨코인\", \"segment_id\": 174, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:20:11'),(140,19,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:20:21'),(141,19,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-02 13:20:26'),(142,19,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-02 13:20:37'),(143,19,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:20:51'),(144,19,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:21:01'),(145,19,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:21:13'),(146,18,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:26:22'),(147,18,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:26:26'),(148,18,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:26:32'),(149,18,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:26:39'),(150,18,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:26:43'),(151,19,'LOTTERY','PLAY','{\"label\": \"씨씨포인트2천원\", \"prize_id\": 103, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:26:54'),(152,19,'LOTTERY','PLAY','{\"label\": \"주사위티켓\", \"prize_id\": 104, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:27:06'),(153,19,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-02 13:36:22'),(154,19,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:37:40'),(155,19,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-02 13:37:59'),(156,7,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:52:20'),(157,7,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 13:52:44'),(158,7,'LOTTERY','PLAY','{\"label\": \"주사위티켓\", \"prize_id\": 104, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 13:53:23'),(159,13,'LOTTERY','PLAY','{\"label\": \"배민5천원\", \"prize_id\": 108, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 14:35:57'),(160,20,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 16:45:21'),(161,20,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:45:56'),(162,20,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:46:00'),(163,20,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-02 16:46:08'),(164,20,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:46:16'),(165,20,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:46:23'),(166,20,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:46:37'),(167,20,'ROULETTE','PLAY','{\"label\": \"5000원\", \"segment_id\": 152, \"reward_type\": \"POINT\", \"reward_amount\": 5000, \"xp_from_reward\": 0}','2026-01-02 16:46:46'),(168,20,'ROULETTE','PLAY','{\"label\": \"20000원\", \"segment_id\": 163, \"reward_type\": \"POINT\", \"reward_amount\": 20000, \"xp_from_reward\": 0}','2026-01-02 16:47:02'),(169,20,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:51:22'),(170,20,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-02 16:51:27'),(171,20,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-02 16:51:30'),(172,20,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:51:37'),(173,20,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-02 16:51:39'),(174,20,'LOTTERY','PLAY','{\"label\": \"컴포즈아아\", \"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-02 16:53:03'),(175,7,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 01:43:14'),(176,7,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 01:43:22'),(177,7,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 01:43:35'),(178,7,'LOTTERY','PLAY','{\"label\": \"씨씨포인트2천원\", \"prize_id\": 112, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 01:43:49'),(179,9,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 02:16:32'),(180,9,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 02:16:43'),(181,9,'LOTTERY','PLAY','{\"label\": \"주사위티켓\", \"prize_id\": 113, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 02:17:13'),(182,13,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 03:02:37'),(183,13,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 03:03:41'),(184,13,'LOTTERY','PLAY','{\"label\": \"컴포즈아아\", \"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 03:03:53'),(185,16,'LOTTERY','PLAY','{\"label\": \"룰렛티켓\", \"prize_id\": 107, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 03:36:27'),(186,16,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 03:36:59'),(187,16,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 03:37:35'),(188,16,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 03:37:40'),(189,16,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 03:37:55'),(190,16,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 03:37:57'),(191,27,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 05:31:55'),(192,27,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:32:36'),(193,27,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:32:45'),(194,27,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 05:32:51'),(195,27,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:32:58'),(196,27,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:33:07'),(197,27,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 05:33:58'),(198,27,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 05:34:01'),(199,27,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 05:34:04'),(200,27,'LOTTERY','PLAY','{\"label\": \"컴포즈아아\", \"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:35:17'),(201,27,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 05:35:44'),(202,26,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:39:07'),(203,26,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 05:39:20'),(204,2,'AUTH','AUTH_LOGIN','{\"ip\": \"172.18.0.8\", \"external_id\": \"admin\"}','2026-01-03 07:28:38'),(205,30,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 07:56:00'),(206,30,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 07:56:15'),(207,30,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:56:23'),(208,30,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:56:36'),(209,30,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 07:56:45'),(210,30,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 07:56:55'),(211,30,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:57:05'),(212,30,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 07:57:14'),(213,30,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:57:22'),(214,30,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:57:32'),(215,30,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:57:41'),(216,30,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:57:54'),(217,30,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:57:59'),(218,30,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:58:06'),(219,30,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:58:14'),(220,30,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 07:58:22'),(221,30,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 07:58:30'),(222,30,'ROULETTE','PLAY','{\"label\": \"20000원\", \"segment_id\": 154, \"reward_type\": \"POINT\", \"reward_amount\": 20000, \"xp_from_reward\": 0}','2026-01-03 07:59:30'),(223,29,'LOTTERY','PLAY','{\"label\": \"씨씨포인트2천원\", \"prize_id\": 112, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:01:39'),(224,29,'LOTTERY','PLAY','{\"label\": \"배민5천원\", \"prize_id\": 108, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:02:30'),(225,29,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:03:44'),(226,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:03:50'),(227,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:04:01'),(228,29,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:04:22'),(229,29,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:04:28'),(230,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:04:36'),(231,29,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 08:04:45'),(232,29,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:04:53'),(233,29,'ROULETTE','PLAY','{\"label\": \"룰렛티켓1장\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:05:00'),(234,29,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:05:07'),(235,29,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 08:05:15'),(236,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:05:22'),(237,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:05:30'),(238,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:05:38'),(239,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:05:45'),(240,29,'ROULETTE','PLAY','{\"label\": \"룰렛티켓2장\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"xp_from_reward\": 0}','2026-01-03 08:05:53'),(241,29,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:06:01'),(242,29,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:06:08'),(243,29,'ROULETTE','PLAY','{\"label\": \"꽝\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:06:15'),(244,29,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:06:35'),(245,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:06:38'),(246,29,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:06:43'),(247,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:06:46'),(248,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:06:50'),(249,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:06:53'),(250,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:06:56'),(251,29,'LOTTERY','PLAY','{\"label\": \"룰렛티켓\", \"prize_id\": 107, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:07:47'),(252,29,'LOTTERY','PLAY','{\"label\": \"배민5천원\", \"prize_id\": 108, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:07:54'),(253,29,'LOTTERY','PLAY','{\"label\": \"주사위티켓\", \"prize_id\": 113, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:07:58'),(254,29,'LOTTERY','PLAY','{\"label\": \"룰렛티켓\", \"prize_id\": 107, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:08:03'),(255,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:08:22'),(256,29,'ROULETTE','PLAY','{\"label\": \"복권티켓1장\", \"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:08:27'),(257,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:08:42'),(258,29,'DICE','PLAY','{\"result\": \"DRAW\", \"reward_type\": \"TICKET_DICE\", \"reward_label\": \"2026001 - DRAW\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:08:46'),(259,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:08:49'),(260,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:08:52'),(261,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:08:56'),(262,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:08:58'),(263,29,'DICE','PLAY','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - WIN\", \"reward_amount\": 0, \"xp_from_reward\": 5}','2026-01-03 08:09:01'),(264,29,'DICE','PLAY','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_label\": \"2026001 - LOSE\", \"reward_amount\": 0, \"xp_from_reward\": 0}','2026-01-03 08:09:04'),(265,29,'ROULETTE','PLAY','{\"label\": \"주사위티켓1장\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:09:20'),(266,29,'LOTTERY','PLAY','{\"label\": \"컴포즈아아\", \"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"xp_from_reward\": 0}','2026-01-03 08:09:47');
/*!40000 ALTER TABLE `user_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_game_wallet`
--

DROP TABLE IF EXISTS `user_game_wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_game_wallet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_type` enum('ROULETTE_COIN','DICE_TOKEN','LOTTERY_TICKET','CC_COIN','GOLD_KEY','DIAMOND_KEY','DIAMOND') NOT NULL,
  `balance` int NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_token_type` (`user_id`,`token_type`),
  KEY `ix_user_game_wallet_user_id` (`user_id`),
  KEY `ix_user_game_wallet_id` (`id`),
  KEY `ix_user_game_wallet_token_type` (`token_type`),
  CONSTRAINT `user_game_wallet_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_game_wallet`
--

LOCK TABLES `user_game_wallet` WRITE;
/*!40000 ALTER TABLE `user_game_wallet` DISABLE KEYS */;
INSERT INTO `user_game_wallet` VALUES (21,9,'ROULETTE_COIN',0,'2026-01-03 02:16:42'),(22,9,'DICE_TOKEN',0,'2026-01-03 02:16:31'),(23,9,'GOLD_KEY',0,'2026-01-01 03:21:04'),(24,9,'LOTTERY_TICKET',0,'2026-01-03 02:17:13'),(25,9,'DIAMOND',1,'2026-01-01 03:23:33'),(26,9,'DIAMOND_KEY',0,'2026-01-01 03:24:04'),(27,7,'ROULETTE_COIN',0,'2026-01-03 01:43:35'),(28,7,'DICE_TOKEN',0,'2026-01-03 01:43:22'),(29,7,'LOTTERY_TICKET',0,'2026-01-03 01:43:49'),(37,12,'DICE_TOKEN',6,'2026-01-02 23:45:29'),(38,12,'ROULETTE_COIN',6,'2026-01-02 23:34:44'),(39,13,'ROULETTE_COIN',0,'2026-01-03 03:02:37'),(40,13,'GOLD_KEY',0,'2026-01-02 08:00:19'),(41,13,'DIAMOND_KEY',0,'2026-01-02 08:00:20'),(42,13,'LOTTERY_TICKET',0,'2026-01-03 03:03:53'),(43,13,'DICE_TOKEN',0,'2026-01-03 03:03:41'),(44,16,'ROULETTE_COIN',0,'2026-01-03 03:37:40'),(45,17,'ROULETTE_COIN',5,'2026-01-02 23:32:46'),(46,17,'DICE_TOKEN',12,'2026-01-02 23:48:57'),(47,17,'GOLD_KEY',1,'2026-01-02 23:32:46'),(48,17,'DIAMOND_KEY',0,'2026-01-02 12:14:07'),(49,17,'LOTTERY_TICKET',1,'2026-01-02 23:44:48'),(50,18,'ROULETTE_COIN',0,'2026-01-02 13:26:43'),(51,18,'DICE_TOKEN',12,'2026-01-02 13:46:57'),(52,18,'LOTTERY_TICKET',5,'2026-01-02 13:26:26'),(53,19,'ROULETTE_COIN',0,'2026-01-02 13:36:22'),(54,19,'LOTTERY_TICKET',0,'2026-01-02 13:27:06'),(55,19,'DICE_TOKEN',0,'2026-01-02 13:37:59'),(56,14,'ROULETTE_COIN',1,'2026-01-02 13:22:37'),(57,19,'GOLD_KEY',0,'2026-01-02 13:36:10'),(58,20,'ROULETTE_COIN',0,'2026-01-02 16:46:36'),(59,20,'DICE_TOKEN',0,'2026-01-02 16:51:39'),(60,20,'GOLD_KEY',0,'2026-01-02 16:46:45'),(61,20,'DIAMOND_KEY',0,'2026-01-02 16:47:02'),(62,20,'LOTTERY_TICKET',0,'2026-01-02 16:53:03'),(63,7,'GOLD_KEY',0,'2026-01-02 23:02:20'),(64,7,'DIAMOND_KEY',0,'2026-01-02 23:02:21'),(65,21,'ROULETTE_COIN',2,'2026-01-02 23:04:04'),(66,12,'LOTTERY_TICKET',2,'2026-01-02 23:45:33'),(67,24,'ROULETTE_COIN',7,'2026-01-03 02:50:00'),(68,24,'DICE_TOKEN',6,'2026-01-03 04:57:38'),(69,24,'LOTTERY_TICKET',1,'2026-01-03 02:50:00'),(70,25,'ROULETTE_COIN',2,'2026-01-03 03:31:34'),(71,16,'LOTTERY_TICKET',0,'2026-01-03 03:36:27'),(72,16,'DICE_TOKEN',0,'2026-01-03 03:37:57'),(73,16,'GOLD_KEY',0,'2026-01-03 03:37:22'),(74,16,'DIAMOND_KEY',0,'2026-01-03 03:37:25'),(75,26,'ROULETTE_COIN',11,'2026-01-03 05:39:20'),(76,27,'ROULETTE_COIN',3,'2026-01-03 07:26:00'),(77,27,'DICE_TOKEN',1,'2026-01-03 07:25:59'),(78,26,'LOTTERY_TICKET',2,'2026-01-03 05:39:20'),(79,27,'LOTTERY_TICKET',0,'2026-01-03 05:35:16'),(80,26,'GOLD_KEY',0,'2026-01-03 05:38:29'),(81,26,'DIAMOND_KEY',0,'2026-01-03 05:38:37'),(82,29,'ROULETTE_COIN',0,'2026-01-03 08:09:19'),(83,30,'ROULETTE_COIN',0,'2026-01-03 07:58:30'),(84,30,'DICE_TOKEN',9,'2026-01-03 07:57:59'),(85,30,'LOTTERY_TICKET',5,'2026-01-03 07:58:22'),(86,30,'GOLD_KEY',0,'2026-01-03 07:59:29'),(87,29,'DICE_TOKEN',0,'2026-01-03 08:09:04'),(88,29,'LOTTERY_TICKET',0,'2026-01-03 08:09:47'),(89,30,'DIAMOND_KEY',0,'2026-01-03 07:59:20');
/*!40000 ALTER TABLE `user_game_wallet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_game_wallet_ledger`
--

DROP TABLE IF EXISTS `user_game_wallet_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_game_wallet_ledger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_type` enum('ROULETTE_COIN','DICE_TOKEN','LOTTERY_TICKET','CC_COIN','GOLD_KEY','DIAMOND_KEY','DIAMOND') NOT NULL,
  `delta` int NOT NULL,
  `balance_after` int NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `meta_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_user_game_wallet_ledger_user_id` (`user_id`),
  KEY `ix_user_game_wallet_ledger_created_at` (`created_at`),
  KEY `ix_user_game_wallet_ledger_id` (`id`),
  KEY `ix_user_game_wallet_ledger_token_type` (`token_type`),
  CONSTRAINT `user_game_wallet_ledger_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=517 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_game_wallet_ledger`
--

LOCK TABLES `user_game_wallet_ledger` WRITE;
/*!40000 ALTER TABLE `user_game_wallet_ledger` DISABLE KEYS */;
INSERT INTO `user_game_wallet_ledger` VALUES (144,9,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-01 03:19:58'),(145,9,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 136, \"consumed_trial\": false}','2026-01-01 03:20:16'),(146,9,'ROULETTE_COIN',2,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 136}','2026-01-01 03:20:16'),(147,9,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 134, \"consumed_trial\": false}','2026-01-01 03:20:26'),(148,9,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 134}','2026-01-01 03:20:26'),(149,9,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 133, \"consumed_trial\": false}','2026-01-01 03:20:38'),(150,9,'ROULETTE_COIN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 133}','2026-01-01 03:20:38'),(151,9,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 134, \"consumed_trial\": false}','2026-01-01 03:20:50'),(152,9,'DICE_TOKEN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 134}','2026-01-01 03:20:50'),(153,9,'DICE_TOKEN',-1,1,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-01 03:21:24'),(154,9,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-01 03:21:28'),(155,9,'DIAMOND',1,1,'MISSION_REWARD','오픈기념 출석미션','{}','2026-01-01 03:23:33'),(156,7,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-01 04:17:54'),(157,7,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 135, \"consumed_trial\": false}','2026-01-01 04:19:07'),(158,7,'LOTTERY_TICKET',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 135}','2026-01-01 04:19:07'),(159,7,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','씨씨포인트2천원','{\"prize_id\": 58, \"consumed_trial\": false}','2026-01-01 04:19:15'),(171,12,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 04:41:17'),(172,13,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 07:50:51'),(176,16,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 12:06:50'),(177,16,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 12:06:50'),(178,17,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 12:12:34'),(179,17,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 12:12:34'),(180,17,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 12:13:20'),(181,17,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-02 12:13:24'),(182,17,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:14:12'),(183,17,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:14:12'),(184,17,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-02 12:14:17'),(185,17,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 12:14:28'),(186,17,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-02 12:14:30'),(187,17,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:15:01'),(188,17,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:15:01'),(189,17,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-02 12:15:05'),(190,17,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 12:15:26'),(191,17,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','씨씨코인','{\"prize_id\": 100, \"consumed_trial\": true}','2026-01-02 12:15:29'),(192,18,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 12:39:51'),(193,18,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 12:39:51'),(194,18,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-02 12:42:03'),(195,18,'ROULETTE_COIN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-02 12:42:03'),(196,18,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:42:09'),(197,18,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:42:09'),(198,18,'ROULETTE_COIN',3,4,'GRANT',NULL,'{}','2026-01-02 12:42:11'),(199,18,'DICE_TOKEN',3,4,'GRANT',NULL,'{}','2026-01-02 12:42:14'),(200,18,'ROULETTE_COIN',-1,3,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:42:17'),(201,18,'DICE_TOKEN',1,5,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:42:18'),(202,18,'LOTTERY_TICKET',3,3,'GRANT',NULL,'{}','2026-01-02 12:42:18'),(203,18,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:42:25'),(204,18,'DICE_TOKEN',1,6,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:42:25'),(205,18,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:42:34'),(206,18,'DICE_TOKEN',1,7,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:42:34'),(207,18,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-02 12:42:42'),(208,18,'ROULETTE_COIN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-02 12:42:42'),(209,18,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:42:49'),(210,18,'DICE_TOKEN',1,8,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:42:49'),(211,18,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 12:43:01'),(212,18,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": true}','2026-01-02 12:43:03'),(213,13,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 12:58:32'),(214,13,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 12:58:32'),(215,13,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 12:58:40'),(216,13,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-02 12:58:42'),(217,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:08'),(218,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:09'),(219,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:14'),(220,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:14'),(221,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:19'),(222,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:19'),(223,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:22'),(224,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:22'),(225,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:25'),(226,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:25'),(227,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:29'),(228,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:29'),(229,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:31'),(230,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:31'),(231,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 12:59:34'),(232,13,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 5, \"outcome\": \"WIN\"}','2026-01-02 12:59:34'),(233,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-02 12:59:36'),(234,18,'DICE_TOKEN',1,9,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 40, \"season_id\": 1}','2026-01-02 13:02:42'),(235,18,'ROULETTE_COIN',2,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 3, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 40, \"season_id\": 1}','2026-01-02 13:02:42'),(236,18,'LOTTERY_TICKET',1,4,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 4, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 40, \"season_id\": 1}','2026-01-02 13:02:42'),(237,18,'ROULETTE_COIN',3,5,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-02 13:02:42'),(238,19,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 13:19:20'),(239,19,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 13:19:20'),(240,19,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-02 13:20:00'),(241,19,'ROULETTE_COIN',2,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-02 13:20:00'),(242,19,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','씨씨코인','{\"segment_id\": 174, \"consumed_trial\": false}','2026-01-02 13:20:11'),(243,19,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-02 13:20:21'),(244,19,'LOTTERY_TICKET',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-02 13:20:21'),(245,19,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-02 13:20:26'),(246,19,'ROULETTE_COIN',2,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-02 13:20:26'),(247,19,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-02 13:20:37'),(248,19,'ROULETTE_COIN',2,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-02 13:20:37'),(249,19,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-02 13:20:51'),(250,19,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 13:21:01'),(251,19,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 13:21:01'),(252,19,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-02 13:21:13'),(253,14,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 13:22:37'),(254,18,'ROULETTE_COIN',-1,4,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-02 13:26:22'),(255,18,'ROULETTE_COIN',-1,3,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-02 13:26:26'),(256,18,'LOTTERY_TICKET',1,5,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-02 13:26:26'),(257,18,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-02 13:26:32'),(258,18,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-02 13:26:39'),(259,18,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 13:26:43'),(260,18,'DICE_TOKEN',1,10,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 13:26:43'),(261,19,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','씨씨포인트2천원','{\"prize_id\": 103, \"consumed_trial\": false}','2026-01-02 13:26:54'),(262,19,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 13:27:02'),(263,19,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','주사위티켓','{\"prize_id\": 104, \"consumed_trial\": true}','2026-01-02 13:27:06'),(264,19,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 13:36:19'),(265,19,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": true}','2026-01-02 13:36:22'),(266,19,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-02 13:37:40'),(267,19,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 13:37:55'),(268,19,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": true}','2026-01-02 13:37:59'),(269,18,'DICE_TOKEN',3,13,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-02 13:45:26'),(270,18,'DICE_TOKEN',-1,12,'REVOKE',NULL,'{}','2026-01-02 13:46:57'),(271,7,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 13:52:17'),(272,7,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": true}','2026-01-02 13:52:20'),(273,7,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 13:52:41'),(274,7,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-02 13:52:44'),(275,7,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 13:53:20'),(276,7,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','주사위티켓','{\"prize_id\": 104, \"consumed_trial\": true}','2026-01-02 13:53:23'),(277,13,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-02','{\"date\": \"2026-01-02\", \"source\": \"ticket_zero\"}','2026-01-02 14:35:53'),(278,13,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','배민5천원','{\"prize_id\": 108, \"consumed_trial\": true}','2026-01-02 14:35:57'),(279,20,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 16:44:22'),(280,20,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 16:44:22'),(281,20,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-02 16:45:14'),(282,20,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-02 16:45:21'),(283,20,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-02 16:45:56'),(284,20,'ROULETTE_COIN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-02 16:45:56'),(285,20,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 16:46:00'),(286,20,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 16:46:00'),(287,20,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-02 16:46:08'),(288,20,'ROULETTE_COIN',2,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-02 16:46:09'),(289,20,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 16:46:16'),(290,20,'DICE_TOKEN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 16:46:16'),(291,20,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-02 16:46:23'),(292,20,'DICE_TOKEN',1,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-02 16:46:23'),(293,20,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-02 16:46:35'),(294,20,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-02 16:46:36'),(295,20,'GOLD_KEY',1,1,'TRIAL_GRANT','TRIAL_GOLD_KEY_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-02 16:46:44'),(296,20,'GOLD_KEY',-1,0,'ROULETTE_PLAY','5000원','{\"segment_id\": 152, \"consumed_trial\": true}','2026-01-02 16:46:45'),(297,20,'DIAMOND_KEY',1,1,'TRIAL_GRANT','TRIAL_DIAMOND_KEY_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-02 16:47:01'),(298,20,'DIAMOND_KEY',-1,0,'ROULETTE_PLAY','20000원','{\"segment_id\": 163, \"consumed_trial\": true}','2026-01-02 16:47:02'),(299,20,'DICE_TOKEN',-1,2,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-02 16:51:22'),(300,20,'DICE_TOKEN',1,3,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 0, \"outcome\": \"DRAW\"}','2026-01-02 16:51:22'),(301,20,'DICE_TOKEN',-1,2,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 16:51:27'),(302,20,'DICE_TOKEN',-1,1,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-02 16:51:30'),(303,20,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-02 16:51:37'),(304,20,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 0, \"outcome\": \"DRAW\"}','2026-01-02 16:51:37'),(305,20,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-02 16:51:39'),(306,20,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-02 16:52:56'),(307,20,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','컴포즈아아','{\"prize_id\": 114, \"consumed_trial\": true}','2026-01-02 16:53:03'),(308,21,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-02 23:04:04'),(309,21,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-02 23:04:04'),(310,17,'DICE_TOKEN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 60, \"season_id\": 1}','2026-01-02 23:32:46'),(311,17,'ROULETTE_COIN',2,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 3, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 60, \"season_id\": 1}','2026-01-02 23:32:46'),(312,17,'LOTTERY_TICKET',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 4, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 60, \"season_id\": 1}','2026-01-02 23:32:46'),(313,17,'ROULETTE_COIN',3,5,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-02 23:32:46'),(314,17,'DICE_TOKEN',3,4,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-02 23:32:46'),(315,17,'GOLD_KEY',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 5, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-02 23:32:46'),(316,12,'DICE_TOKEN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 40, \"season_id\": 1}','2026-01-02 23:34:44'),(317,12,'ROULETTE_COIN',3,4,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-02 23:34:44'),(318,12,'ROULETTE_COIN',2,6,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 3, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-02 23:34:44'),(319,12,'LOTTERY_TICKET',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 4, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-02 23:34:44'),(320,7,'DICE_TOKEN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-02 23:35:54'),(321,17,'DICE_TOKEN',5,9,'GRANT',NULL,'{}','2026-01-02 23:44:12'),(322,17,'LOTTERY_TICKET',1,2,'GRANT',NULL,'{}','2026-01-02 23:44:18'),(323,17,'DICE_TOKEN',-5,4,'REVOKE',NULL,'{}','2026-01-02 23:44:44'),(324,17,'LOTTERY_TICKET',-1,1,'REVOKE',NULL,'{}','2026-01-02 23:44:48'),(325,12,'DICE_TOKEN',5,6,'GRANT',NULL,'{}','2026-01-02 23:45:29'),(326,12,'LOTTERY_TICKET',1,2,'GRANT',NULL,'{}','2026-01-02 23:45:33'),(327,17,'DICE_TOKEN',8,12,'GRANT',NULL,'{}','2026-01-02 23:48:57'),(328,7,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 01:43:14'),(329,7,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 01:43:19'),(330,7,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-03 01:43:22'),(331,7,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 01:43:34'),(332,7,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-03 01:43:35'),(333,7,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 01:43:47'),(334,7,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','씨씨포인트2천원','{\"prize_id\": 112, \"consumed_trial\": true}','2026-01-03 01:43:49'),(335,9,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 02:16:27'),(336,9,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": true}','2026-01-03 02:16:32'),(337,9,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 02:16:41'),(338,9,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-03 02:16:42'),(339,9,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 02:17:09'),(340,9,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','주사위티켓','{\"prize_id\": 113, \"consumed_trial\": true}','2026-01-03 02:17:13'),(341,24,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-03 02:42:56'),(342,24,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-03 02:42:56'),(343,24,'DICE_TOKEN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 40, \"season_id\": 1}','2026-01-03 02:50:00'),(344,24,'ROULETTE_COIN',3,5,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-03 02:50:00'),(345,24,'ROULETTE_COIN',2,7,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 3, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-03 02:50:00'),(346,24,'LOTTERY_TICKET',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 4, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-03 02:50:00'),(347,24,'DICE_TOKEN',2,3,'GRANT',NULL,'{}','2026-01-03 02:52:19'),(348,13,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 03:02:36'),(349,13,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-03 03:02:37'),(350,13,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 03:03:39'),(351,13,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-03 03:03:41'),(352,13,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 03:03:50'),(353,13,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','컴포즈아아','{\"prize_id\": 114, \"consumed_trial\": true}','2026-01-03 03:03:53'),(354,25,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-03 03:31:34'),(355,25,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-03 03:31:34'),(356,16,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 03:36:24'),(357,16,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','룰렛티켓','{\"prize_id\": 107, \"consumed_trial\": true}','2026-01-03 03:36:27'),(358,16,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 03:36:56'),(359,16,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-03 03:36:58'),(360,16,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 03:37:35'),(361,16,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 03:37:35'),(362,16,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 03:37:40'),(363,16,'DICE_TOKEN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 03:37:40'),(364,16,'DICE_TOKEN',-1,1,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 03:37:55'),(365,16,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 03:37:57'),(366,26,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-03 03:54:57'),(367,26,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-03 03:54:57'),(368,26,'ROULETTE_COIN',10,12,'GRANT',NULL,'{}','2026-01-03 04:49:16'),(369,24,'DICE_TOKEN',3,6,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-03 04:57:38'),(370,27,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-03 05:30:32'),(371,27,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-03 05:30:32'),(372,27,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 05:31:38'),(373,27,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-03 05:31:54'),(374,27,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 05:32:36'),(375,27,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 05:32:36'),(376,27,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 05:32:45'),(377,27,'ROULETTE_COIN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 05:32:45'),(378,27,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 05:32:50'),(379,27,'ROULETTE_COIN',2,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 05:32:51'),(380,27,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 05:32:58'),(381,27,'DICE_TOKEN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 05:32:58'),(382,27,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 05:33:07'),(383,27,'DICE_TOKEN',1,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 05:33:07'),(384,27,'DICE_TOKEN',-1,2,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 05:33:58'),(385,27,'DICE_TOKEN',-1,1,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 05:34:01'),(386,27,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 05:34:04'),(387,27,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 05:35:13'),(388,26,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 05:35:13'),(389,27,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','컴포즈아아','{\"prize_id\": 114, \"consumed_trial\": true}','2026-01-03 05:35:17'),(390,27,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 05:35:41'),(391,27,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": true}','2026-01-03 05:35:44'),(392,26,'ROULETTE_COIN',-1,11,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 05:39:07'),(393,26,'ROULETTE_COIN',1,12,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 05:39:07'),(394,26,'ROULETTE_COIN',-1,11,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 05:39:20'),(395,26,'LOTTERY_TICKET',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 05:39:20'),(396,27,'DICE_TOKEN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 20, \"season_id\": 1}','2026-01-03 07:25:59'),(397,27,'ROULETTE_COIN',3,3,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-03 07:26:00'),(398,29,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-03 07:55:10'),(399,29,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-03 07:55:10'),(400,30,'ROULETTE_COIN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_INIT\", \"season_id\": 1}','2026-01-03 07:55:17'),(401,30,'ROULETTE_COIN',1,2,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"SEASON_PASS_AUTO_CLAIM_RECOVERY\", \"trigger\": \"STATUS\", \"season_id\": 1}','2026-01-03 07:55:17'),(402,30,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 07:56:00'),(403,30,'ROULETTE_COIN',2,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 07:56:00'),(404,30,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 07:56:15'),(405,30,'ROULETTE_COIN',2,4,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 07:56:15'),(406,30,'ROULETTE_COIN',-1,3,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 07:56:23'),(407,30,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 07:56:23'),(408,30,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 07:56:36'),(409,30,'DICE_TOKEN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 07:56:36'),(410,30,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 07:56:44'),(411,30,'ROULETTE_COIN',2,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 07:56:45'),(412,30,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-03 07:56:55'),(413,30,'DICE_TOKEN',1,3,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 60, \"season_id\": 1}','2026-01-03 07:57:00'),(414,30,'ROULETTE_COIN',2,4,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 3, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 60, \"season_id\": 1}','2026-01-03 07:57:00'),(415,30,'LOTTERY_TICKET',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 4, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 60, \"season_id\": 1}','2026-01-03 07:57:00'),(416,30,'ROULETTE_COIN',3,7,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-03 07:57:00'),(417,30,'DICE_TOKEN',3,6,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-03 07:57:00'),(418,30,'GOLD_KEY',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 5, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-03 07:57:00'),(419,30,'ROULETTE_COIN',-1,6,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 07:57:04'),(420,30,'ROULETTE_COIN',1,7,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 07:57:05'),(421,29,'DICE_TOKEN',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 2, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"trigger\": \"BONUS_XP\", \"xp_added\": 40, \"season_id\": 1}','2026-01-03 07:57:13'),(422,29,'ROULETTE_COIN',3,5,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 1, \"source\": \"EXTERNAL_RANKING_DEPOSIT\", \"tickets\": 3}','2026-01-03 07:57:13'),(423,30,'ROULETTE_COIN',-1,6,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 07:57:13'),(424,29,'ROULETTE_COIN',2,7,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 3, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-03 07:57:14'),(425,29,'LOTTERY_TICKET',1,1,'LEVEL_REWARD','AUTO_GRANT','{\"level\": 4, \"source\": \"SEASON_PASS_AUTO_CLAIM\", \"feature\": \"EXTERNAL_RANKING_TOP10\", \"trigger\": \"STAMP\", \"xp_added\": 20, \"season_id\": 1, \"stamp_count\": 1}','2026-01-03 07:57:14'),(426,30,'ROULETTE_COIN',2,8,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 07:57:14'),(427,30,'ROULETTE_COIN',-1,7,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 07:57:21'),(428,30,'LOTTERY_TICKET',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 07:57:22'),(429,30,'ROULETTE_COIN',-1,6,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 07:57:32'),(430,30,'LOTTERY_TICKET',1,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 07:57:32'),(431,30,'ROULETTE_COIN',-1,5,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 07:57:41'),(432,30,'DICE_TOKEN',1,7,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 07:57:41'),(433,30,'ROULETTE_COIN',-1,4,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 07:57:53'),(434,30,'DICE_TOKEN',1,8,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 07:57:54'),(435,30,'ROULETTE_COIN',-1,3,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 07:57:59'),(436,30,'DICE_TOKEN',1,9,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 07:57:59'),(437,30,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 07:58:06'),(438,30,'ROULETTE_COIN',1,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 07:58:07'),(439,30,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 07:58:14'),(440,30,'LOTTERY_TICKET',1,4,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 07:58:14'),(441,30,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 07:58:22'),(442,30,'LOTTERY_TICKET',1,5,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 07:58:22'),(443,30,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-03 07:58:30'),(444,30,'GOLD_KEY',-1,0,'ROULETTE_PLAY','20000원','{\"segment_id\": 154, \"consumed_trial\": false}','2026-01-03 07:59:30'),(445,29,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','씨씨포인트2천원','{\"prize_id\": 112, \"consumed_trial\": false}','2026-01-03 08:01:39'),(446,29,'LOTTERY_TICKET',1,1,'TRIAL_GRANT','TRIAL_LOTTERY_TICKET_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 08:02:24'),(447,29,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','배민5천원','{\"prize_id\": 108, \"consumed_trial\": true}','2026-01-03 08:02:30'),(448,29,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-03 08:03:44'),(449,29,'DICE_TOKEN',1,1,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 0, \"outcome\": \"DRAW\"}','2026-01-03 08:03:44'),(450,29,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 08:03:50'),(451,29,'DICE_TOKEN',1,1,'TRIAL_GRANT','TRIAL_DICE_TOKEN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 08:03:57'),(452,29,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": true}','2026-01-03 08:04:01'),(453,29,'ROULETTE_COIN',-1,6,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 08:04:22'),(454,29,'ROULETTE_COIN',1,7,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 08:04:22'),(455,29,'ROULETTE_COIN',-1,6,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 08:04:28'),(456,29,'LOTTERY_TICKET',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 08:04:28'),(457,29,'ROULETTE_COIN',-1,5,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 08:04:36'),(458,29,'DICE_TOKEN',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 08:04:36'),(459,29,'ROULETTE_COIN',-1,4,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 08:04:45'),(460,29,'ROULETTE_COIN',2,6,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 08:04:45'),(461,29,'ROULETTE_COIN',-1,5,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 08:04:53'),(462,29,'ROULETTE_COIN',1,6,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 08:04:53'),(463,29,'ROULETTE_COIN',-1,5,'ROULETTE_PLAY','룰렛티켓1장','{\"segment_id\": 169, \"consumed_trial\": false}','2026-01-03 08:05:00'),(464,29,'ROULETTE_COIN',1,6,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 169}','2026-01-03 08:05:00'),(465,29,'ROULETTE_COIN',-1,5,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 08:05:07'),(466,29,'LOTTERY_TICKET',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 08:05:07'),(467,29,'ROULETTE_COIN',-1,4,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 08:05:15'),(468,29,'ROULETTE_COIN',2,6,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 08:05:15'),(469,29,'ROULETTE_COIN',-1,5,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 08:05:22'),(470,29,'DICE_TOKEN',1,2,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 08:05:22'),(471,29,'ROULETTE_COIN',-1,4,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 08:05:30'),(472,29,'DICE_TOKEN',1,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 08:05:30'),(473,29,'ROULETTE_COIN',-1,3,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 08:05:38'),(474,29,'DICE_TOKEN',1,4,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 08:05:38'),(475,29,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 08:05:45'),(476,29,'DICE_TOKEN',1,5,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 08:05:45'),(477,29,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','룰렛티켓2장','{\"segment_id\": 172, \"consumed_trial\": false}','2026-01-03 08:05:52'),(478,29,'ROULETTE_COIN',2,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 172}','2026-01-03 08:05:53'),(479,29,'ROULETTE_COIN',-1,2,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 08:06:00'),(480,29,'LOTTERY_TICKET',1,3,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 08:06:01'),(481,29,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 08:06:08'),(482,29,'LOTTERY_TICKET',1,4,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 08:06:08'),(483,29,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','꽝','{\"segment_id\": 173, \"consumed_trial\": false}','2026-01-03 08:06:15'),(484,29,'DICE_TOKEN',-1,4,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-03 08:06:34'),(485,29,'DICE_TOKEN',1,5,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 0, \"outcome\": \"DRAW\"}','2026-01-03 08:06:35'),(486,29,'DICE_TOKEN',-1,4,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 08:06:38'),(487,29,'DICE_TOKEN',-1,3,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-03 08:06:43'),(488,29,'DICE_TOKEN',1,4,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 0, \"outcome\": \"DRAW\"}','2026-01-03 08:06:43'),(489,29,'DICE_TOKEN',-1,3,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:06:46'),(490,29,'DICE_TOKEN',-1,2,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 08:06:50'),(491,29,'DICE_TOKEN',-1,1,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 08:06:53'),(492,29,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:06:56'),(493,29,'DICE_TOKEN',5,5,'GRANT',NULL,'{}','2026-01-03 08:06:57'),(494,29,'LOTTERY_TICKET',-1,3,'LOTTERY_PLAY','룰렛티켓','{\"prize_id\": 107, \"consumed_trial\": false}','2026-01-03 08:07:47'),(495,29,'ROULETTE_COIN',1,1,'lottery_play','AUTO_GRANT','{\"reason\": \"lottery_play\", \"game_xp\": 0, \"prize_id\": 107}','2026-01-03 08:07:47'),(496,29,'LOTTERY_TICKET',-1,2,'LOTTERY_PLAY','배민5천원','{\"prize_id\": 108, \"consumed_trial\": false}','2026-01-03 08:07:53'),(497,29,'LOTTERY_TICKET',-1,1,'LOTTERY_PLAY','주사위티켓','{\"prize_id\": 113, \"consumed_trial\": false}','2026-01-03 08:07:58'),(498,29,'DICE_TOKEN',1,6,'lottery_play','AUTO_GRANT','{\"reason\": \"lottery_play\", \"game_xp\": 0, \"prize_id\": 113}','2026-01-03 08:07:58'),(499,29,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','룰렛티켓','{\"prize_id\": 107, \"consumed_trial\": false}','2026-01-03 08:08:03'),(500,29,'ROULETTE_COIN',1,2,'lottery_play','AUTO_GRANT','{\"reason\": \"lottery_play\", \"game_xp\": 0, \"prize_id\": 107}','2026-01-03 08:08:03'),(501,29,'ROULETTE_COIN',-1,1,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": false}','2026-01-03 08:08:22'),(502,29,'DICE_TOKEN',1,7,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 170}','2026-01-03 08:08:22'),(503,29,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','복권티켓1장','{\"segment_id\": 171, \"consumed_trial\": false}','2026-01-03 08:08:27'),(504,29,'LOTTERY_TICKET',1,1,'roulette_spin','AUTO_GRANT','{\"reason\": \"roulette_spin\", \"game_xp\": 0, \"segment_id\": 171}','2026-01-03 08:08:27'),(505,29,'DICE_TOKEN',-1,6,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:08:42'),(506,29,'DICE_TOKEN',-1,5,'DICE_PLAY','2026001 - DRAW','{\"result\": \"DRAW\", \"consumed_trial\": false}','2026-01-03 08:08:45'),(507,29,'DICE_TOKEN',1,6,'dice_play','AUTO_GRANT','{\"reason\": \"dice_play\", \"game_xp\": 0, \"outcome\": \"DRAW\"}','2026-01-03 08:08:46'),(508,29,'DICE_TOKEN',-1,5,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:08:49'),(509,29,'DICE_TOKEN',-1,4,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:08:52'),(510,29,'DICE_TOKEN',-1,3,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:08:55'),(511,29,'DICE_TOKEN',-1,2,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 08:08:58'),(512,29,'DICE_TOKEN',-1,1,'DICE_PLAY','2026001 - WIN','{\"result\": \"WIN\", \"consumed_trial\": false}','2026-01-03 08:09:01'),(513,29,'DICE_TOKEN',-1,0,'DICE_PLAY','2026001 - LOSE','{\"result\": \"LOSE\", \"consumed_trial\": false}','2026-01-03 08:09:04'),(514,29,'ROULETTE_COIN',1,1,'TRIAL_GRANT','TRIAL_ROULETTE_COIN_2026-01-03','{\"date\": \"2026-01-03\", \"source\": \"ticket_zero\"}','2026-01-03 08:09:18'),(515,29,'ROULETTE_COIN',-1,0,'ROULETTE_PLAY','주사위티켓1장','{\"segment_id\": 170, \"consumed_trial\": true}','2026-01-03 08:09:19'),(516,29,'LOTTERY_TICKET',-1,0,'LOTTERY_PLAY','컴포즈아아','{\"prize_id\": 114, \"consumed_trial\": false}','2026-01-03 08:09:47');
/*!40000 ALTER TABLE `user_game_wallet_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_idempotency_key`
--

DROP TABLE IF EXISTS `user_idempotency_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_idempotency_key` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `scope` varchar(50) NOT NULL,
  `idempotency_key` varchar(128) NOT NULL,
  `request_hash` varchar(64) NOT NULL,
  `request_json` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'IN_PROGRESS',
  `response_json` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_idempotency_key_user_scope_key` (`user_id`,`scope`,`idempotency_key`),
  KEY `ix_user_idempotency_key_status` (`status`),
  KEY `ix_user_idempotency_key_id` (`id`),
  KEY `ix_user_idempotency_key_user_id` (`user_id`),
  KEY `ix_user_idempotency_key_scope` (`scope`),
  KEY `ix_user_idempotency_key_user_scope_created` (`user_id`,`scope`,`created_at`),
  CONSTRAINT `user_idempotency_key_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_idempotency_key`
--

LOCK TABLES `user_idempotency_key` WRITE;
/*!40000 ALTER TABLE `user_idempotency_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_idempotency_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_inventory_item`
--

DROP TABLE IF EXISTS `user_inventory_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_inventory_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `item_type` varchar(50) NOT NULL,
  `quantity` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_inventory_item_user_item` (`user_id`,`item_type`),
  KEY `ix_user_inventory_item_id` (`id`),
  KEY `ix_user_inventory_item_item_type` (`item_type`),
  KEY `ix_user_inventory_item_user_id` (`user_id`),
  CONSTRAINT `fk_user_inventory_item_user_id_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_inventory_item`
--

LOCK TABLES `user_inventory_item` WRITE;
/*!40000 ALTER TABLE `user_inventory_item` DISABLE KEYS */;
INSERT INTO `user_inventory_item` VALUES (4,13,'DIAMOND',3,'2026-01-02 07:55:11','2026-01-03 05:12:25'),(5,7,'DIAMOND',2,'2026-01-02 13:53:48','2026-01-03 03:41:49');
/*!40000 ALTER TABLE `user_inventory_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_inventory_ledger`
--

DROP TABLE IF EXISTS `user_inventory_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_inventory_ledger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `item_type` varchar(50) NOT NULL,
  `change_amount` int NOT NULL,
  `balance_after` int NOT NULL,
  `reason` varchar(100) NOT NULL,
  `related_id` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_user_inventory_ledger_id` (`id`),
  KEY `ix_user_inventory_ledger_item_type` (`item_type`),
  KEY `ix_user_inventory_ledger_user_id` (`user_id`),
  CONSTRAINT `fk_user_inventory_ledger_user_id_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_inventory_ledger`
--

LOCK TABLES `user_inventory_ledger` WRITE;
/*!40000 ALTER TABLE `user_inventory_ledger` DISABLE KEYS */;
INSERT INTO `user_inventory_ledger` VALUES (7,13,'DIAMOND',1,1,'MISSION_REWARD','4','2026-01-02 07:55:11'),(9,7,'DIAMOND',1,1,'MISSION_REWARD','1','2026-01-02 13:53:48'),(10,13,'DIAMOND',1,2,'MISSION_REWARD','1','2026-01-02 14:36:07'),(11,7,'DIAMOND',1,2,'MISSION_REWARD','1','2026-01-03 03:41:49'),(12,13,'DIAMOND',1,3,'MISSION_REWARD','1','2026-01-03 05:12:25');
/*!40000 ALTER TABLE `user_inventory_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_level_progress`
--

DROP TABLE IF EXISTS `user_level_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_level_progress` (
  `user_id` int NOT NULL,
  `level` int NOT NULL,
  `xp` int NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_level_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_level_progress`
--

LOCK TABLES `user_level_progress` WRITE;
/*!40000 ALTER TABLE `user_level_progress` DISABLE KEYS */;
INSERT INTO `user_level_progress` VALUES (12,1,40,'2026-01-02 23:34:44'),(17,2,60,'2026-01-03 08:32:46'),(18,1,60,'2026-01-02 13:45:26'),(24,1,60,'2026-01-03 04:57:38'),(27,1,20,'2026-01-03 07:26:00'),(29,1,40,'2026-01-03 07:57:13'),(30,2,60,'2026-01-03 16:57:00');
/*!40000 ALTER TABLE `user_level_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_level_reward_log`
--

DROP TABLE IF EXISTS `user_level_reward_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_level_reward_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `level` int NOT NULL,
  `reward_type` varchar(50) NOT NULL,
  `reward_payload` json DEFAULT NULL,
  `auto_granted` tinyint(1) NOT NULL,
  `granted_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_level_reward` (`user_id`,`level`),
  KEY `ix_user_level_reward_log_id` (`id`),
  CONSTRAINT `user_level_reward_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_level_reward_log`
--

LOCK TABLES `user_level_reward_log` WRITE;
/*!40000 ALTER TABLE `user_level_reward_log` DISABLE KEYS */;
INSERT INTO `user_level_reward_log` VALUES (2,18,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-02 13:02:42'),(3,18,2,'TICKET_DICE','{\"tickets\": 3}',1,NULL,'2026-01-02 13:45:26'),(4,17,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-02 23:32:46'),(5,17,2,'TICKET_DICE','{\"tickets\": 3}',1,NULL,'2026-01-02 23:32:46'),(6,12,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-02 23:34:44'),(7,24,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-03 02:50:00'),(8,24,2,'TICKET_DICE','{\"tickets\": 3}',1,NULL,'2026-01-03 04:57:38'),(9,27,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-03 07:26:00'),(10,30,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-03 07:57:00'),(11,30,2,'TICKET_DICE','{\"tickets\": 3}',1,NULL,'2026-01-03 07:57:00'),(12,29,1,'TICKET_ROULETTE','{\"tickets\": 3}',1,NULL,'2026-01-03 07:57:13');
/*!40000 ALTER TABLE `user_level_reward_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_mission_progress`
--

DROP TABLE IF EXISTS `user_mission_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_mission_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `mission_id` int NOT NULL,
  `current_value` int NOT NULL,
  `is_completed` tinyint(1) DEFAULT NULL,
  `is_claimed` tinyint(1) DEFAULT NULL,
  `approval_status` enum('NONE','PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'NONE',
  `reset_date` varchar(50) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_mission_reset` (`user_id`,`mission_id`,`reset_date`),
  KEY `ix_user_mission_progress_mission_id` (`mission_id`),
  KEY `ix_user_mission_progress_user_id` (`user_id`),
  KEY `ix_user_mission_progress_id` (`id`),
  KEY `ix_user_mission_progress_reset_date` (`reset_date`),
  CONSTRAINT `user_mission_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_mission_progress_ibfk_2` FOREIGN KEY (`mission_id`) REFERENCES `mission` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_mission_progress`
--

LOCK TABLES `user_mission_progress` WRITE;
/*!40000 ALTER TABLE `user_mission_progress` DISABLE KEYS */;
INSERT INTO `user_mission_progress` VALUES (5,9,1,1,1,1,'NONE','2026-01-01','2026-01-01 03:23:33','2026-01-01 03:20:16'),(6,9,3,6,0,0,'NONE','2026-01-01','2026-01-01 03:21:28',NULL),(7,7,1,1,1,0,'NONE','2026-01-01','2026-01-01 04:19:07','2026-01-01 04:19:07'),(8,7,3,2,0,0,'NONE','2026-01-01','2026-01-01 04:19:15',NULL),(15,13,4,1,1,1,'NONE','STATIC','2026-01-03 01:44:39','2026-01-02 07:54:49'),(20,17,1,1,1,0,'NONE','2026-01-02','2026-01-02 12:13:24','2026-01-02 12:13:24'),(21,17,3,7,0,0,'NONE','2026-01-02','2026-01-02 12:15:29',NULL),(22,17,5,1,1,0,'NONE','STATIC','2026-01-02 12:13:24','2026-01-02 12:13:24'),(23,17,6,3,1,0,'NONE','STATIC','2026-01-02 12:14:17','2026-01-02 12:14:17'),(24,18,1,1,1,0,'NONE','2026-01-02','2026-01-02 12:42:03','2026-01-02 12:42:03'),(25,18,3,13,0,0,'NONE','2026-01-02','2026-01-02 13:26:43',NULL),(26,18,5,1,1,0,'NONE','STATIC','2026-01-02 12:42:03','2026-01-02 12:42:03'),(27,18,6,3,1,0,'NONE','STATIC','2026-01-02 12:42:18','2026-01-02 12:42:18'),(28,13,1,1,1,1,'NONE','2026-01-02','2026-01-02 14:36:07','2026-01-02 12:58:32'),(29,13,3,12,0,0,'NONE','2026-01-02','2026-01-02 14:35:57',NULL),(30,13,5,1,1,1,'NONE','STATIC','2026-01-02 14:36:10','2026-01-02 12:58:32'),(31,13,6,3,1,1,'NONE','STATIC','2026-01-03 01:44:38','2026-01-02 12:59:09'),(32,19,1,1,1,0,'NONE','2026-01-02','2026-01-02 13:20:00','2026-01-02 13:20:00'),(33,19,3,13,0,0,'NONE','2026-01-02','2026-01-02 13:37:59',NULL),(34,19,5,1,1,0,'NONE','STATIC','2026-01-02 13:20:00','2026-01-02 13:20:00'),(35,19,6,3,1,0,'NONE','STATIC','2026-01-02 13:20:21','2026-01-02 13:20:21'),(36,7,1,1,1,1,'NONE','2026-01-02','2026-01-02 13:53:48','2026-01-02 13:52:20'),(37,7,3,3,0,0,'NONE','2026-01-02','2026-01-02 13:53:23',NULL),(38,7,5,1,1,1,'NONE','STATIC','2026-01-02 13:53:55','2026-01-02 13:52:20'),(39,7,6,3,1,1,'NONE','STATIC','2026-01-02 13:53:56','2026-01-02 13:53:23'),(40,7,7,1,1,1,'NONE','STATIC','2026-01-02 23:01:52','2026-01-02 14:01:51'),(41,20,1,1,1,0,'NONE','2026-01-03','2026-01-02 16:45:22','2026-01-02 16:45:22'),(42,20,3,0,0,0,'NONE','2026-01-03','2026-01-02 23:20:42',NULL),(43,20,5,1,1,0,'NONE','STATIC','2026-01-02 16:45:22','2026-01-02 16:45:22'),(44,20,6,3,1,0,'NONE','STATIC','2026-01-02 16:46:00','2026-01-02 16:46:00'),(45,20,7,1,1,0,'NONE','STATIC','2026-01-02 23:19:48','2026-01-02 23:19:48'),(46,7,1,1,1,1,'NONE','2026-01-03','2026-01-03 03:41:49','2026-01-03 01:43:14'),(47,7,3,4,0,0,'NONE','2026-01-03','2026-01-03 01:43:49',NULL),(48,13,7,0,1,1,'NONE','STATIC','2026-01-03 05:12:30','2026-01-03 01:43:17'),(49,9,1,1,1,0,'NONE','2026-01-03','2026-01-03 02:16:32','2026-01-03 02:16:32'),(50,9,3,3,0,0,'NONE','2026-01-03','2026-01-03 02:17:13',NULL),(51,9,5,1,1,0,'NONE','STATIC','2026-01-03 02:16:32','2026-01-03 02:16:32'),(52,9,6,3,1,0,'NONE','STATIC','2026-01-03 02:17:13','2026-01-03 02:17:13'),(53,13,1,1,1,1,'NONE','2026-01-03','2026-01-03 05:12:25','2026-01-03 03:02:37'),(54,13,3,3,0,0,'NONE','2026-01-03','2026-01-03 03:03:53',NULL),(55,16,1,1,1,0,'NONE','2026-01-03','2026-01-03 03:36:27','2026-01-03 03:36:27'),(56,16,3,6,0,0,'NONE','2026-01-03','2026-01-03 03:37:57',NULL),(57,16,5,1,1,0,'NONE','STATIC','2026-01-03 03:36:27','2026-01-03 03:36:27'),(58,16,6,3,1,0,'NONE','STATIC','2026-01-03 03:37:35','2026-01-03 03:37:35'),(59,27,1,1,1,0,'NONE','2026-01-03','2026-01-03 05:31:55','2026-01-03 05:31:55'),(60,27,3,11,0,0,'NONE','2026-01-03','2026-01-03 05:35:44',NULL),(61,27,5,1,1,0,'NONE','STATIC','2026-01-03 05:31:55','2026-01-03 05:31:55'),(62,27,6,3,1,0,'NONE','STATIC','2026-01-03 05:32:45','2026-01-03 05:32:45'),(63,26,1,1,1,0,'NONE','2026-01-03','2026-01-03 05:39:07','2026-01-03 05:39:07'),(64,26,3,2,0,0,'NONE','2026-01-03','2026-01-03 05:39:20',NULL),(65,26,5,1,1,0,'NONE','STATIC','2026-01-03 05:39:07','2026-01-03 05:39:07'),(66,26,6,2,0,0,'NONE','STATIC','2026-01-03 05:39:20',NULL),(67,30,1,1,1,0,'NONE','2026-01-03','2026-01-03 07:56:00','2026-01-03 07:56:00'),(68,30,3,18,0,0,'NONE','2026-01-03','2026-01-03 07:59:30',NULL),(69,30,5,1,1,0,'NONE','STATIC','2026-01-03 07:56:00','2026-01-03 07:56:00'),(70,30,6,3,1,0,'NONE','STATIC','2026-01-03 07:56:23','2026-01-03 07:56:23'),(71,29,1,1,1,0,'NONE','2026-01-03','2026-01-03 08:01:39','2026-01-03 08:01:39'),(72,29,3,26,1,0,'NONE','2026-01-03','2026-01-03 08:06:50','2026-01-03 08:06:50'),(73,29,5,1,1,0,'NONE','STATIC','2026-01-03 08:01:39','2026-01-03 08:01:39'),(74,29,6,3,1,0,'NONE','STATIC','2026-01-03 08:03:44','2026-01-03 08:03:44');
/*!40000 ALTER TABLE `user_mission_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_segment`
--

DROP TABLE IF EXISTS `user_segment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_segment` (
  `user_id` int NOT NULL,
  `segment` varchar(50) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_segment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_segment`
--

LOCK TABLES `user_segment` WRITE;
/*!40000 ALTER TABLE `user_segment` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_segment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_xp_event_log`
--

DROP TABLE IF EXISTS `user_xp_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_xp_event_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `source` varchar(100) NOT NULL,
  `delta` int NOT NULL,
  `meta` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_user_xp_event_log_id` (`id`),
  CONSTRAINT `user_xp_event_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_xp_event_log`
--

LOCK TABLES `user_xp_event_log` WRITE;
/*!40000 ALTER TABLE `user_xp_event_log` DISABLE KEYS */;
INSERT INTO `user_xp_event_log` VALUES (2,18,'EXTERNAL_RANKING_DEPOSIT',40,'{\"xp_per_step\": 20, \"deposit_delta\": 200000, \"deposit_steps\": 2}','2026-01-02 13:02:42'),(3,18,'EXTERNAL_RANKING_DEPOSIT',20,'{\"xp_per_step\": 20, \"deposit_delta\": 120000, \"deposit_steps\": 1}','2026-01-02 13:45:26'),(4,17,'EXTERNAL_RANKING_DEPOSIT',60,'{\"xp_per_step\": 20, \"deposit_delta\": 350000, \"deposit_steps\": 3}','2026-01-02 23:32:46'),(5,12,'EXTERNAL_RANKING_DEPOSIT',40,'{\"xp_per_step\": 20, \"deposit_delta\": 200000, \"deposit_steps\": 2}','2026-01-02 23:34:44'),(6,24,'EXTERNAL_RANKING_DEPOSIT',40,'{\"xp_per_step\": 20, \"deposit_delta\": 200000, \"deposit_steps\": 2}','2026-01-03 02:50:00'),(7,24,'EXTERNAL_RANKING_DEPOSIT',20,'{\"xp_per_step\": 20, \"deposit_delta\": 100000, \"deposit_steps\": 1}','2026-01-03 04:57:38'),(8,27,'EXTERNAL_RANKING_DEPOSIT',20,'{\"xp_per_step\": 20, \"deposit_delta\": 150000, \"deposit_steps\": 1}','2026-01-03 07:26:00'),(9,30,'EXTERNAL_RANKING_DEPOSIT',60,'{\"xp_per_step\": 20, \"deposit_delta\": 300000, \"deposit_steps\": 3}','2026-01-03 07:57:00'),(10,29,'EXTERNAL_RANKING_DEPOSIT',40,'{\"xp_per_step\": 20, \"deposit_delta\": 200000, \"deposit_steps\": 2}','2026-01-03 07:57:13');
/*!40000 ALTER TABLE `user_xp_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_earn_event`
--

DROP TABLE IF EXISTS `vault_earn_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_earn_event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `earn_event_id` varchar(128) NOT NULL,
  `earn_type` varchar(50) NOT NULL,
  `amount` int NOT NULL,
  `source` varchar(50) NOT NULL,
  `reward_kind` varchar(50) DEFAULT NULL,
  `game_type` varchar(50) DEFAULT NULL,
  `token_type` varchar(50) DEFAULT NULL,
  `payout_raw_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vault_earn_event_earn_event_id` (`earn_event_id`),
  KEY `ix_vault_earn_event_user_created_at` (`user_id`,`created_at`),
  KEY `ix_vault_earn_event_id` (`id`),
  CONSTRAINT `vault_earn_event_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_earn_event`
--

LOCK TABLES `vault_earn_event` WRITE;
/*!40000 ALTER TABLE `vault_earn_event` DISABLE KEYS */;
INSERT INTO `vault_earn_event` VALUES (86,9,'GAME:ROULETTE:40','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 136, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-01 03:20:16'),(87,9,'GAME:ROULETTE:41','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 134, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-01 03:20:26'),(88,9,'GAME:ROULETTE:42','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 133, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-01 03:20:38'),(89,9,'GAME:ROULETTE:43','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 134, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-01 03:20:50'),(90,9,'GAME:DICE:31','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-01 03:21:24'),(91,7,'GAME:ROULETTE:44','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 135, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-01 04:19:07'),(92,7,'GAME:LOTTERY:17','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 58, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-01 04:19:15'),(100,17,'GAME:DICE:37','GAME_PLAY',300,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 300, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:13:24'),(101,17,'TRIAL:DICE:37:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_VALUATION','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:13:24'),(102,17,'GAME:ROULETTE:48','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:14:12'),(103,17,'GAME:ROULETTE:49','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:14:17'),(104,17,'GAME:ROULETTE:50','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:14:30'),(105,17,'TRIAL:ROULETTE:50:TICKET_DICE:1','TRIAL_PAYOUT',0,'ROULETTE','SKIP_NO_VALUATION','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:14:30'),(106,17,'GAME:DICE:38','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:15:01'),(107,17,'GAME:LOTTERY:18','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 100, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:15:29'),(108,17,'TRIAL:LOTTERY:18:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_VALUATION','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 100, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:15:29'),(109,18,'GAME:ROULETTE:51','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:03'),(110,18,'GAME:ROULETTE:52','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:09'),(111,18,'GAME:ROULETTE:53','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:17'),(112,18,'GAME:ROULETTE:54','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:25'),(113,18,'GAME:ROULETTE:55','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:34'),(114,18,'GAME:ROULETTE:56','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:42'),(115,18,'GAME:ROULETTE:57','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:42:49'),(116,18,'GAME:ROULETTE:58','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:43:03'),(117,18,'TRIAL:ROULETTE:58:NONE:0','TRIAL_PAYOUT',0,'ROULETTE','SKIP_NO_VALUATION','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"NONE:0\", \"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:43:03'),(118,13,'GAME:ROULETTE:59','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:58:32'),(119,13,'GAME:ROULETTE:60','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:58:42'),(120,13,'TRIAL:ROULETTE:60:TICKET_DICE:1','TRIAL_PAYOUT',100,'ROULETTE','VALUED','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:58:42'),(121,13,'GAME:DICE:40','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:08'),(122,13,'GAME:DICE:41','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:14'),(123,13,'GAME:DICE:42','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:19'),(124,13,'GAME:DICE:43','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:22'),(125,13,'GAME:DICE:44','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:25'),(126,13,'GAME:DICE:45','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:29'),(127,13,'GAME:DICE:46','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:31'),(128,13,'GAME:DICE:47','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:34'),(129,13,'GAME:DICE:48','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 12:59:36'),(130,19,'GAME:ROULETTE:61','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:20:00'),(131,19,'GAME:ROULETTE:62','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 174, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:20:11'),(132,19,'GAME:ROULETTE:63','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:20:21'),(133,19,'GAME:ROULETTE:64','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:20:26'),(134,19,'GAME:ROULETTE:65','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:20:37'),(135,19,'GAME:ROULETTE:66','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:20:51'),(136,19,'GAME:ROULETTE:67','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:21:01'),(137,19,'GAME:ROULETTE:68','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:21:13'),(138,18,'GAME:ROULETTE:69','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:26:22'),(139,18,'GAME:ROULETTE:70','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:26:26'),(140,18,'GAME:ROULETTE:71','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:26:32'),(141,18,'GAME:ROULETTE:72','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:26:39'),(142,18,'GAME:ROULETTE:73','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:26:43'),(143,19,'GAME:LOTTERY:19','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 103, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:26:54'),(144,19,'GAME:LOTTERY:20','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 104, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:27:06'),(145,19,'TRIAL:LOTTERY:20:TICKET_DICE:1','TRIAL_PAYOUT',100,'LOTTERY','VALUED','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 104, \"reward_id\": \"TICKET_DICE:1\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:27:06'),(146,19,'GAME:ROULETTE:74','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:36:22'),(147,19,'TRIAL:ROULETTE:74:TICKET_ROULETTE:2','TRIAL_PAYOUT',0,'ROULETTE','SKIP_NO_VALUATION','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_ROULETTE:2\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:36:22'),(148,19,'GAME:DICE:49','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:37:40'),(149,19,'GAME:DICE:50','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:37:59'),(150,19,'TRIAL:DICE:50:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_VALUATION','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:37:59'),(151,7,'GAME:ROULETTE:75','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:52:20'),(152,7,'TRIAL:ROULETTE:75:TICKET_ROULETTE:1','TRIAL_PAYOUT',0,'ROULETTE','SKIP_NO_VALUATION','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_ROULETTE:1\", \"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:52:20'),(153,7,'GAME:DICE:51','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:52:44'),(154,7,'TRIAL:DICE:51:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_VALUATION','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:52:44'),(155,7,'GAME:LOTTERY:21','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 104, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:53:23'),(156,7,'TRIAL:LOTTERY:21:TICKET_DICE:1','TRIAL_PAYOUT',100,'LOTTERY','VALUED','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 104, \"reward_id\": \"TICKET_DICE:1\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-02 13:53:23'),(157,13,'GAME:LOTTERY:22','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 108, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 14:35:57'),(158,13,'TRIAL:LOTTERY:22:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_VALUATION','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 108, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 14:35:57'),(159,20,'GAME:DICE:52','GAME_PLAY',300,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 300, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:45:21'),(160,20,'TRIAL:DICE:52:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_REWARD','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:45:21'),(161,20,'GAME:ROULETTE:76','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:45:56'),(162,20,'GAME:ROULETTE:77','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:00'),(163,20,'GAME:ROULETTE:78','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:08'),(164,20,'GAME:ROULETTE:79','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:16'),(165,20,'GAME:ROULETTE:80','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:23'),(166,20,'GAME:ROULETTE:81','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:36'),(167,20,'TRIAL:ROULETTE:81:TICKET_DICE:1','TRIAL_PAYOUT',100,'ROULETTE','VALUED','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:37'),(168,20,'GAME:ROULETTE:82','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','GOLD_KEY','{\"segment_id\": 152, \"reward_type\": \"POINT\", \"reward_amount\": 5000, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:45'),(169,20,'TRIAL:ROULETTE:82:POINT:5000','TRIAL_PAYOUT',5000,'ROULETTE','POINT','ROULETTE','GOLD_KEY','{\"reward_id\": \"POINT:5000\", \"segment_id\": 152, \"reward_type\": \"POINT\", \"reward_amount\": 5000, \"amount_before_multiplier\": 5000, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:46:45'),(170,20,'GAME:ROULETTE:83','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','DIAMOND_KEY','{\"segment_id\": 163, \"reward_type\": \"POINT\", \"reward_amount\": 20000, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:47:02'),(171,20,'TRIAL:ROULETTE:83:POINT:20000','TRIAL_PAYOUT',20000,'ROULETTE','POINT','ROULETTE','DIAMOND_KEY','{\"reward_id\": \"POINT:20000\", \"segment_id\": 163, \"reward_type\": \"POINT\", \"reward_amount\": 20000, \"amount_before_multiplier\": 20000, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:47:02'),(172,20,'GAME:DICE:54','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:51:27'),(173,20,'GAME:DICE:55','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:51:30'),(174,20,'GAME:DICE:57','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:51:39'),(175,20,'GAME:LOTTERY:23','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:53:03'),(176,20,'TRIAL:LOTTERY:23:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_REWARD','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-02 16:53:03'),(177,7,'GAME:DICE:58','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:14'),(178,7,'GAME:DICE:59','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:22'),(179,7,'TRIAL:DICE:59:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_REWARD','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:22'),(180,7,'GAME:ROULETTE:84','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:35'),(181,7,'TRIAL:ROULETTE:84:TICKET_DICE:1','TRIAL_PAYOUT',100,'ROULETTE','VALUED','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:35'),(182,7,'GAME:LOTTERY:24','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 112, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:49'),(183,7,'TRIAL:LOTTERY:24:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_REWARD','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 112, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 01:43:49'),(184,9,'TRIAL:DICE:60:TICKET_DICE:1','TRIAL_PAYOUT',100,'DICE','VALUED','DICE','DICE_TOKEN','{\"result\": \"DRAW\", \"reward_id\": \"TICKET_DICE:1\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-03 02:16:32'),(185,9,'GAME:ROULETTE:85','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 02:16:42'),(186,9,'TRIAL:ROULETTE:85:TICKET_DICE:1','TRIAL_PAYOUT',100,'ROULETTE','VALUED','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-03 02:16:42'),(187,9,'GAME:LOTTERY:25','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 113, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 02:17:13'),(188,9,'TRIAL:LOTTERY:25:TICKET_DICE:1','TRIAL_PAYOUT',100,'LOTTERY','VALUED','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 113, \"reward_id\": \"TICKET_DICE:1\", \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-03 02:17:13'),(189,13,'GAME:ROULETTE:86','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:02:37'),(190,13,'TRIAL:ROULETTE:86:TICKET_DICE:1','TRIAL_PAYOUT',100,'ROULETTE','VALUED','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 100, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:02:37'),(191,13,'GAME:DICE:61','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:03:41'),(192,13,'TRIAL:DICE:61:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_REWARD','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:03:41'),(193,13,'GAME:LOTTERY:26','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:03:53'),(194,13,'TRIAL:LOTTERY:26:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_REWARD','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:03:53'),(195,16,'GAME:LOTTERY:27','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 107, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:36:27'),(196,16,'TRIAL:LOTTERY:27:TICKET_ROULETTE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_VALUATION','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 107, \"reward_id\": \"TICKET_ROULETTE:1\", \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:36:27'),(197,16,'GAME:DICE:62','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:36:58'),(198,16,'TRIAL:DICE:62:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_REWARD','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:36:59'),(199,16,'GAME:ROULETTE:87','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:37:35'),(200,16,'GAME:ROULETTE:88','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:37:40'),(201,16,'GAME:DICE:63','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:37:55'),(202,16,'GAME:DICE:64','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 03:37:57'),(203,27,'GAME:DICE:65','GAME_PLAY',300,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 300, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:31:54'),(204,27,'TRIAL:DICE:65:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_REWARD','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:31:55'),(205,27,'GAME:ROULETTE:89','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:32:36'),(206,27,'GAME:ROULETTE:90','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:32:45'),(207,27,'GAME:ROULETTE:91','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:32:50'),(208,27,'GAME:ROULETTE:92','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:32:58'),(209,27,'GAME:ROULETTE:93','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:33:07'),(210,27,'GAME:DICE:66','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:33:58'),(211,27,'GAME:DICE:67','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:34:01'),(212,27,'GAME:DICE:68','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:34:04'),(213,27,'GAME:LOTTERY:28','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:35:17'),(214,27,'TRIAL:LOTTERY:28:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_REWARD','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:35:17'),(215,27,'GAME:ROULETTE:94','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:35:44'),(216,27,'TRIAL:ROULETTE:94:TICKET_ROULETTE:2','TRIAL_PAYOUT',0,'ROULETTE','SKIP_NO_VALUATION','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_ROULETTE:2\", \"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:35:44'),(217,26,'GAME:ROULETTE:95','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:39:07'),(218,26,'GAME:ROULETTE:96','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 05:39:20'),(219,30,'GAME:ROULETTE:97','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:56:00'),(220,30,'GAME:ROULETTE:98','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:56:15'),(221,30,'GAME:ROULETTE:99','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:56:23'),(222,30,'GAME:ROULETTE:100','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:56:36'),(223,30,'GAME:ROULETTE:101','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:56:44'),(224,30,'GAME:ROULETTE:102','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:56:55'),(225,30,'GAME:ROULETTE:103','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:04'),(226,30,'GAME:ROULETTE:104','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:14'),(227,30,'GAME:ROULETTE:105','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:22'),(228,30,'GAME:ROULETTE:106','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:32'),(229,30,'GAME:ROULETTE:107','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:41'),(230,30,'GAME:ROULETTE:108','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:53'),(231,30,'GAME:ROULETTE:109','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:57:59'),(232,30,'GAME:ROULETTE:110','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:58:06'),(233,30,'GAME:ROULETTE:111','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:58:14'),(234,30,'GAME:ROULETTE:112','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:58:22'),(235,30,'GAME:ROULETTE:113','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:58:30'),(236,30,'GAME:ROULETTE:114','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','GOLD_KEY','{\"segment_id\": 154, \"reward_type\": \"POINT\", \"reward_amount\": 20000, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:59:30'),(237,30,'TRIAL:ROULETTE:114:POINT:20000','TRIAL_PAYOUT',20000,'ROULETTE','POINT','ROULETTE','GOLD_KEY','{\"reward_id\": \"POINT:20000\", \"segment_id\": 154, \"reward_type\": \"POINT\", \"reward_amount\": 20000, \"is_key_spin_point\": true, \"original_reward_type\": \"POINT\", \"amount_before_multiplier\": 20000, \"vault_accrual_multiplier\": 1.0}','2026-01-03 07:59:30'),(238,29,'GAME:LOTTERY:29','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 112, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:01:39'),(239,29,'GAME:LOTTERY:30','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 108, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:02:30'),(240,29,'TRIAL:LOTTERY:30:NONE:1','TRIAL_PAYOUT',0,'LOTTERY','SKIP_NO_REWARD','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 108, \"reward_id\": \"NONE:1\", \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:02:30'),(241,29,'GAME:DICE:70','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:03:50'),(242,29,'GAME:DICE:71','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:01'),(243,29,'TRIAL:DICE:71:NONE:0','TRIAL_PAYOUT',0,'DICE','SKIP_NO_REWARD','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_id\": \"NONE:0\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 0, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:01'),(244,29,'GAME:ROULETTE:115','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:22'),(245,29,'GAME:ROULETTE:116','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:28'),(246,29,'GAME:ROULETTE:117','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:36'),(247,29,'GAME:ROULETTE:118','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:45'),(248,29,'GAME:ROULETTE:119','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:04:53'),(249,29,'GAME:ROULETTE:120','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 169, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:00'),(250,29,'GAME:ROULETTE:121','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:07'),(251,29,'GAME:ROULETTE:122','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:15'),(252,29,'GAME:ROULETTE:123','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:22'),(253,29,'GAME:ROULETTE:124','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:30'),(254,29,'GAME:ROULETTE:125','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:38'),(255,29,'GAME:ROULETTE:126','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:45'),(256,29,'GAME:ROULETTE:127','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 172, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 2, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:05:53'),(257,29,'GAME:ROULETTE:128','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:00'),(258,29,'GAME:ROULETTE:129','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:08'),(259,29,'GAME:ROULETTE:130','GAME_PLAY',-50,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 173, \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:15'),(260,29,'GAME:DICE:73','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:38'),(261,29,'GAME:DICE:75','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:46'),(262,29,'GAME:DICE:76','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:50'),(263,29,'GAME:DICE:77','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:53'),(264,29,'GAME:DICE:78','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:06:56'),(265,29,'GAME:LOTTERY:31','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 107, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:07:47'),(266,29,'GAME:LOTTERY:32','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 108, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:07:54'),(267,29,'GAME:LOTTERY:33','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 113, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:07:58'),(268,29,'GAME:LOTTERY:34','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 107, \"reward_type\": \"TICKET_ROULETTE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:03'),(269,29,'GAME:ROULETTE:131','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:22'),(270,29,'GAME:ROULETTE:132','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 171, \"reward_type\": \"TICKET_LOTTERY\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:27'),(271,29,'GAME:DICE:79','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:42'),(272,29,'GAME:DICE:81','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:49'),(273,29,'GAME:DICE:82','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:52'),(274,29,'GAME:DICE:83','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:55'),(275,29,'GAME:DICE:84','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:08:58'),(276,29,'GAME:DICE:85','GAME_PLAY',200,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"WIN\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:09:01'),(277,29,'GAME:DICE:86','GAME_PLAY',-50,'DICE','BASE','DICE','DICE_TOKEN','{\"result\": \"LOSE\", \"reward_type\": \"NONE\", \"reward_amount\": 0, \"amount_before_multiplier\": -50, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:09:04'),(278,29,'GAME:ROULETTE:133','GAME_PLAY',200,'ROULETTE','BASE','ROULETTE','ROULETTE_COIN','{\"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:09:20'),(279,29,'TRIAL:ROULETTE:133:TICKET_DICE:1','TRIAL_PAYOUT',10,'ROULETTE','VALUED','ROULETTE','ROULETTE_COIN','{\"reward_id\": \"TICKET_DICE:1\", \"segment_id\": 170, \"reward_type\": \"TICKET_DICE\", \"reward_amount\": 1, \"amount_before_multiplier\": 10, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:09:20'),(280,29,'GAME:LOTTERY:35','GAME_PLAY',200,'LOTTERY','BASE','LOTTERY','LOTTERY_TICKET','{\"prize_id\": 114, \"reward_type\": \"NONE\", \"reward_amount\": 1, \"amount_before_multiplier\": 200, \"vault_accrual_multiplier\": 1.0}','2026-01-03 08:09:47');
/*!40000 ALTER TABLE `vault_earn_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_program`
--

DROP TABLE IF EXISTS `vault_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_program` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `duration_hours` int NOT NULL DEFAULT '24',
  `expire_policy` varchar(30) NOT NULL DEFAULT 'FIXED_24H',
  `unlock_rules_json` json DEFAULT NULL,
  `ui_copy_json` json DEFAULT NULL,
  `config_json` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`),
  KEY `ix_vault_program_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_program`
--

LOCK TABLES `vault_program` WRITE;
/*!40000 ALTER TABLE `vault_program` DISABLE KEYS */;
INSERT INTO `vault_program` VALUES (1,'NEW_MEMBER_VAULT','신규 정착 금고',24,'FIXED_24H','{\"available_grace_hours\": 0, \"phase1_deposit_unlock\": {\"tiers\": [{\"unlock_amount\": 30000, \"min_deposit_delta\": 500000}], \"trigger\": \"EXTERNAL_RANKING_DEPOSIT_INCREASE\"}}','{\"desc\": \"지금 바로 씨씨 충전하구 티켓받자! \", \"title\": \"내 금고\"}','{\"eligibility_mode\": \"all\", \"game_earn_config\": {}, \"eligibility_allow\": [], \"eligibility_block\": [], \"accrual_multiplier\": 1, \"charge_bonus_rules\": [], \"trial_reward_valuation\": {\"TICKET_DICE:1\": 10, \"TICKET_DICE:2\": 10, \"TICKET_LOTTERY:1\": 10, \"TICKET__ROULETTE:1\": 10, \"TICKET__ROULETTE:2\": 10}, \"enable_game_earn_events\": true}',1,'2025-12-31 16:11:00','2026-01-03 03:05:10');
/*!40000 ALTER TABLE `vault_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_status`
--

DROP TABLE IF EXISTS `vault_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `program_id` int NOT NULL,
  `state` varchar(20) NOT NULL DEFAULT 'LOCKED',
  `locked_amount` int NOT NULL DEFAULT '0',
  `available_amount` int NOT NULL DEFAULT '0',
  `progress_json` json DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_vault_status_id` (`id`),
  KEY `ix_vault_status_user_id` (`user_id`),
  KEY `ix_vault_status_program_id` (`program_id`),
  CONSTRAINT `fk_vault_status_program_id_vault_program` FOREIGN KEY (`program_id`) REFERENCES `vault_program` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vault_status_user_id_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_status`
--

LOCK TABLES `vault_status` WRITE;
/*!40000 ALTER TABLE `vault_status` DISABLE KEYS */;
INSERT INTO `vault_status` VALUES (3,9,1,'LOCKED',1500,0,'{\"events\": [{\"at\": \"2026-01-01T03:20:16.220017\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-01 03:20:16','2026-01-02 03:20:16','2026-01-01 03:20:16','2026-01-03 02:17:13'),(4,7,1,'LOCKED',1600,0,'{\"events\": [{\"at\": \"2026-01-01T04:19:06.796486\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-01 04:19:07','2026-01-02 04:19:07','2026-01-01 04:19:07','2026-01-03 01:43:49'),(5,17,1,'LOCKED',1100,0,'{\"events\": [{\"at\": \"2026-01-02T12:13:24.001971\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 300}]}','2026-01-02 12:13:24','2026-01-03 12:13:24','2026-01-02 12:13:24','2026-01-02 12:15:29'),(6,18,1,'LOCKED',1800,0,'{\"events\": [{\"at\": \"2026-01-02T12:42:03.192674\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-02 12:42:03','2026-01-03 12:42:03','2026-01-02 12:42:03','2026-01-02 13:26:43'),(7,13,1,'LOCKED',2800,0,'{\"events\": [{\"at\": \"2026-01-02T12:58:31.600634\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-02 12:58:32','2026-01-03 12:58:32','2026-01-02 12:58:32','2026-01-03 03:03:53'),(8,19,1,'LOCKED',2100,0,'{\"events\": [{\"at\": \"2026-01-02T13:19:59.990400\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-02 13:20:00','2026-01-03 13:20:00','2026-01-02 13:20:00','2026-01-02 13:37:59'),(9,20,1,'LOCKED',2550,0,'{\"events\": [{\"at\": \"2026-01-02T16:45:21.300175\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 300}]}','2026-01-02 16:45:21','2026-01-03 16:45:21','2026-01-02 16:45:21','2026-01-02 23:08:00'),(10,16,1,'LOCKED',800,0,'{\"events\": [{\"at\": \"2026-01-03T03:36:27.099785\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-03 03:36:27','2026-01-04 03:36:27','2026-01-03 03:36:27','2026-01-03 03:37:55'),(11,27,1,'LOCKED',1900,0,'{\"events\": [{\"at\": \"2026-01-03T05:31:54.013881\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 300}]}','2026-01-03 05:31:54','2026-01-04 05:31:54','2026-01-03 05:31:55','2026-01-03 05:35:44'),(12,26,1,'LOCKED',400,0,'{\"events\": [{\"at\": \"2026-01-03T05:39:06.514496\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-03 05:39:07','2026-01-04 05:39:07','2026-01-03 05:39:07','2026-01-03 05:39:20'),(13,30,1,'LOCKED',29400,0,'{\"events\": [{\"at\": \"2026-01-03T07:55:59.904177\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-03 07:56:00','2026-01-04 07:56:00','2026-01-03 07:56:00','2026-01-03 08:11:22'),(14,29,1,'LOCKED',6410,0,'{\"events\": [{\"at\": \"2026-01-03T08:01:38.603861\", \"type\": \"ACCRUE_LOCKED\", \"amount\": 200}]}','2026-01-03 08:01:39','2026-01-04 08:01:39','2026-01-03 08:01:39','2026-01-03 08:09:47');
/*!40000 ALTER TABLE `vault_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_withdrawal_request`
--

DROP TABLE IF EXISTS `vault_withdrawal_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_withdrawal_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `admin_memo` varchar(255) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `processed_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_vault_withdrawal_request_id` (`id`),
  KEY `ix_vault_withdrawal_request_user_id` (`user_id`),
  CONSTRAINT `vault_withdrawal_request_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_withdrawal_request`
--

LOCK TABLES `vault_withdrawal_request` WRITE;
/*!40000 ALTER TABLE `vault_withdrawal_request` DISABLE KEYS */;
INSERT INTO `vault_withdrawal_request` VALUES (1,30,23100,'APPROVED',NULL,'2026-01-03 08:04:51',1,'2026-01-03 08:04:07','2026-01-03 08:04:51');
/*!40000 ALTER TABLE `vault_withdrawal_request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-03 17:40:41
