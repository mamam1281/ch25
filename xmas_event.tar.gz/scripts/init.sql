-- Minimal init: Alembic handles schema. Keep empty to avoid conflicting tables.
SELECT 'Database init placeholder - schema created via Alembic' AS status;
