/// <reference types="cypress" />

// Shared Cypress E2E setup. Extend with custom commands if needed.
export {};
